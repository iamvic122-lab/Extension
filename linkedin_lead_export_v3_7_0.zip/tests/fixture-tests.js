(async function runFixtureTests(){
  const results=[]; const main=document.getElementById('fixture-main'); const nav=document.getElementById('fixture-pagination');
  const assert=(name,condition,detail='')=>{results.push({name,pass:!!condition,detail:condition?'':String(detail||'failed')});if(!condition)console.error('FAIL',name,detail);};
  const route=(path)=>history.replaceState({},'',path);
  const profileRow=(slug,name,headline,location='')=>`<li class="reusable-search__result-container"><div class="entity-result"><span class="entity-result__title-text"><a href="/in/${slug}/"><span aria-hidden="true">${name}</span></a></span><div class="entity-result__primary-subtitle">${headline}</div><div class="entity-result__secondary-subtitle">${location}</div></div></li>`;
  try {
    const A=window.LXLinkedInAdapters, E=window.LXExtractor, U=window.LX, C=window.LXConstants;
    const expectedFields=['url','person_name','job_title','company_name','company_profile_url','current_job_period','headline','location','current_job_location','status'];
    const contexts=[
      ['https://www.linkedin.com/search/results/people/?keywords=dev','search',true],
      ['https://www.linkedin.com/mynetwork/invite-connect/connections/','connections',true],
      ['https://www.linkedin.com/mynetwork/grow/','grow',true],
      ['https://www.linkedin.com/in/jane-doe/','profile',false],
      ['https://www.linkedin.com/sales/search/people','sales-people',true],
      ['https://www.linkedin.com/sales/search/companies','sales-company',true]
    ];
    for(const [url,type,isList] of contexts){const found=A.detectContext(url,document);assert('context '+type,found.pageType===type&&found.isListView===isList,JSON.stringify(found));}
    assert('exact person output columns',JSON.stringify(U.getColumns('person').map(c=>c.label))===JSON.stringify(expectedFields),U.getColumns('person').map(c=>c.label).join(','));

    route('/search/results/people/?keywords=fixture');
    main.innerHTML=`<ol>${profileRow('alex-shepard','Alex Shepard','Partnerships Manager at Example Co','Boston, MA')}${profileRow('bea-chen','Bea Chen','Product Designer','Toronto, ON')}</ol><section><h2>More profiles for you</h2>${profileRow('recommend-me','Unrelated Recommended Person','Sponsored Profile','New York')}</section>`;
    let rows=E.findResultRows('person');
    assert('standard Search excludes unrelated recommendation section',rows.length===2,`rows=${rows.length}`);
    let listed=A.readListPerson(rows[0],'search',0,location.href);
    listed=U.normalizeLead(listed);
    assert('Search canonical url and name',listed.url==='https://www.linkedin.com/in/alex-shepard'&&listed.person_name==='Alex Shepard',JSON.stringify({url:listed.url,name:listed.person_name}));
    assert('Search headline and location from semantically identified fields',listed.headline==='Partnerships Manager at Example Co'&&listed.location==='Boston, MA',JSON.stringify({headline:listed.headline,location:listed.location}));
    assert('list does not fabricate Experience fields',listed.job_title==='N/A'&&listed.company_name==='N/A'&&listed.company_profile_url==='N/A'&&listed.current_job_period==='N/A'&&listed.current_job_location==='N/A'&&listed.status==='partial',JSON.stringify(listed));

    main.innerHTML='<ol><li class="reusable-search__result-container"><a href="/in/unnamed-result/"></a><div class="entity-result__primary-subtitle">Visible headline</div></li></ol>';
    rows=E.findResultRows('person');
    const unnamed=U.normalizeLead(A.readListPerson(rows[0],'search',0,location.href));
    assert('valid profile identity with missing name is retained as explicit error',unnamed.url==='https://www.linkedin.com/in/unnamed-result'&&unnamed.person_name==='N/A'&&unnamed.status==='error',JSON.stringify(unnamed));

    route('/mynetwork/invite-connect/connections/');
    main.innerHTML=`<ul><li class="mn-connection-card"><a href="/in/casey-jones/"><span aria-hidden="true">Casey Jones</span></a><div class="mn-connection-card__occupation">Sales Director</div><div class="mn-connection-card__location">Phoenix, Arizona</div></li><li class="mn-connection-card"><a href="/in/casey-jones/"><span aria-hidden="true">Casey Jones</span></a><div class="mn-connection-card__occupation">Sales Director</div></li><li class="mn-connection-card"><a href="/in/ravi-shah/"><span aria-hidden="true">Ravi Shah</span></a><div class="mn-connection-card__occupation">Founder</div></li></ul>`;
    rows=E.findResultRows('person');
    assert('Connections adapter deduplicates repeated/virtualized identity',rows.length===2,`rows=${rows.length}`);
    const connection=A.readListPerson(rows[0],'connections',0,location.href);
    assert('Connections row does not put degree/button text into name',connection.person_name==='Casey Jones'&&!/message|connect|1st|2nd/i.test(connection.person_name),connection.person_name);

    route('/mynetwork/grow/');
    main.innerHTML=`<section><h2>People you may know</h2><ul><li class="discover-entity-type-card"><a href="/in/morgan-lee/"><span aria-hidden="true">Morgan Lee</span></a><div class="discover-entity-type-card__subtitle">Operations Manager</div></li></ul></section><section><h2>Explore Premium profiles</h2><li class="discover-entity-type-card"><a href="/in/premium-person/"><span aria-hidden="true">Premium Person</span></a></li></section>`;
    rows=E.findResultRows('person');
    assert('Grow adapter includes requested suggested people and excludes Premium promo',rows.length===1,`rows=${rows.length}`);

    route('/in/jane-doe/');
    main.innerHTML=`<div class="pv-text-details__left-panel"><h1>Jane Doe</h1><div class="text-body-medium">Staff Product Engineer at Acme</div><div class="text-body-small inline t-black--light break-words">Seattle, Washington, United States</div></div><section id="experience"><h2>Experience</h2><ul><li><div data-view-name="profile-component-entity"><h3><span class="t-bold"><span aria-hidden="true">Staff Product Engineer</span></span></h3><a href="/company/acme-inc/"><span aria-hidden="true">Acme Inc. · Full-time</span></a><span class="pvs-entity__caption-wrapper">Jan 2023 – Present · 3 yrs</span><span data-field="experience_location">Remote — United States</span></div></li><li><div data-view-name="profile-component-entity"><h3><span class="t-bold"><span aria-hidden="true">Product Engineer</span></span></h3><a href="/company/oldco/"><span aria-hidden="true">OldCo · Full-time</span></a><span class="pvs-entity__caption-wrapper">2019 – 2022</span><span data-field="experience_location">Chicago, Illinois</span></div></li></ul></section>`;
    const profile=A.extractProfilePerson(document,location.href); const normalized=U.normalizeLead(profile);
    assert('Profile header name/headline/location',normalized.person_name==='Jane Doe'&&normalized.headline==='Staff Product Engineer at Acme'&&normalized.location==='Seattle, Washington, United States',JSON.stringify({name:normalized.person_name,headline:normalized.headline,location:normalized.location}));
    assert('Current Experience fields all from same current entry',normalized.job_title==='Staff Product Engineer'&&normalized.company_name==='Acme Inc.'&&normalized.company_profile_url==='https://www.linkedin.com/company/acme-inc'&&normalized.current_job_period==='Jan 2023 – Present'&&normalized.current_job_location==='Remote — United States',JSON.stringify({title:normalized.job_title,company:normalized.company_name,companyUrl:normalized.company_profile_url,period:normalized.current_job_period,jobLocation:normalized.current_job_location}));
    assert('employment-type suffix removed from current company',normalized.company_name==='Acme Inc.'&&!normalized.company_name.includes('Full-time'),normalized.company_name);
    const partialProfile=A.extractProfilePerson(document,'https://www.linkedin.com/in/no-experience/');
    // Current fixture contains Experience: test the explicit missing-fields path by removing that section.
    main.innerHTML='<h1>No Experience Person</h1><div class="pv-text-details__left-panel"><div class="text-body-medium">Profile headline</div><div class="text-body-small inline t-black--light break-words">Dublin, Ireland</div></div>';
    const missing=U.normalizeLead(A.extractProfilePerson(document,'https://www.linkedin.com/in/no-experience/'));
    assert('missing Experience fields use exact N/A and partial status',missing.job_title==='N/A'&&missing.company_name==='N/A'&&missing.company_profile_url==='N/A'&&missing.current_job_period==='N/A'&&missing.current_job_location==='N/A'&&missing.status==='partial',JSON.stringify(missing));
    main.innerHTML='<section id="experience"><h2>Experience</h2><div class="text-body-medium break-words">Unrelated current-role-looking text</div><div class="text-body-small inline t-black--light break-words">Austin, Texas</div></section>';
    const headerMissing=U.normalizeLead(A.extractProfilePerson(document,'https://www.linkedin.com/in/header-missing/'));
    assert('header fields do not fall back to Experience text/location',headerMissing.headline==='N/A'&&headerMissing.location==='N/A'&&headerMissing.status==='error',JSON.stringify(headerMissing));

    // Regression check: original Sales Navigator people extraction path remains active.
    route('/sales/search/people?page=1');
    main.innerHTML=`<ol data-x-search-results-list><li class="artdeco-list__item" data-x-search-result="LEAD"><a data-anonymize="person-name" href="/sales/lead/opaque123,NAME_SEARCH,token">Sam Sales</a><span data-anonymize="title">Director of Business Development</span><a data-anonymize="company-name" href="/sales/company/9501">Example Sales Co</a><span data-anonymize="location">Fort Wayne, Indiana</span></li></ol>`;
    assert('Sales Navigator People mode preserved',E.detectMode()==='person'&&E.getPageContext().pageType==='sales-people');
    rows=E.findResultRows('person'); const salesPerson=U.normalizeLead(E.extractRecord(rows[0],0,'person'));
    assert('Sales Navigator People extractor preserved',salesPerson.person_name==='Sam Sales'&&salesPerson.job_title==='Director of Business Development'&&salesPerson.company_name==='Example Sales Co',JSON.stringify(salesPerson));
    // New 12-column Sales Navigator people layout, built from real Sales Navigator markup.
    main.innerHTML=`<ol data-x-search-results-list><li class="artdeco-list__item" data-x-search-result="LEAD"><a data-lead-search-result="profile-link-st5454" href="/sales/lead/ACwAAC_NWEgBpKPj5PJHq355-Z5RVhNbzzQMOq8,NAME_SEARCH,xdnu?_ntb=abc"><span data-anonymize="person-name"> Michael Noke </span></a><span class="artdeco-entity-lockup__degree" aria-hidden="true">·&nbsp;3rd</span><span data-anonymize="title">Sales Development Representative </span><a data-anonymize="company-name" href="/sales/company/2713134?_ntb=abc"> LegiStorm </a><span class="t-12" data-anonymize="location">United States</span><div class="artdeco-entity-lockup__metadata" data-anonymize="job-title"> 2 months in role <span aria-hidden="true" class="separator--pipe"></span> 2 months in company </div><span style="display: inline;">Synopsis (getsynopsis.ai), the AI data infrastruct<button id="ellipsis-button-ember5543-clamped-content" type="button" data-test-expand-button=""> … <span class="button-text">Show more</span></button></span></li></ol><div class="entity-hovercard-container"><div class="entity-hovercard"><a class="entity-hovercard__title entity-hovercard__title--company" href="https://www.linkedin.com/sales/company/2713134" data-anonymize="company-name">LegiStorm</a><span data-anonymize="location">Washington, District of Columbia, United States</span><a data-anonymize="company-size" href="/sales/search/people/list/employees-for-account/2713134?_ntb=x"> 50 employees </a></div></div>`;
    E._companyInfo.clear();
    const noke=U.normalizeLead(E.extractRecord(E.findResultRows('person')[0],0,'person'));
    assert('Sales Nav row: name/title/degree/location',noke.person_name==='Michael Noke'&&noke.job_title==='Sales Development Representative'&&noke.connectionDegree==='3rd'&&noke.location==='United States',JSON.stringify(noke));
    assert('Sales Nav row: normal LinkedIn URL derived from lead URL',noke.url==='https://www.linkedin.com/in/ACwAAC_NWEgBpKPj5PJHq355-Z5RVhNbzzQMOq8',noke.url);
    assert('Sales Nav row: company name and normal company URL',noke.company_name==='LegiStorm'&&noke.company_profile_url==='https://www.linkedin.com/company/2713134',JSON.stringify(noke));
    assert('Sales Nav row: tenure split into role and company',noke.yearsInRole==='2 months'&&noke.yearsInCompany==='2 months',JSON.stringify(noke));
    assert('Sales Nav row: employee count read from hover card, location not taken from it',noke.employeeCount==='50 employees'&&noke.location==='United States',JSON.stringify(noke));
    assert('Sales Nav row: About excludes the Show more control',noke.about==='Synopsis (getsynopsis.ai), the AI data infrastruct',noke.about);
    assert('Sales Nav row: Data Quality computed',noke.dataQuality&&noke.dataQuality.percent>=80,JSON.stringify(noke.dataQuality));
    route('/sales/search/companies?page=1');
    main.innerHTML=`<ol data-x-search-results-list><li class="artdeco-list__item"><a data-anonymize="company-name" href="/sales/company/95067953">Acme Account</a><span data-anonymize="industry">Software</span><a data-anonymize="company-size" href="#employees">50 employees</a><span data-anonymize="revenue">$2.5M - $5M</span></li></ol>`;
    assert('Sales Navigator Company mode preserved',E.detectMode()==='company'&&E.getPageContext().pageType==='sales-company');
    const company=E.extractRecord(E.findResultRows('company')[0],0,'company');
    assert('Sales Navigator Company fields preserved',company.companyName==='Acme Account'&&company.industry==='Software'&&company.employeeCount==='50 employees'&&company.revenue==='$2.5M - $5M',JSON.stringify(company));

    // Pagination fixture: URL changes first but stale rows must not be accepted.
    route('/search/results/people/?page=1');
    main.innerHTML=`<ol>${profileRow('page-one-a','Page One A','Headline A','LA')}${profileRow('page-one-b','Page One B','Headline B','LA')}</ol>`;
    nav.innerHTML='<button class="artdeco-pagination__button--next"><span class="artdeco-button__text">Next</span></button>';
    nav.querySelector('button').addEventListener('click',()=>{history.pushState({},'','/search/results/people/?page=2');setTimeout(()=>{main.innerHTML=`<ol>${profileRow('page-two-a','Page Two A','Headline A','NY')}${profileRow('page-two-b','Page Two B','Headline B','NY')}</ol>`;},180);});
    const descriptor=window.LXPagination.getPageDescriptor();
    const pageChange=await window.LXPagination.clickNextWithRetry(descriptor,{timeoutMs:2500,pageChangeRetries:1},null,()=>false);
    assert('pagination waits for new row signature rather than URL alone',pageChange.ok&&pageChange.waitedMs>=100&&window.LXExtractor.findResultRows('person')[0]?.textContent.includes('Page Two A'),JSON.stringify({ok:pageChange.ok,waitedMs:pageChange.waitedMs,reason:pageChange.reason}));

    // State-control regression with fake chrome.storage; no LinkedIn session is used.
    const ctl=window.LXController;
    await ctl.init(); ctl.state=C.STATES.COLLECTING; ctl.meta={...(await window.LXStorage.getMeta()),state:C.STATES.COLLECTING,searchKey:U.searchKey(location.href),recordType:'person'};
    await ctl.pause(); assert('Pause transitions to PAUSED',ctl.state===C.STATES.PAUSED,ctl.state);
    await ctl.resume(); assert('Resume transitions out of PAUSED',ctl.state===C.STATES.STARTING&&ctl.pauseRequested===false,ctl.state);
    await ctl.stop(); assert('Stop remains STOPPED',ctl.state===C.STATES.STOPPED,ctl.state);

    const personCols=U.getColumns('person').map(c=>c.label);
    const sample=U.normalizeLead({recordType:'person',url:'https://www.linkedin.com/in/safe-person/',person_name:'=Formula Safe',headline:'Engineer',location:'Dublin'});
    const csvSafe=U.csvEscape(sample.person_name);
    assert('CSV formula injection is neutralized',csvSafe.startsWith("'=Formula Safe"),csvSafe);
    const exportRows=window.LXExport._test.exportRows([sample],'person');
    assert('CSV/XLSX shared column order',JSON.stringify(personCols)===JSON.stringify(Object.keys(exportRows[0])));
    const bytes=window.LXExport._test.makeXlsx([sample],'person');
    let binary=''; for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,Math.min(i+8192,bytes.length)));
    document.getElementById('xlsx-base64').value=btoa(binary);
  } catch (error) { results.push({name:'Unhandled test exception',pass:false,detail:error?.stack||String(error)}); }
  document.getElementById('test-output').textContent=JSON.stringify({passed:results.filter(r=>r.pass).length,failed:results.filter(r=>!r.pass).length,results},null,2);
  document.getElementById('xlsx-base64').hidden=false;
})();
