# Sales Navigator + LinkedIn Extractor v3.7.0

## Scope

This is a targeted fix to the existing v3.5.0 project, not a replacement extension. It preserves the existing People/Company Sales Navigator architecture and adds page adapters for:

- Sales Navigator People search: `/sales/search/people`
- Sales Navigator Company/Account search: `/sales/search/companies` and `/sales/search/accounts`
- Standard LinkedIn People Search: `/search/results/people`
- My Network Connections: `/mynetwork/invite-connect/connections` and `/mynetwork/connections`
- A manually opened person profile: `/in/<profile-slug>` for profile enrichment only

People Search and Connections extract only fields visibly associated with a person card. They do not pretend a list card contains a complete Experience history. To enrich current-position fields, open the person’s profile and use **Extract Current Page Live**. The extension does not automatically open profiles.

## Sales Navigator People export (v3.7.0)

On `/sales/search/people` the CSV/XLSX columns are: Person Name, Job Title, Person LinkedIn URL, Company Name, Company LinkedIn URL, Location, Employee Count, Connection Degree, Years in Role, Years in Company, About, Data Quality. See `CHANGELOG_v3_7_0.md`.

## Person export schema (profile pages)

CSV and XLSX use the same ten fields, in this exact order:

`url, person_name, job_title, company_name, company_profile_url, current_job_period, headline, location, current_job_location, status`

Unavailable values export as `N/A`. List views normally supply identity and visible list fields only; current-position title/company/company URL/period/work-location are filled only when a profile Experience entry exposes them together. `status` is `ok`, `partial`, or `error`. The current Experience entry is selected by its current/present period; company, title, period, and role location are read from that same entry. Employment-type suffixes are removed from company names. If header name is unavailable but the profile URL is usable, the profile is retained with `person_name=N/A` and `status=error` rather than silently disappearing.

Company extraction remains on its existing Sales Navigator adapter and retains its company fields.

## Collection, pagination, and persistence

- Record persistence is owned by the extension-origin IndexedDB in the MV3 service worker, so the LinkedIn content script and popup use the same database through a sender-validated message bridge. Legacy records in the older LinkedIn host-origin database are imported once; the shared record pipeline, deduplication, auto-save, pause/resume/stop, logging, CSV/JSON, and safety controls are retained.
- List records are collected as visible rows appear. Virtualized lists use repeated identity-based sweeps; new page types are not assumed to contain exactly 25 records.
- Sales Navigator uses its known 25-result page target unless the view exposes a more specific range. A standard LinkedIn view with no exposed total uses a settled-list audit instead of an invented 25-result target.
- The controller will not knowingly advance after a page audit reports unresolved rows or incomplete coverage. An unknown-total list is only considered settled after repeated sweeps stop discovering new unique identities.
- New pages require a changed row identity/signature, not merely a URL change.
- Explicit Resume waits for a paused run to finish its shutdown before restoring it, including when automatic resume is disabled. Auto-resume on reload remains governed by its setting and staleness window.

## Safety

The extension does not bypass CAPTCHA, identity verification, checkpoints, authentication factors, or platform limits. Explicit security markers and challenge dialogs stop the run. Generic words found in ordinary people/company result text are not, by themselves, treated as account restrictions. No extension can guarantee that LinkedIn will never restrict an account.

## Exports

- **CSV:** UTF-8 BOM for spreadsheet compatibility; formula-like leading values are escaped.
- **XLSX:** native workbook with the same columns/order/values as CSV, text cells, and `N/A` handling.
- **JSON:** existing record-object export plus metadata is retained.

## Regression tests

Run the deterministic tests with Node:

```bash
node tests/node-regression.test.js
node tests/background-bridge.test.js
node tests/storage-bridge.test.js
node tests/scroll-pagination.test.js
node tests/scroll-loop.test.js
node tests/storage-upsert.test.js
node tests/settings-validation.test.js
```

See `CHANGELOG_v3_7_0.md` for the latest change.

A DOM fixture suite is included at `tests/fixture-tests.html` and `tests/fixture-tests.js`. It covers page contexts, intended-section filtering, list fields, profile header/current Experience separation, missing-field handling, Sales Navigator People/Company regressions, delayed page navigation, pause/resume/stop, and export column consistency. It must be run in a normal browser against the local fixture HTML. In this build environment, Chromium navigation was blocked by the sandbox policy, so this DOM suite was added but not reported as executed.

## Validation status for this package

- JavaScript syntax checks: executed for all extension and test JavaScript files.
- Node regression suite: 17 passed.
- Background bridge authorization suite: 3 passed.
- Storage bridge routing suite: 2 passed.
- XLSX package: generated by the actual export module and opened successfully with `openpyxl`; the ten ordered headers and an exported data row were checked.
- Manifest JSON and all manifest script references: validated.
- ZIP integrity and root manifest: validated during packaging.
- Live LinkedIn execution: **not performed**. LinkedIn’s live DOM can change, so use the supplied fixtures and perform a cautious end-to-end test in the target account.


## v3.5.7 changes
See `CHANGELOG_v3_5_4.md`. The popup displays records only for the active page type and active search/filter URL. Older records remain stored but are hidden when the current view/filter changes. Standard People Search and Connections use separate visible-field table layouts. Grow extraction is no longer supported.


## v3.5.7 changes
- Sales Navigator People exports now include separate `url` (normal LinkedIn profile URL) and `sales_navigator_url` columns.
- The extractor no longer treats an opaque `/sales/lead/ACw...` identifier as a valid `/in/ACw...` profile URL. The normal URL is only populated from an actual matching `/in/` link in the same card.
- CSV, XLSX, and clipboard output use the active page's column schema, including the two Sales Navigator URL fields.
- Added regression tests for both URL formats and for preventing fabricated normal profile URLs.
- Automated tests and static checks passed; live LinkedIn browser verification was not performed.


## v3.5.7 changes
- Scroll-container selection now chooses the usable result-list ancestor with the largest scroll range, rather than the first nested overflow wrapper. This targets the Sales Navigator symptom where only 10–12 of 25 expected people were captured.
- Next-page detection accepts exact Next/Next page labels, including aria-label/title labels and role=button controls, on supported result views even when LinkedIn uses generated CSS classes.
- Added deterministic regression coverage for nested scroll containers and Sales Navigator Next controls.
- Live LinkedIn browser verification remains outstanding.


## v3.5.9
- Renamed the top counter to Saved People / Saved Companies so it is not confused with current-page visible rows.
- Normal LinkedIn URL lookup checks for an exact-name matching `/in/` anchor inside the Sales Navigator result card and elsewhere in the currently rendered DOM.
