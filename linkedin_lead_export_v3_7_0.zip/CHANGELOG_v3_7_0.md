# v3.7.0 — New 12-column Sales Navigator People export

## Export layout (Sales Navigator People search only)
Person Name | Job Title | Person LinkedIn URL | Company Name | Company LinkedIn URL | Location |
Employee Count | Connection Degree | Years in Role | Years in Company | About | Data Quality

- The separate "Sales Navigator URL" column and the profile-only columns (current_job_period, headline,
  current_job_location, status) are no longer exported for this page type. They are still kept on the stored
  record and in the JSON export. Other page types (LinkedIn search, Connections, profile, Companies) are unchanged.
- Person LinkedIn URL: `/sales/lead/<ID>,NAME_SEARCH,<token>` becomes `https://www.linkedin.com/in/<ID>`.
- Company LinkedIn URL: `/sales/company/<id>` becomes `https://www.linkedin.com/company/<id>`.
- Missing values export as `N/A`. Employee Count keeps the word "employees" (e.g. `11-50 employees`) so
  spreadsheets do not turn ranges like `2-10` into dates.
- Data Quality is calculated by the extension (percentage of the 9 data fields present, plus complete/partial/weak).

## Extraction (extractor.js, selectors.js)
- Years in Role / Years in Company are parsed from the "2 months in role | 2 months in company" line, including
  "1 year 3 months", "10+ years" and "Less than a year".
- Job Title no longer picks up the tenure line (it shares `data-anonymize="job-title"`).
- Location, employee count and About are never read from the floating company hover card by mistake.
- About is read without the "… Show more" control. New setting expands clamped About text first.
- Employee Count is not in the result row; Sales Navigator only shows it in the company hover card. New
  setting hovers each unseen company once per page (capped, sequential, randomized pause), reads the card,
  caches by company id, and reuses it for every other person at the same company.
- The old `.artdeco-entity-lockup__metadata span:nth-child(1)` employee-count fallback was removed.

## Settings
- "Read employee count from company hover card" (default on), "Expand Show more in About" (default on).

## Tests
- Updated sales-people column/export tests; added tenure, employee-count and N/A/Data Quality tests (29 pass).
- Added a browser fixture built from the real markup in tests/fixture-tests.js (not executed in the build sandbox).
