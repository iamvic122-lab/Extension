/* extractor.js — route-aware People/Company discovery with resilient field extraction. */
(function attachExtractor(root) {
  const U = root.LX, C = root.LXConstants, SEL = root.LXSelectors, Logger = root.LXLogger, Adapters = root.LXLinkedInAdapters;

  const Extractor = {
    _activeResultSelector: new Map(),
    _modeCache: { href: '', mode: null },
    _lastResultSelector: null,

    _q(node, selectors) {
      for (const selector of selectors || []) {
        try { const el = node?.querySelector(selector); if (el) return el; } catch (error) { Logger.debug('Invalid selector ignored', selector, error?.message || error); }
      }
      return null;
    },
    _qAll(node, selector) { try { return Array.from(node?.querySelectorAll(selector) || []); } catch (_) { return []; } },
    _text(element) { return element ? U.cleanText(element.textContent) : ''; },
    _config: { enrichCompanyHovercard: true, expandAbout: true, hovercardWaitMs: 1800, maxHovercardsPerPage: 30 },
    _companyInfo: new Map(),
    _hoverAttempted: new Set(),
    _hoverBusy: false,
    _hoverCount: 0,

    configure(settings = {}) {
      for (const key of Object.keys(this._config)) if (settings[key] !== undefined) this._config[key] = settings[key];
      return this._config;
    },
    resetEnrichment() { this._hoverAttempted.clear(); this._hoverCount = 0; },

    _inHovercard(el) { return !!el?.closest?.('.entity-hovercard, .entity-hovercard-container'); },
    // First match that is part of the result row itself, never the floating company hover card.
    _qRow(node, selectors) {
      for (const selector of selectors || []) {
        try { const el = Array.from(node?.querySelectorAll(selector) || []).find((candidate) => !this._inHovercard(candidate)); if (el) return el; }
        catch (error) { Logger.debug('Invalid selector ignored', selector, error?.message || error); }
      }
      return null;
    },

    // Employee count must look like a head-count, never a tenure string such as "2 months in role".
    _cleanEmployeeCount(value) {
      const text = U.cleanText(value).split('·')[0].trim();
      if (!text || !/\d/.test(text) || /\b(?:in role|in company|months?|years?)\b/i.test(text)) return '';
      return text;
    },

    // "2 months in role | 2 months in company" -> { role:'2 months', company:'2 months' }
    parseTenure(text) {
      const value = U.cleanText(text);
      const span = '(less than a year|\\d+\\+?\\s*years?(?:\\s*\\d+\\s*months?)?|\\d+\\s*months?)';
      const role = value.match(new RegExp(`${span}\\s+in\\s+role`, 'i'));
      const company = value.match(new RegExp(`${span}\\s+in\\s+company`, 'i'));
      const tidy = (m) => m ? U.cleanText(m[1]).replace(/^less than a year$/i, 'Less than a year') : '';
      return { role: tidy(role), company: tidy(company) };
    },

    _readTenure(row) {
      for (const selector of SEL.tenureMetadata || []) {
        for (const el of this._qAll(row, selector)) {
          if (this._inHovercard(el)) continue;
          const text = this._text(el);
          if (/\bin\s+(?:role|company)\b/i.test(text)) { const parsed = this.parseTenure(text); if (parsed.role || parsed.company) return parsed; }
        }
      }
      return this.parseTenure(this._text(row));
    },

    // About text without the "… Show more" control.
    _readAbout(row) {
      const button = this._qRow(row, SEL.aboutExpandButton);
      let el = button ? button.closest('span, p, div') : this._qRow(row, SEL.about);
      if (!el) return '';
      let text = '';
      try {
        const clone = el.cloneNode(true);
        clone.querySelectorAll('button').forEach((node) => node.remove());
        text = this._text(clone);
      } catch (_) { text = this._text(el); }
      return text.replace(/\s*(?:…|\.\.\.)\s*(?:Show more|Show less)?\s*$/i, '').replace(/\s*Show (?:more|less)\s*$/i, '').trim();
    },

    // Read every company hover card currently in the DOM into the per-company cache.
    scanHovercards() {
      for (const card of this._qAll(document, SEL.hovercard.join(','))) {
        const link = this._q(card, SEL.hovercardCompanyLink);
        const id = U.extractCompanyId(link?.getAttribute('href') || '') || (card.querySelector('[data-anonymize="company-size"]')?.getAttribute('href') || '').match(/employees-for-account\/(\d+)/)?.[1] || '';
        const employeeCount = this._cleanEmployeeCount(this._text(card.querySelector('[data-anonymize="company-size"]')));
        if (!id || !employeeCount) continue;
        this._companyInfo.set(String(id), {
          employeeCount, name: this._text(link),
          industry: this._text(card.querySelector('[data-anonymize="industry"]')),
          location: this._text(card.querySelector('[data-anonymize="location"]')), at: Date.now()
        });
      }
    },
    getCompanyInfo(companyId, companyName = '') {
      if (!this._companyInfo.size) this.scanHovercards();
      let info = companyId ? this._companyInfo.get(String(companyId)) : null;
      if (!info && companyId) { this.scanHovercards(); info = this._companyInfo.get(String(companyId)) || null; }
      if (!info && companyName) {
        const wanted = U.cleanText(companyName).toLowerCase();
        for (const value of this._companyInfo.values()) if (value.name && U.cleanText(value.name).toLowerCase() === wanted) return value;
      }
      return info || null;
    },

    _fire(el, type, init = {}) {
      try {
        const rect = el.getBoundingClientRect();
        el.dispatchEvent(new MouseEvent(type, { bubbles: type !== 'mouseenter' && type !== 'mouseleave', cancelable: true, view: window, clientX: rect.left + rect.width / 2, clientY: rect.top + rect.height / 2, ...init }));
      } catch (_) {}
    },

    // Best-effort, sequential and capped: hover each *unseen* company link once, as a person would,
    // to let Sales Navigator render its company hover card, then read the head-count from it.
    async enrichRows(rows, { shouldCancel = () => false } = {}) {
      if (this._hoverBusy || !this._config.enrichCompanyHovercard) return;
      this._hoverBusy = true;
      try {
        for (const row of rows || []) {
          if (shouldCancel() || this._hoverCount >= Number(this._config.maxHovercardsPerPage || 30)) break;
          if (this._q(row, SEL.hovercard) || this._qRow(row, SEL.companySize)) continue;
          const link = this._qRow(row, SEL.companyLink);
          const companyId = U.extractCompanyId(link?.getAttribute('href') || '');
          if (!link || !companyId || this._hoverAttempted.has(companyId) || this._companyInfo.has(companyId)) continue;
          this._hoverAttempted.add(companyId); this._hoverCount += 1;
          this._fire(link, 'mouseenter'); this._fire(link, 'mouseover');
          const deadline = Date.now() + Math.max(600, Number(this._config.hovercardWaitMs) || 1800);
          while (Date.now() < deadline && !shouldCancel()) {
            await new Promise((resolve) => setTimeout(resolve, 120));
            this.scanHovercards();
            if (this._companyInfo.has(companyId)) break;
          }
          this._fire(link, 'mouseout'); this._fire(link, 'mouseleave');
          await new Promise((resolve) => setTimeout(resolve, U.randomBetween(350, 900)));
        }
      } catch (error) { Logger.debug('Hover card enrichment failed', error?.message || error); }
      finally { this._hoverBusy = false; }
    },

    // Expand clamped About text in place (local UI toggle; no navigation).
    async expandAbout(rows, { shouldCancel = () => false } = {}) {
      if (!this._config.expandAbout) return;
      for (const row of rows || []) {
        if (shouldCancel()) break;
        const button = this._qRow(row, SEL.aboutExpandButton);
        if (!button || button.__lxExpanded || !/show more/i.test(this._text(button))) continue;
        button.__lxExpanded = true;
        try { button.click(); } catch (_) {}
        await new Promise((resolve) => setTimeout(resolve, 80));
      }
    },

    getPageContext() {
      try { return Adapters?.detectContext(window.location.href, document) || { pageType:'unsupported', mode:null, isListView:false, isProfileView:false, usesSalesNavigator:false }; }
      catch (_) { return { pageType:'unsupported', mode:null, isListView:false, isProfileView:false, usesSalesNavigator:false }; }
    },

    detectMode() {
      const href = window.location.href;
      if (this._modeCache.href === href && this._modeCache.mode) return this._modeCache.mode;
      const context = this.getPageContext();
      const mode = context.mode || null;
      this._modeCache = { href, mode };
      return mode;
    },

    invalidateCache(mode = null) {
      if (mode) this._activeResultSelector.delete(mode); else this._activeResultSelector.clear();
      this._modeCache = { href: '', mode: null };
    },

    _normalizePersonRowCandidate(row) { return row?.nodeType === 1 && this._q(row, SEL.personLink) ? row : null; },
    _normalizeCompanyRowCandidate(row) { return row?.nodeType === 1 && this._q(row, SEL.companySearchLink) ? row : null; },

    _dedupeRows(rows, mode) {
      const seen = new Set(), result = [];
      for (const row of rows || []) {
        const key = U.stableRowKey(row, mode) || this.rowSignature(row, mode);
        if (!key || seen.has(key)) continue;
        seen.add(key); row.__lxSig = key; result.push(row);
      }
      return result;
    },

    _querySelectorRows(selector, mode) {
      try {
        const normalizer = mode === C.RECORD_TYPES.COMPANY ? this._normalizeCompanyRowCandidate.bind(this) : this._normalizePersonRowCandidate.bind(this);
        return this._dedupeRows(Array.from(document.querySelectorAll(selector)).map(normalizer).filter(Boolean), mode);
      } catch (error) { Logger.debug('Result selector failed', selector, error?.message || error); return []; }
    },

    _rowsFromAnchors(mode) {
      const rows = new Set();
      const anchorSelector = mode === C.RECORD_TYPES.COMPANY ? 'a[data-anonymize="company-name"][href*="/sales/company/"], a[href*="/sales/company/"]' : 'a[data-anonymize="person-name"][href*="/sales/lead/"], a[href*="/sales/lead/"]';
      try {
        this._qAll(document, anchorSelector).forEach((anchor) => {
          const row = anchor.closest('li') || anchor.closest('article') || anchor.closest('[role="listitem"]') || anchor.parentElement;
          if (row) rows.add(row);
        });
      } catch (_) {}
      return [...rows];
    },

    findResultRows(mode = this.detectMode()) {
      const resolvedMode = mode || C.RECORD_TYPES.PERSON;
      const context = this.getPageContext();
      if (context.mode && !context.usesSalesNavigator && Adapters) {
        return Adapters.findRows(context.pageType, document);
      }
      if (!context.mode) return [];
      const selectors = resolvedMode === C.RECORD_TYPES.COMPANY ? SEL.companyResultRow : SEL.personResultRow;
      const normalizer = resolvedMode === C.RECORD_TYPES.COMPANY ? this._normalizeCompanyRowCandidate.bind(this) : this._normalizePersonRowCandidate.bind(this);
      const cached = this._activeResultSelector.get(resolvedMode);
      if (cached) {
        const current = this._querySelectorRows(cached, resolvedMode);
        if (current.length) { this._lastResultSelector = cached; return current; }
        this._activeResultSelector.delete(resolvedMode);
      }

      const scored = [];
      for (const selector of selectors) {
        const rows = this._querySelectorRows(selector, resolvedMode);
        if (rows.length) scored.push({ selector, rows });
      }
      const fallback = this._dedupeRows(this._rowsFromAnchors(resolvedMode).map(normalizer).filter(Boolean), resolvedMode);
      if (fallback.length) scored.push({ selector: `fallback:${resolvedMode}-link-anchor`, rows: fallback });

      if (!scored.length) { this._lastResultSelector = null; return []; }
      scored.sort((a, b) => b.rows.length - a.rows.length);
      this._activeResultSelector.set(resolvedMode, scored[0].selector);
      this._lastResultSelector = scored[0].selector;
      return scored[0].rows;
    },

    signature(rows = this.findResultRows(), mode = this.detectMode()) {
      const resolvedMode = mode || C.RECORD_TYPES.PERSON;
      return rows.map((row) => row.__lxSig || this.rowSignature(row, resolvedMode)).filter(Boolean).slice(0, 20).join('|');
    },

    rowSignature(row, mode = this.detectMode()) {
      const resolvedMode = mode || C.RECORD_TYPES.PERSON;
      const context = this.getPageContext();
      if (context.isProfileView && resolvedMode === C.RECORD_TYPES.PERSON) {
        const profileId = U.extractLeadIdentity(window.location.href);
        if (profileId) return `person:${profileId}`;
      }
      const key = U.stableRowKey(row, resolvedMode);
      if (key) return key;
      if (resolvedMode === C.RECORD_TYPES.COMPANY) return this._text(this._q(row, SEL.companyName));
      return this._text(this._q(row, SEL.personName));
    },

    hasBlockingLoader() {
      const rootNode = this.observationRoot();
      for (const selector of SEL.loading) {
        try {
          if ([...rootNode.querySelectorAll(selector)].some((element) => {
            const style = getComputedStyle(element), rect = element.getBoundingClientRect();
            return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
          })) return true;
        } catch (_) {}
      }
      return false;
    },

    observationRoot(mode = this.detectMode()) {
      const row = this.findResultRows(mode)[0];
      return row?.closest('main,section,ol,ul') || document.body;
    },

    _extractCompanyAbout(row) {
      const button = this._q(row, SEL.companyAboutExpandButton);
      const parent = button?.parentElement;
      if (parent) {
        try { const clone = parent.cloneNode(true); clone.querySelectorAll('button').forEach((node) => node.remove()); const value = this._text(clone); if (value) return value.replace(/(?:…|\.\.\.)\s*$/i, '').trim(); } catch (_) {}
      }
      const paragraphs = this._qAll(row, 'p, span').map((el) => this._text(el)).filter((value) => value.length > 20 && !/show more/i.test(value));
      return paragraphs[0] || '';
    },

    _extractCompanyLogo(row, companyName) {
      const target = U.cleanText(companyName).toLowerCase();
      const images = this._qAll(row, SEL.companyLogo);
      const preferred = images.find((img) => U.cleanText(img.getAttribute('alt') || '').toLowerCase() === target);
      const fallback = images.find((img) => /^https:\/\/(?:[^/]+\.)?licdn\.com\//i.test(img.getAttribute('src') || ''));
      return U.normalizeMediaUrl((preferred || fallback)?.getAttribute('src') || '');
    },

    extractCompany(row, index = 0) {
      if (!row) return null;
      const companyA = this._q(row, SEL.companySearchLink);
      if (!companyA) return null;
      const companyLinkedInUrl = U.convertCompanyUrl(companyA.getAttribute('href') || '');
      const companyName = this._text(this._q(row, SEL.companyName)) || this._text(companyA);
      if (!companyLinkedInUrl || !companyName) return null;
      let employeeCount = this._text(this._q(row, SEL.companySize));
      if (employeeCount && !/\d/.test(employeeCount)) employeeCount = '';
      let revenue = this._text(this._q(row, SEL.revenue));
      if (/^more info$/i.test(revenue)) revenue = '';
      return U.normalizeLead({
        recordType: C.RECORD_TYPES.COMPANY,
        companyName, companyLinkedInUrl, companyId: U.extractCompanyId(companyLinkedInUrl),
        industry: this._text(this._q(row, SEL.industry)), employeeCount, revenue,
        about: this._extractCompanyAbout(row), companyProfileImageUrl: this._extractCompanyLogo(row, companyName),
        sourceRow: index + 1, capturedAt: new Date().toISOString(), capturedFromUrl: window.location.href
      });
    },

    extractPerson(row, index = 0) {
      if (!row) return null;
      const context = this.getPageContext();
      if (context.isProfileView && Adapters) {
        const enriched = Adapters.extractProfilePerson(document, window.location.href);
        return enriched ? U.normalizeLead({ ...enriched, sourceRow:index + 1 }) : null;
      }
      if (context.pageType && !context.usesSalesNavigator && Adapters) {
        const listRecord = Adapters.readListPerson(row, context.pageType, index, window.location.href);
        return listRecord ? U.normalizeLead(listRecord) : null;
      }
      const personA = this._q(row, SEL.personLink);
      if (!personA) return null;
      const primaryHref = personA.getAttribute('href') || '';
      const salesNavigatorUrl = U.normalizeSalesNavigatorUrl(primaryHref);
      const isUsablePersonName = (value) => {
        const name = U.cleanText(value || '').replace(/\s*[·•]\s*(?:1st|2nd|3rd|\d+(?:st|nd|rd)?)(?:\s+connection)?\s*$/i, '').trim();
        if (!name || name.length > 100) return false;
        if (/^(?:view profile|open profile|profile|out of network|connect|message|follow|save|see open roles|linkedin member|member)$/i.test(name)) return false;
        if (/\b(?:mutual connection|other mutual connections|is hiring|see open roles)\b/i.test(name)) return false;
        return true;
      };
      const nameCandidates = [];
      for (const selector of SEL.personName || []) {
        try {
          const candidate = row.querySelector(selector);
          const value = this._text(candidate);
          if (value) nameCandidates.push(value);
        } catch (_) {}
      }
      for (const candidate of [personA.getAttribute?.('data-anonymize') === 'person-name' ? this._text(personA) : '', personA.getAttribute?.('aria-label'), personA.getAttribute?.('title'), this._text(personA)]) {
        if (candidate) nameCandidates.push(candidate);
      }
      const personName = nameCandidates.find(isUsablePersonName) || '';
      // Sales Navigator sometimes renders an OUT_OF_NETWORK placeholder whose
      // only label is "View profile". It is not a person record and must not be
      // exported as a lead with a fabricated name.
      if (!isUsablePersonName(personName)) return null;
      // Preserve the established export behavior: the first URL column is the
      // /in/<lead-id> form derived from the Sales Navigator lead URL, while the
      // second column retains the original /sales/lead/... URL unchanged.
      // Prefer a real matching /in/ anchor if LinkedIn exposes one; otherwise
      // convert the Sales Navigator lead identity using U.convertLeadUrl.
      const normalizePersonLabel = (value) => U.cleanText(value || '')
        .replace(/\s*[·•]\s*(?:1st|2nd|3rd|\d+(?:st|nd|rd)?)(?:\s+connection)?\s*$/i, '')
        .replace(/\s+/g, ' ').trim().toLowerCase();
      const isMatchingPersonAnchor = (anchor) => {
        const labels = [this._text(anchor), anchor.getAttribute('aria-label') || '', anchor.getAttribute('title') || '', this._text(anchor.querySelector?.('[data-anonymize="person-name"]'))]
          .map(normalizePersonLabel).filter(Boolean);
        return labels.includes(normalizePersonLabel(personName));
      };
      // Prefer a same-person profile link in the card. Some layouts also render
      // a matching /in/ link elsewhere in the current DOM (e.g. a detail surface).
      const normalProfileAnchors = this._qAll(row, 'a[href*="/in/"]');
      let matchingNormalAnchor = normalProfileAnchors.find(isMatchingPersonAnchor);
      if (!matchingNormalAnchor) matchingNormalAnchor = this._qAll(document, 'a[href*="/in/"]').find(isMatchingPersonAnchor) || null;
      const normalProfileHref = matchingNormalAnchor?.getAttribute('href') || (U.isNormalProfileUrl(primaryHref) ? primaryHref : '');
      const personLinkedInUrl = U.convertLeadUrl(normalProfileHref || salesNavigatorUrl || primaryHref);
      if ((!personLinkedInUrl && !salesNavigatorUrl) || !personName) return null;

      const companyA = this._q(row, SEL.companyLink);
      const companyName = this._text(this._q(row, SEL.companyName)) || this._text(companyA);
      const companyLinkedInUrl = companyA ? U.convertCompanyUrl(companyA.getAttribute('href') || '') : '';
      let jobTitle = '';
      for (const selector of SEL.jobTitle) {
        const el = this._qAll(row, selector).find((candidate) => !this._inHovercard(candidate) && !/\bin\s+(?:role|company)\b/i.test(this._text(candidate)));
        if (el) { jobTitle = this._text(el); break; }
      }
      if (jobTitle) jobTitle = jobTitle.split(/\d+\s*(?:year|month)|in role|in company/i)[0].replace(/[,·•]$/, '').trim();
      if (jobTitle && companyName) {
        const marker = ` at ${companyName}`.toLowerCase(); const at = jobTitle.toLowerCase().lastIndexOf(marker);
        if (at > 0) jobTitle = jobTitle.slice(0, at).trim();
      }
      if (!jobTitle) {
        const candidates = this._qAll(row, 'span, div').map((el) => this._text(el)).filter(Boolean).filter((text) => text !== personName && text !== companyName && text.length >= 2 && text.length < 120);
        const skip = /^(1st|2nd|3rd|3\+|connect|message|save|premium|open profile|view profile)$/i;
        jobTitle = candidates.find((text) => !skip.test(text) && !/^\d+\s*(year|month|employee)/i.test(text)) || '';
      }

      const tenure = this._readTenure(row);
      let connectionDegree = this._text(this._q(row, SEL.connectionDegree));
      const degreeMatch = connectionDegree.match(/(1st|2nd|3rd|3\+|Out of network|Following|You)/i); if (degreeMatch) connectionDegree = degreeMatch[1];
      const companyId = U.extractCompanyId(companyLinkedInUrl);
      let employeeCount = this._cleanEmployeeCount(this._text(this._qRow(row, SEL.employeeCount)));
      if (!employeeCount && (companyId || companyName)) employeeCount = this.getCompanyInfo(companyId, companyName)?.employeeCount || '';
      const about = this._readAbout(row);

      return U.normalizeLead({
        recordType: C.RECORD_TYPES.PERSON, personName, jobTitle, companyName,
        location: this._text(this._qRow(row, SEL.location)), employeeCount, connectionDegree,
        premium: !!this._q(row, SEL.premiumBadge), about,
        yearsInRole: tenure.role, yearsInCompany: tenure.company,
        personLinkedInUrl, salesNavigatorUrl, url: personLinkedInUrl || 'N/A', sales_navigator_url: salesNavigatorUrl || 'N/A',
        companyLinkedInUrl, leadId: U.extractLeadId(salesNavigatorUrl || personLinkedInUrl), companyId: U.extractCompanyId(companyLinkedInUrl),
        sourceRow: index + 1, capturedAt: new Date().toISOString(), capturedFromUrl: window.location.href
      });
    },

    extractRecord(row, index = 0, mode = this.detectMode()) { return mode === C.RECORD_TYPES.COMPANY ? this.extractCompany(row, index) : this.extractPerson(row, index); },
    extractLead(row, index = 0, mode = this.detectMode()) { return this.extractRecord(row, index, mode); },

    extractAll(options = {}) {
      const mode = options.mode || this.detectMode() || C.RECORD_TYPES.PERSON;
      const rows = this.findResultRows(mode), retryCount = Math.max(1, Math.min(6, Number(options.retryCount) || 3));
      const records = [], seen = new Set(), failures = [];
      rows.forEach((row, index) => {
        let record = null, lastError = null;
        for (let attempt = 1; attempt <= retryCount; attempt += 1) {
          try { record = this.extractRecord(row, index, mode); if (!record) throw new Error(`Required ${mode} identity was not available.`); lastError = null; break; }
          catch (error) { lastError = error; Logger.debug('Row extraction retry', mode, index + 1, attempt, error?.message || error); }
        }
        if (lastError) { failures.push({ row: index + 1, rowKey: U.stableRowKey(row, mode), message: lastError.message || 'Unknown extraction error', attempts: retryCount }); return; }
        const key = U.recordKey(record); if (!key || seen.has(key)) return; seen.add(key); records.push(record);
      });
      return { mode, records, leads: records, rowsFound: rows.length, failures, selector: this._lastResultSelector };
    }
  };
  root.LXExtractor = Extractor;
})(typeof window !== 'undefined' ? window : globalThis);
