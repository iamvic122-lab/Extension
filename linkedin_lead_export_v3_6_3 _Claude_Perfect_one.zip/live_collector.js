/* live_collector.js — incremental observer with row-level coverage accounting. */
(function attachLiveCollector(root) {
  const U=root.LX,C=root.LXConstants,S=root.LXStorage,Extractor=root.LXExtractor,Logger=root.LXLogger;
  class LiveCollector {
    constructor(){this.active=false;this.pageKey='';this.mode=C.RECORD_TYPES.PERSON;this.observer=null;this.scanTimer=null;this.flushTimer=null;this.reconcileTimer=null;this.scanQueued=false;this.flushRunning=false;this.lastScanAt=0;this.pending=new Map();this.revisions=new Map();this.pageKeys=new Set();this.observedRowKeys=new Set();this.unresolvedRowKeys=new Set();this.unresolvedDetails=new Map();this.stats={added:0,updated:0,duplicates:0,errors:0,seen:0,scans:0};this.onSaved=null;this.waiters=[];}

    start(pageKey,mode=C.RECORD_TYPES.PERSON,onSaved=null){
      this.stop({preserveStats:false});this.active=true;this.pageKey=String(pageKey||U.pageKey(window.location.href));this.mode=mode===C.RECORD_TYPES.COMPANY?C.RECORD_TYPES.COMPANY:C.RECORD_TYPES.PERSON;this.onSaved=typeof onSaved==='function'?onSaved:null;
      this.stats={added:0,updated:0,duplicates:0,errors:0,seen:0,scans:0};this.pending.clear();this.revisions.clear();this.pageKeys.clear();this.observedRowKeys.clear();this.unresolvedRowKeys.clear();this.unresolvedDetails.clear();
      try{this.observer=new MutationObserver((mutations)=>this._handleMutations(mutations));this.observer.observe(document.documentElement||document,{subtree:true,childList:true,characterData:true,attributes:false});}catch(error){Logger.warning('Live collector observer unavailable',error?.message||error);}
      this.scanNow();
      const reconcileMs=Math.max(700,Number(C.DEFAULTS.liveReconcileMs)||1400);this.reconcileTimer=setTimeout(function tick(){if(!this.active)return;this.scanNow();this.reconcileTimer=setTimeout(tick.bind(this),reconcileMs);}.bind(this),reconcileMs);
      return this.snapshot();
    }

    stop({preserveStats=true}={}){this.active=false;this.observer?.disconnect();this.observer=null;if(this.scanTimer)clearTimeout(this.scanTimer);if(this.flushTimer)clearTimeout(this.flushTimer);if(this.reconcileTimer)clearTimeout(this.reconcileTimer);this.scanTimer=null;this.flushTimer=null;this.reconcileTimer=null;this.scanQueued=false;if(!preserveStats){this.stats={added:0,updated:0,duplicates:0,errors:0,seen:0,scans:0};this.pending.clear();this.revisions.clear();this.pageKeys.clear();this.observedRowKeys.clear();this.unresolvedRowKeys.clear();this.unresolvedDetails.clear();}this._resolveWaitersIfIdle();}

    snapshot(){return {pageKey:this.pageKey,mode:this.mode,recordType:this.mode,active:this.active,...this.stats,uniquePageRecords:this.pageKeys.size,uniquePageLeads:this.pageKeys.size,observedRows:this.observedRowKeys.size,unresolvedRows:this.unresolvedRowKeys.size,unresolvedCount:this.unresolvedRowKeys.size,pending:this.pending.size,queueBusy:this.flushRunning};}
    getUniquePageCount(){return this.pageKeys.size;}
    getPageKeys(){return new Set(this.pageKeys);}
    getObservedRowCount(){return this.observedRowKeys.size;}
    getUnresolvedCount(){return this.unresolvedRowKeys.size;}
    getUnresolvedRows(){return new Map(this.unresolvedDetails);}

    scanNow(){
      if(!this.active)return this.snapshot();this.stats.scans+=1;this.lastScanAt=Date.now();let rows=[];
      try{rows=Extractor.findResultRows(this.mode);}catch(error){Logger.warning('Live collector row discovery failed',error?.message||error);return this.snapshot();}
      const currentRowKeys=new Set();
      rows.forEach((row,index)=>{
        const rowKey=U.stableRowKey(row,this.mode)||Extractor.rowSignature(row,this.mode)||`${this.mode}:index:${index}`;currentRowKeys.add(rowKey);this.observedRowKeys.add(rowKey);
        try{
          const record=Extractor.extractRecord(row,index,this.mode);
          if (record) {
            const context = Extractor.getPageContext?.() || {};
            record.sourcePageType = context.pageType || record.pageType || 'unknown';
            record.sourceSearchKey = U.searchKey(window.location.href);
            record.sourceSearchUrl = window.location.href;
          }
          if(!record||!U.recordKey(record)){this.unresolvedRowKeys.add(rowKey);this.unresolvedDetails.set(rowKey,{row:index+1,key:rowKey,lastSeenAt:new Date().toISOString(),reason:'Required identity not available'});return;}
          this.unresolvedRowKeys.delete(rowKey);this.unresolvedDetails.delete(rowKey);const key=U.recordKey(record);this.pageKeys.add(key);this.stats.seen=this.pageKeys.size;
          const revision=this._revision(record);if(this.revisions.get(key)===revision)return;this.revisions.set(key,revision);this.pending.set(key,record);
        }catch(error){this.unresolvedRowKeys.add(rowKey);this.unresolvedDetails.set(rowKey,{row:index+1,key:rowKey,lastSeenAt:new Date().toISOString(),reason:error?.message||'Extraction failed'});Logger.debug('Live row scan failed',this.mode,index+1,error?.message||error);}
      });
      // A row that was resolved earlier remains part of the page identity set even when virtualized away.
      void currentRowKeys;
      this._scheduleFlush();return this.snapshot();
    }

    _revision(record){return JSON.stringify({recordType:record.recordType,leadId:record.leadId||'',companyId:record.companyId||'',personName:record.personName||'',jobTitle:record.jobTitle||'',companyName:record.companyName||'',companyLinkedInUrl:record.companyLinkedInUrl||'',location:record.location||'',employeeCount:record.employeeCount||'',connectionDegree:record.connectionDegree||'',yearsInRole:record.yearsInRole||'',yearsInCompany:record.yearsInCompany||'',about:record.about||'',industry:record.industry||'',revenue:record.revenue||'',companyProfileImageUrl:record.companyProfileImageUrl||'',currentJobPeriod:record.currentJobPeriod||'',profileHeadline:record.profileHeadline||'',currentJobLocation:record.currentJobLocation||'',extractionStatus:record.extractionStatus||'',currentExperienceVerified:!!record.currentExperienceVerified,premium:!!record.premium});}

    _handleMutations(mutations){if(!this.active||!mutations?.length)return;if(mutations.some((m)=>m.type==='childList'||m.type==='characterData'))this._queueScan();}
    _queueScan(){if(!this.active||this.scanQueued)return;const debounce=Math.max(60,Number(C.DEFAULTS.liveScanDebounceMs)||160);const elapsed=Date.now()-this.lastScanAt;this.scanQueued=true;this.scanTimer=setTimeout(()=>{this.scanTimer=null;this.scanQueued=false;if(this.active)this.scanNow();},Math.max(0,debounce-elapsed));}
    _scheduleFlush(){if(!this.active||this.flushTimer||this.flushRunning)return;this.flushTimer=setTimeout(()=>{this.flushTimer=null;void this.flushPending();},Math.max(40,Number(C.DEFAULTS.liveFlushDebounceMs)||100));}

    async flushPending(){if(this.flushRunning)return;this.flushRunning=true;try{while(this.pending.size){const entries=[...this.pending.entries()];this.pending.clear();for(const [key,record] of entries){try{const result=await S.upsertLead(record);if(result.added)this.stats.added+=1;else if(result.updated)this.stats.updated+=1;else this.stats.duplicates+=1;if(this.onSaved)await this.onSaved({key,lead:record,record,result,snapshot:this.snapshot()});}catch(error){if(U.isExtensionContextInvalidated?.(error))throw error;this.stats.errors+=1;this.revisions.delete(key);Logger.warning('Live record save failed',key,error?.message||error);}}}}finally{this.flushRunning=false;this._resolveWaitersIfIdle();}}
    async flushAndWait(){if(!this.active)return this.snapshot();this.scanNow();await this.flushPending();if(!this.pending.size&&!this.flushRunning)return this.snapshot();await new Promise((resolve)=>this.waiters.push(resolve));return this.snapshot();}
    async flushPendingOnly(){await this.flushPending();return this.snapshot();}
    _resolveWaitersIfIdle(){if(this.pending.size||this.flushRunning)return;const waiters=this.waiters.splice(0);waiters.forEach((resolve)=>resolve());}
  }
  root.LXLiveCollector=new LiveCollector();
})(typeof window !== 'undefined' ? window : globalThis);
