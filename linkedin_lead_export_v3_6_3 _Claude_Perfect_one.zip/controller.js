/* controller.js — fail-closed state machine with verified page coverage and resumable pagination. */
(function attachController(root) {
  const C = root.LXConstants, S = root.LXStorage, U = root.LX, Logger = root.LXLogger;
  const Wait = root.LXWait, Extractor = root.LXExtractor, Scroll = root.LXScroll, Pagination = root.LXPagination, Safety = root.LXSafety, LiveCollector = root.LXLiveCollector;
  const ACTIVE_STATES = new Set([C.STATES.STARTING,C.STATES.SCROLLING,C.STATES.COLLECTING,C.STATES.SAVING,C.STATES.NEXT_PAGE,C.STATES.WAITING_PAGE]);

  class Controller {
    constructor() {
      this.settings = { ...C.DEFAULTS }; this.state = C.STATES.IDLE; this.meta = {}; this.runPromise = null;
      this.pauseRequested = false; this.stopRequested = false; this.autoSaveTimer = null; this.progressPersistTimer = null; this.progressPersistPending = null;
      this.leaseHeartbeat = null; this.leaseId = `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
    }

    async init() {
      this.settings = Safety.validateSettings(await S.getSettings()); Logger.setDebug(this.settings.debugMode); this.meta = await S.getMeta();
      this.state = this.meta.state || C.STATES.IDLE; return this.getSnapshot();
    }
    getSnapshot() { return U.clone({ state: this.state, settings: this.settings, ...this.meta, live: LiveCollector.snapshot() }); }
    async refreshSettings() { this.settings = Safety.validateSettings(await S.getSettings()); Logger.setDebug(this.settings.debugMode); return this.settings; }

    _baseMeta() {
      const now = new Date().toISOString();
      return { state:this.state, currentUrl:window.location.href, currentPage:this._getPageNumber(), searchKey:U.searchKey(window.location.href), lastActivityAt:now, updatedAt:now };
    }
    async _persist(patch = {}) { this.meta = { ...this.meta, ...this._baseMeta(), ...patch }; return S.setMeta(this.meta); }
    async _transition(nextState, patch = {}) {
      this.state = Object.values(C.STATES).includes(nextState) ? nextState : C.STATES.ERROR;
      Logger.info('State →', this.state, patch.reason || '');
      try { await this._persist({ currentStateReason:patch.reason || '', ...patch }); } catch (error) { if (!U.isExtensionContextInvalidated(error)) throw error; }
      return this.state;
    }

    _getPageNumber() { return U.pageNumber(window.location.href, Number(this.meta.currentPage) || 1); }
    _getRecordType() { return Extractor.detectMode(); }
    _getPageContext() { return Extractor.getPageContext(); }
    _isSearchView() { return !!this._getPageContext().isListView; }
    _isProfileView() { return !!this._getPageContext().isProfileView; }
    _shouldPause() { return this.pauseRequested || this.state === C.STATES.PAUSED; }
    _shouldStop() { return this.stopRequested || this.state === C.STATES.STOPPED; }
    _isCancelledError(error) { return error?.code === 'WAIT_CANCELLED' || error?.code === 'STOPPED' || error?.code === 'PAUSED'; }

    async _checkSafety(context) {
      if (!this.settings.safetyMode) return { risky:false, severity:'disabled' };
      const result = Safety.detect();
      try { await this._persist({ lastSafetyCheckAt:new Date().toISOString(), safetyContext:context, safetyRisk:result }); } catch (error) { if (!U.isExtensionContextInvalidated(error)) throw error; }
      if (result.risky && this.settings.stopOnSecurityPrompt) {
        this.stopRequested = true;
        try { await this._transition(C.STATES.STOPPED, { currentStateReason:'Safety guard stopped the run.', lastError:result.reason, safetyEvent:result, stoppedAt:new Date().toISOString(), stopReason:'SAFETY_SIGNAL' }); } catch (error) { if (!U.isExtensionContextInvalidated(error)) throw error; }
        this._stopAutoSave();
      }
      return result;
    }

    async _beforeAction(context) {
      if (this._shouldStop() || this._shouldPause()) return false;
      const safety = await this._checkSafety(context);
      if (safety.risky && this.settings.stopOnSecurityPrompt) return false;
      const budget = await Safety.waitForActionBudget(this.meta, this.settings, Wait, () => this._shouldStop() || this._shouldPause());
      if (!budget) return false;
      await this._persist(budget);
      return !this._shouldStop() && !this._shouldPause();
    }

    _startAutoSave() {
      this._stopAutoSave(); if (!this.settings.autoSave) return;
      const schedule = () => {
        this.autoSaveTimer = setTimeout(async () => {
          this.autoSaveTimer = null;
          if (![C.STATES.FINISHED,C.STATES.STOPPED,C.STATES.ERROR].includes(this.state)) {
            try { await this._persist({ lastAutosaveAt:new Date().toISOString(), live:LiveCollector.snapshot() }); } catch (error) { if (!U.isExtensionContextInvalidated(error)) Logger.warning('Autosave failed', error?.message || error); }
            schedule();
          }
        }, this.settings.autoSaveMs);
      }; schedule();
    }
    _stopAutoSave() { if (this.autoSaveTimer) clearTimeout(this.autoSaveTimer); this.autoSaveTimer = null; }

    _startLeaseHeartbeat() {
      this._stopLeaseHeartbeat();
      const interval = U.clamp(this.settings.leaseHeartbeatMs, C.LIMITS.leaseHeartbeatMs.min, C.LIMITS.leaseHeartbeatMs.max);
      const renew = async () => { if (!this.runPromise || this.stopRequested) return; try { await this._persist({ runLease:{ id:this.leaseId, expiresAt:Date.now()+interval*2 } }); } catch (_) {} };
      this.leaseHeartbeat = setInterval(() => { void renew(); }, interval);
    }
    _stopLeaseHeartbeat() { if (this.leaseHeartbeat) clearInterval(this.leaseHeartbeat); this.leaseHeartbeat = null; }

    async _acquireLease(searchKey) {
      const beforeRun = async () => {
        // Do not write shared run metadata until this execution context owns the
        // lock. Otherwise two tabs starting together can overwrite each other's
        // runId/state before one loses the lock race.
        const interval = U.clamp(this.settings.leaseHeartbeatMs, C.LIMITS.leaseHeartbeatMs.min, C.LIMITS.leaseHeartbeatMs.max);
        await this._persist({
          state: this.state,
          searchKey,
          totalLeads: this.meta.totalLeads,
          totalRecordsByType: this.meta.totalRecordsByType,
          recordType: this.meta.recordType,
          expectedResultsPerPage: this.meta.expectedResultsPerPage,
          runLease: { id:this.leaseId, expiresAt:Date.now()+interval*2 }
        });
        this._startLeaseHeartbeat();
        this._startAutoSave();
      };
      if (navigator.locks?.request) {
        let acquired = false;
        // Meta/settings are shared across tabs, so only one global run can own them at a time.
        await navigator.locks.request('lx-sales-run-global', { ifAvailable:true, mode:'exclusive' }, async (lock) => {
          if (!lock) return;
          acquired = true;
          try { await beforeRun(); await this._runLoop(); }
          finally { this._stopLeaseHeartbeat(); this._stopAutoSave(); try { await this._persist({ runLease:null }); } catch (_) {} }
        });
        return acquired;
      }
      const meta = await S.getMeta();
      const now = Date.now();
      const lease = meta.runLease;
      if (lease && lease.id !== this.leaseId && Number(lease.expiresAt || 0) > now) return false;
      await beforeRun();
      const reserved = await S.getMeta();
      if (reserved.runLease?.id !== this.leaseId) { this._stopLeaseHeartbeat(); this._stopAutoSave(); return false; }
      try { await this._runLoop(); }
      finally { this._stopLeaseHeartbeat(); this._stopAutoSave(); try { await this._persist({ runLease:null }); } catch (_) {} }
      return true;
    }

    async _hasForeignActiveLease() {
      // A live runPromise in this controller means this tab is the command
      // target for the run it started. Avoid blocking Pause/Stop on a storage
      // round-trip before honoring a local cancellation request.
      if (this.runPromise && ACTIVE_STATES.has(this.state)) return false;
      try {
        const saved = await S.getMeta();
        return !!(saved.runLease && saved.runLease.id !== this.leaseId && Number(saved.runLease.expiresAt || 0) > Date.now());
      } catch (_) { return false; }
    }

    async start({ resume = true, currentPage = true, explicitResume = false } = {}) {
      if (this.runPromise) return this.getSnapshot();
      await this.refreshSettings();
      const existing = await S.getMeta();
      const currentSearch = U.searchKey(window.location.href), sameSearch = existing.searchKey === currentSearch;
      const age = Date.now() - Date.parse(existing.updatedAt || existing.lastActivityAt || existing.startedAt || 0);
      const savedLease = existing.runLease;
      if (savedLease && savedLease.id !== this.leaseId && Number(savedLease.expiresAt || 0) > Date.now()) {
        // Do not overwrite the single shared run metadata while another live tab owns it.
        this.meta = { ...existing, currentStateReason:'Another tab currently owns the extractor run.', stopReason:'RUN_ALREADY_ACTIVE' };
        this.state = existing.state || C.STATES.STOPPED;
        return this.getSnapshot();
      }
      const resumable = [C.STATES.STARTING,C.STATES.SCROLLING,C.STATES.COLLECTING,C.STATES.SAVING,C.STATES.NEXT_PAGE,C.STATES.WAITING_PAGE,C.STATES.PAUSED].includes(existing.state);
      // Auto-resume is a setting for boot/reload. A user pressing Resume is an explicit request and must work even when auto-resume is disabled.
      const canResume = resume && (this.settings.autoResume || explicitResume) && sameSearch && resumable && existing.runId && (explicitResume || (age >= 0 && age <= Number(this.settings.resumeStalenessMs || 10*60*1000)));

      if (canResume) {
        this.meta = existing; this.state = C.STATES.STARTING; this.pauseRequested = false; this.stopRequested = false;
        Logger.info('Resuming run', existing.runId, 'page', existing.currentPage, 'from', existing.state);
      } else {
        this.meta = {
          runId:`${Date.now()}-${Math.random().toString(36).slice(2,8)}`, searchKey:currentSearch, searchSessionId:U.hashString(`${currentSearch}|${Date.now()}`),
          startedAt:new Date().toISOString(), updatedAt:new Date().toISOString(), pagesProcessed:0, currentPage:currentPage ? this._getPageNumber() : 1,
          collectedThisRun:0, duplicates:0, errors:0, pageLedger:[], completedPageIds:[], lastError:'', currentStateReason:'Run started',
          expectedResultsPerPage:(this._getPageContext().usesSalesNavigator ? 25 : Pagination.detectExpectedResultsPerPage()), pageType:this._getPageContext().pageType, recordType:this._getRecordType(), pageCoverage:null, actionsInWindow:0, actionWindowStartedAt:Date.now(), stopReason:'', debug:{}
        };
        this.state = C.STATES.STARTING;
      }

      if (!this._isSearchView()) {
        this.state=C.STATES.ERROR;
        await this._persist({ state:C.STATES.ERROR, lastError:'Open LinkedIn People Search, My Network Connections, or a Sales Navigator People/Company search before starting.', stopReason:'NOT_SUPPORTED_LIST_VIEW' });
        return this.getSnapshot();
      }
      this.pauseRequested = false; this.stopRequested = false; this.meta.totalLeads = await S.getLeadCount();
      this.meta.totalRecordsByType = await S.getCountByType();
      this.meta.recordType = this._getRecordType();
      this.runPromise = this._acquireLease(this.meta.searchKey).then(async (acquired) => {
        if (acquired !== false) return;
        // The global metadata may belong to the real owner. Do not write STOPPED
        // over that tab's state; only report the conflict in this local controller.
        this.stopRequested = true;
        this._stopAutoSave();
        this.state = C.STATES.STOPPED;
        this.meta = { ...this.meta, currentStateReason:'Another tab already owns the extractor run.', stopReason:'RUN_ALREADY_ACTIVE' };
        Logger.warning('Run not started because another tab owns the shared extractor state.');
      }).catch(async (error) => {
        if (U.isExtensionContextInvalidated(error)) return;
        Logger.error('Run lease failed', error?.message || error);
        try { await this._transition(C.STATES.ERROR, { lastError:error?.message || 'Run lease failed', stopReason:'LEASE_FAILURE' }); } catch (_) {}
      }).finally(() => { this.runPromise = null; });
      return this.getSnapshot();
    }

    async pause() {
      if (await this._hasForeignActiveLease()) return { ...this.getSnapshot(), controlError:'Another tab currently owns the extractor run.' };
      this.pauseRequested = true;
      if (![C.STATES.FINISHED,C.STATES.STOPPED,C.STATES.ERROR].includes(this.state)) {
        // Make the local state transition first. A slow IndexedDB/message-bridge
        // flush must not leave the UI saying RUNNING after Pause was requested.
        // Start draining already discovered records without blocking the
        // control command on the storage bridge, then stop further observation.
        void LiveCollector.flushPending().catch((error) => Logger.warning('Pending record flush after pause failed', error?.message || error));
        LiveCollector.stop({ preserveStats:true });
        this.state = C.STATES.PAUSED;
        const patch = { state:C.STATES.PAUSED, currentStateReason:'Paused by user', pauseRequestedAt:new Date().toISOString(), live:LiveCollector.snapshot() };
        try { await Promise.race([this._persist(patch), new Promise((_, reject) => setTimeout(() => reject(new Error('Pause state persistence timed out')), 2500))]); }
        catch (error) { if (!U.isExtensionContextInvalidated(error)) Logger.warning('Pause state persistence failed', error?.message || error); }
      }
      return this.getSnapshot();
    }

    async resume() {
      await this.refreshSettings();
      if (this.state === C.STATES.PAUSED) {
        // A paused _runLoop may still be unwinding. Wait for its lease/finally
        // block to finish before creating the replacement loop, otherwise an
        // immediate Resume click can leave STARTING with no active controller.
        const previousRun = this.runPromise;
        if (previousRun) {
          try { await previousRun; }
          catch (error) { if (!U.isExtensionContextInvalidated(error)) Logger.warning('Paused run shutdown failed before resume', error?.message || error); }
        }
        // A concurrent Stop always wins over a Resume request.
        if (this.stopRequested || this.state === C.STATES.STOPPED) return this.getSnapshot();
        this.pauseRequested = false;
        this.stopRequested = false;
        return this.start({ resume:true, explicitResume:true });
      }
      if (!this.runPromise) return this.start({ resume:true, explicitResume:true });
      return this.getSnapshot();
    }

    async stop() {
      if (await this._hasForeignActiveLease()) return { ...this.getSnapshot(), controlError:'Another tab currently owns the extractor run.' };
      this.stopRequested = true; this.pauseRequested = false; this._stopAutoSave(); LiveCollector.stop({preserveStats:true});
      this.state = C.STATES.STOPPED;
      const patch = { state:C.STATES.STOPPED, currentStateReason:'Stopped by user', stoppedAt:new Date().toISOString(), stopReason:'USER_STOPPED' };
      // Stop is a cancellation command, not a request to wait for every queued
      // storage write. Persist in the background with a bound so the popup can
      // receive acknowledgement promptly even if a record write is stuck.
      try {
        await Promise.race([this._flushProgressPersist().then(() => this._persist(patch)), new Promise((_, reject) => setTimeout(() => reject(new Error('Stop persistence timed out')), 2500))]);
      } catch (error) { if (!U.isExtensionContextInvalidated(error)) Logger.warning('Stop state persistence failed', error?.message || error); }
      return this.getSnapshot();
    }

    async resetRun() {
      if (await this._hasForeignActiveLease()) return { ...this.getSnapshot(), controlError:'Cannot reset while another tab owns the extractor run.' };
      this.stopRequested=true; this.pauseRequested=false; this._stopAutoSave(); LiveCollector.stop({preserveStats:false}); await this._flushProgressPersist();
      await S.setMeta({ state:C.STATES.IDLE, currentStateReason:'Run reset', currentPage:this._getPageNumber(), searchKey:U.searchKey(window.location.href), pagesProcessed:0, collectedThisRun:0, duplicates:0, errors:0, pageLedger:[], completedPageIds:[], lastError:'', actionsInWindow:0, actionWindowStartedAt:Date.now(), pageCoverage:null, stopReason:'', recordType:this._getRecordType(), totalRecordsByType:await S.getCountByType(), runLease:null });
      this.meta=await S.getMeta(); this.state=C.STATES.IDLE; this.stopRequested=false; return this.getSnapshot();
    }

    async extractCurrentPage() {
      if (this.runPromise || ACTIVE_STATES.has(this.state)) return { ok:false, reason:'Current-page extraction is unavailable while a run is active. Stop or pause the run first.' };
      await this.refreshSettings(); if (!this._isSearchView() && !this._isProfileView()) return { ok:false, reason:'Open a supported LinkedIn people list or a person profile to extract visible data.' };
      const mode=this._getRecordType() || C.RECORD_TYPES.PERSON, pageKey=U.pageKey(window.location.href);
      this.meta.totalLeads=await S.getLeadCount(); this.meta.totalRecordsByType=await S.getCountByType();
      const collector=LiveCollector.start(pageKey, mode, (payload)=>this._onLeadSaved(payload));
      await LiveCollector.flushAndWait(); LiveCollector.stop();
      return { ok:true, mode, foundOnPage:collector.uniquePageRecords, live:LiveCollector.snapshot() };
    }

    async _waitForFirstRows() {
      const timeoutMs=Number(this.settings.timeoutMs)||30000; const started=Date.now();
      try {
        const result=await Wait.waitForCondition(()=>!Extractor.hasBlockingLoader() && Extractor.findResultRows(this._getRecordType()).length>0,{root:document.documentElement||document,timeoutMs,observeAttributes:false,shouldCancel:()=>this._shouldStop()||this._shouldPause()});
        return {ready:true,reason:'first-row-found',waitedMs:result.waitedMs,rowsVisible:Extractor.findResultRows(this._getRecordType()).length};
      } catch(error) {
        if (error?.code==='WAIT_CANCELLED') return {ready:false,cancelled:true,reason:this._shouldPause()?'paused':'stopped',waitedMs:Date.now()-started,rowsVisible:Extractor.findResultRows(this._getRecordType()).length};
        return {ready:false,reason:error?.message||'first-row-timeout',waitedMs:Date.now()-started,rowsVisible:Extractor.findResultRows(this._getRecordType()).length};
      }
    }

    _scheduleProgressPersist(patch) {
      this.progressPersistPending={...(this.progressPersistPending||{}),...(patch||{})}; if(this.progressPersistTimer) return;
      this.progressPersistTimer=setTimeout(async()=>{ this.progressPersistTimer=null; const pending=this.progressPersistPending; this.progressPersistPending=null; if(!pending) return; try{await this._persist(pending);}catch(error){if(!U.isExtensionContextInvalidated(error)) Logger.warning('Progress checkpoint failed',error?.message||error);}},250);
    }
    async _flushProgressPersist(){ if(this.progressPersistTimer){clearTimeout(this.progressPersistTimer);this.progressPersistTimer=null;} const pending=this.progressPersistPending;this.progressPersistPending=null;if(!pending)return;try{await this._persist(pending);}catch(error){if(!U.isExtensionContextInvalidated(error))Logger.warning('Progress checkpoint flush failed',error?.message||error);}}

    async _onLeadSaved({result,lead,key,snapshot}) {
      const added=!!result?.added, updated=!!result?.updated, duplicate=!added&&!updated;
      // Totals are seeded from storage in start() and tracked locally here. This used to
      // issue two service-worker round-trips (getCountByType + getLeadCount) per record.
      const counts={person:0,company:0,...(this.meta.totalRecordsByType||{})};
      if(added){const type=lead?.recordType===C.RECORD_TYPES.COMPANY?'company':'person'; counts[type]=Number(counts[type]||0)+1; this.meta.totalLeads=Number(this.meta.totalLeads||0)+1;}
      this.meta.collectedThisRun=Number(this.meta.collectedThisRun||0)+(added?1:0); this.meta.duplicates=Number(this.meta.duplicates||0)+(duplicate?1:0);
      this.meta.lastSavedLead=key; this.meta.lastSavedAt=new Date().toISOString(); this.meta.currentPageLeadCount=snapshot.uniquePageRecords; this.meta.totalRecordsByType=counts; this.meta.live=snapshot;
      this._scheduleProgressPersist({totalLeads:this.meta.totalLeads,collectedThisRun:this.meta.collectedThisRun,duplicates:this.meta.duplicates,lastSavedLead:key,lastSavedAt:this.meta.lastSavedAt,currentPageLeadCount:snapshot.uniquePageRecords,totalRecordsByType:counts,live:snapshot});
      const name=lead?.recordType===C.RECORD_TYPES.COMPANY?lead.companyName:lead.personName; if(added)Logger.success('Record added live',name||key); else if(updated)Logger.info('Record updated live',name||key);
    }

    async _upsertPageLedger(entry) {
      const ledger=Array.isArray(this.meta.pageLedger)?[...this.meta.pageLedger]:[]; const idx=ledger.findIndex((x)=>x.pageId===entry.pageId);
      if(idx>=0) ledger[idx]={...ledger[idx],...entry}; else ledger.push(entry);
      const max=Math.max(10,Math.min(Number(this.settings.maxPages)||1000,1000)); this.meta.pageLedger=ledger.slice(-max); await this._persist({pageLedger:this.meta.pageLedger,currentPageAudit:entry});
    }

    async _auditCurrentPage() {
      const context=this._getPageContext();
      const detected=Pagination.detectExpectedResultsPerPage();
      const expected=detected || (context.usesSalesNavigator ? Math.max(1,Math.min(100,Number(this.settings.expectedResultsPerPage)||25)) : null);
      this.meta.expectedResultsPerPage=expected;
      const audit=this.settings.autoScroll ? await Scroll.auditCoverage({findRows:()=>Extractor.findResultRows(this._getRecordType()),settings:this.settings,shouldPause:()=>this._shouldPause()||this._shouldStop(),onScan:async()=>{LiveCollector.scanNow();await LiveCollector.flushPending();},getUniqueCount:()=>LiveCollector.getUniquePageCount(),getUnresolvedCount:()=>LiveCollector.getUnresolvedCount(),expectedCount:expected}) : (LiveCollector.scanNow(),await LiveCollector.flushPending(),{paused:false,passes:0,attempts:0,uniqueCount:LiveCollector.getUniquePageCount(),unresolvedCount:LiveCollector.getUnresolvedCount(),expectedCount:expected,complete:expected!=null&&LiveCollector.getUniquePageCount()>=expected&&LiveCollector.getUnresolvedCount()===0,audited:false,reason:'auto-scroll-disabled'});
      await LiveCollector.flushAndWait();
      const nextStatus=Pagination.findNextStatus(), moreStatus=Pagination.findLoadMoreStatus();
      const terminal=Pagination.isLastPage();
      const uniqueCount=LiveCollector.getUniquePageCount(), unresolvedCount=LiveCollector.getUnresolvedCount();
      const complete=Boolean(unresolvedCount===0&&(expected!=null?(uniqueCount>=expected||terminal):audit.complete===true));
      const coverage={page:this._getPageNumber(),pageType:context.pageType,uniqueCollected:uniqueCount,expected,missingEstimate:expected==null?null:Math.max(0,expected-uniqueCount),unresolvedCount,complete,lastPage:terminal,audited:audit.audited!==false,auditReason:audit.reason||'',auditPasses:audit.passes||0,auditAttempts:audit.attempts||0,nextPresent:!!nextStatus,nextDisabled:!!nextStatus?.disabled,loadMorePresent:!!moreStatus,observedRows:LiveCollector.getObservedRowCount(),auditedAt:new Date().toISOString()};
      await this._persist({pageCoverage:coverage,currentPageLeadCount:uniqueCount,scrollProgress:this.settings.autoScroll?100:Number(this.meta.scrollProgress||0)});
      return {...audit,...coverage};
    }

    async _processCurrentPage() {
      const mode=this._getRecordType();
      if(!mode)return {ok:false,reason:'Search mode could not be detected.'};
      if(this.meta.recordType&&this.meta.recordType!==mode)throw new Error(`Search mode changed from ${this.meta.recordType} to ${mode}; run stopped to prevent mixed datasets.`);
      this.meta.recordType=mode;

      await this._transition(C.STATES.STARTING,{currentPage:this._getPageNumber(),currentStateReason:'Waiting for first result row',pageKey:U.pageKey(window.location.href)});
      const ready=await this._waitForFirstRows();
      await this._persist({lastReadiness:ready});
      if(!ready.ready){
        if(ready.cancelled)return {ok:false,paused:ready.reason==='paused',stopped:ready.reason==='stopped',reason:ready.reason};
        return {ok:false,reason:`No result row appeared before timeout (${this.settings.timeoutMs}ms).`};
      }
      if(this._shouldStop()||this._shouldPause())return {ok:false,paused:this._shouldPause(),stopped:this._shouldStop(),reason:'Run cancelled during readiness.'};

      const initialDescriptor=Pagination.getPageDescriptor();
      const pageNumber=this._getPageNumber();
      const pageIdentity=initialDescriptor.firstKey||initialDescriptor.signature||initialDescriptor.rowKeys?.join('|')||`page:${pageNumber}`;
      const pageId=`${this.meta.searchKey}|${pageNumber}|${U.hashString(pageIdentity.slice(0,500))}`;
      const completed=new Set(this.meta.completedPageIds||[]);
      if(completed.has(pageId)){
        const existingCoverage=this.meta.pageCoverage?.page===pageNumber?this.meta.pageCoverage:null;
        Logger.info('Page already verified; using checkpoint',pageNumber);
        return {ok:true,alreadyComplete:true,coverage:existingCoverage||{page:pageNumber,complete:true,lastPage:false,uniqueCollected:0,expected:this.settings.expectedResultsPerPage||25,unresolvedCount:0},descriptor:initialDescriptor,action:Pagination.detectAction()};
      }

      await this._upsertPageLedger({pageId,page:pageNumber,mode,status:'IN_PROGRESS',startedAt:new Date().toISOString(),url:window.location.href,firstKey:initialDescriptor.firstKey||'',recordsFound:initialDescriptor.rowCount||0,uniqueCollected:0,expected:(Pagination.detectExpectedResultsPerPage() || (this._getPageContext().usesSalesNavigator ? Number(this.settings.expectedResultsPerPage)||25 : null)),unresolvedCount:0});
      LiveCollector.start(U.pageKey(window.location.href),mode,(payload)=>this._onLeadSaved(payload));
      await LiveCollector.flushAndWait();

      if(this.settings.autoScroll){
        await this._transition(C.STATES.SCROLLING,{currentPage:pageNumber,currentStateReason:'Streaming rows while LinkedIn renders the page'});
        const scroll=await Scroll.scrollToBottom({findRows:()=>Extractor.findResultRows(mode),settings:this.settings,shouldPause:()=>this._shouldPause()||this._shouldStop(),onScan:async()=>{LiveCollector.scanNow();await LiveCollector.flushPending();},onProgress:async(progress)=>{LiveCollector.scanNow();await LiveCollector.flushPending();this._scheduleProgressPersist({scrollProgress:progress.progress,scrollTop:progress.scrollTop,loadedRows:progress.rows,live:LiveCollector.snapshot()});}});
        if(scroll.paused)return {ok:false,paused:true,reason:'Paused during scrolling.'};
        await this._persist({scrollProgress:scroll.progress,scrollTop:scroll.scrollTop});
      }

      let loadMoreLoops=0;
      while(!this._shouldStop()&&!this._shouldPause()){
        const action=Pagination.detectAction();
        if(action.type!=='load-more')break;
        if(++loadMoreLoops>50)throw new Error('Load-more loop guard reached its maximum iterations.');
        if(!(await this._beforeAction('load-more')))return {ok:false,paused:this._shouldPause(),stopped:this._shouldStop()};
        await this._transition(C.STATES.NEXT_PAGE,{currentPage:pageNumber,currentStateReason:`Loading more results (${loadMoreLoops})`});
        const before=Pagination.getPageDescriptor();
        const result=await Pagination.clickLoadMoreWithRetry(before,this.settings,null,()=>this._shouldStop()||this._shouldPause());
        if(result.cancelled)return {ok:false,paused:this._shouldPause(),stopped:this._shouldStop(),reason:'Load-more cancelled.'};
        if(!result.ok)throw new Error(`Load more failed: ${result.reason}`);
        await LiveCollector.flushAndWait();
        if(this.settings.autoScroll){
          const moreScroll=await Scroll.scrollToBottom({findRows:()=>Extractor.findResultRows(mode),settings:this.settings,shouldPause:()=>this._shouldPause()||this._shouldStop(),onScan:async()=>{LiveCollector.scanNow();await LiveCollector.flushPending();}});
          if(moreScroll.paused)return {ok:false,paused:true,reason:'Paused during load-more scrolling.'};
        }
      }

      await this._transition(C.STATES.COLLECTING,{currentPage:pageNumber,currentStateReason:'Verifying every result on the page'});
      const coverage=await this._auditCurrentPage();
      if(coverage.paused)return {ok:false,paused:true,reason:'Paused during coverage audit.'};
      if(!coverage.complete){
        const coverageLabel=coverage.expected==null?`${coverage.uniqueCount} unique records (list did not expose a total)`: `${coverage.uniqueCount}/${coverage.expected} unique records`;
        const reason=`Coverage incomplete: ${coverageLabel}, ${coverage.unresolvedCount} unresolved rows. Pagination blocked.`;
        await this._upsertPageLedger({pageId,page:pageNumber,mode,status:'INCOMPLETE',finishedAt:new Date().toISOString(),uniqueCollected:coverage.uniqueCount,expected:coverage.expected,unresolvedCount:coverage.unresolvedCount,reason});
        return {ok:false,coverage,reason,coverageIncomplete:true};
      }

      await LiveCollector.flushAndWait();
      await this._transition(C.STATES.SAVING,{currentPage:pageNumber,pageRowsFound:coverage.observedRows,pageUniqueCollected:coverage.uniqueCount,pageCoverage:coverage,currentSelector:Extractor._lastResultSelector||'auto-detected'});
      const completedIds=[...(this.meta.completedPageIds||[]),pageId].slice(-Math.max(1,Number(this.settings.maxPages)||1000));
      await this._upsertPageLedger({pageId,page:pageNumber,mode,status:'VERIFIED',finishedAt:new Date().toISOString(),uniqueCollected:coverage.uniqueCount,expected:coverage.expected,unresolvedCount:coverage.unresolvedCount,reason:coverage.lastPage?'Verified last page':'Verified full page coverage'});
      await this._persist({pagesProcessed:Number(this.meta.pagesProcessed||0)+1,completedPageIds:completedIds,lastPageSavedAt:new Date().toISOString(),pageRowsFound:coverage.observedRows,pageUniqueCollected:coverage.uniqueCount,pageCoverage:coverage});
      return {ok:true,coverage,descriptor:Pagination.getPageDescriptor(),action:Pagination.detectAction()};
    }

    async _finishRun(reason) {
      await this._transition(C.STATES.FINISHED,{currentStateReason:reason,finishedAt:new Date().toISOString(),stopReason:'FINISHED'});
      if(this.settings.autoDownload&&root.LXExport?.downloadCsv){try{const records=(await S.getLeads()).filter((r)=>r.recordType===this.meta.recordType);root.LXExport.downloadCsv(records,this.meta.recordType);await this._persist({lastAutoDownloadAt:new Date().toISOString(),lastAutoDownloadCount:records.length});}catch(error){Logger.warning('Final auto-download failed',error?.message||error);}}
    }

    async _runLoop() {
      try {
        const guard=await this._validateSearchContext(); if(!guard.ok){await this._transition(C.STATES.ERROR,{lastError:guard.reason,errors:Number(this.meta.errors||0)+1,stopReason:'SEARCH_CONTEXT'});return;}
        const maxPages=Math.max(1,Number(this.settings.maxPages)||1000);
        while(!this._shouldStop()){
          if(this._shouldPause()){LiveCollector.stop({preserveStats:true});this.state=C.STATES.PAUSED;await this._persist({state:C.STATES.PAUSED,currentStateReason:'Paused by user',live:LiveCollector.snapshot()});this._stopAutoSave();return;}
          if(Number(this.meta.pagesProcessed||0)>=maxPages){await this._finishRun('Maximum page limit reached');break;}
          const safety=await this._checkSafety('page-start');if(safety.risky&&this.settings.stopOnSecurityPrompt)return;
          const pageResult=await this._processCurrentPage();
          if(!pageResult.ok){if(pageResult.paused){this.pauseRequested=true;LiveCollector.stop({preserveStats:true});this.state=C.STATES.PAUSED;await this._persist({state:C.STATES.PAUSED,currentStateReason:'Paused during page processing'});this._stopAutoSave();return;}if(pageResult.stopped||this._shouldStop())return;if(pageResult.coverageIncomplete){await this._transition(C.STATES.ERROR,{lastError:pageResult.reason,errors:Number(this.meta.errors||0)+1,stopReason:'COVERAGE_INCOMPLETE'});break;}throw new Error(pageResult.reason||'Page processing failed.');}
          LiveCollector.stop();
          const nextStatus=Pagination.findNextStatus();
          if(!this.settings.autoNextPage){await this._finishRun('Automatic pagination disabled');break;}
          if(nextStatus?.disabled){await this._finishRun('Verified last page');break;}
          const next=Pagination.findNext();
          if(!next){await this._finishRun('No enabled Next control detected after page verification');break;}
          if(!(await this._beforeAction('next-page')))return;
          const previous=Pagination.getPageDescriptor();
          const beforePage=this._getPageNumber();
          await this._transition(C.STATES.NEXT_PAGE,{currentPage:beforePage,navigationPending:true,navigationStartedAt:new Date().toISOString(),navigationFromUrl:previous.url,navigationFromPage:beforePage,currentSignature:previous.signature,paginationSelector:previous.selector||null});
          const result=await Pagination.clickNextWithRetry(previous,this.settings,null,()=>this._shouldStop()||this._shouldPause());
          if(result.cancelled){if(this._shouldPause()){this.state=C.STATES.PAUSED;await this._persist({state:C.STATES.PAUSED,currentStateReason:'Paused during pagination'});this._stopAutoSave();}return;}
          if(!result.ok)throw new Error(`Next page failed: ${result.reason}`);
          const newPage=U.pageNumber(window.location.href,beforePage+1); const newSearch=U.searchKey(window.location.href);
          if(newSearch!==this.meta.searchKey)throw new Error('Search context changed during pagination; run stopped to prevent mixing datasets.');
          await this._transition(C.STATES.WAITING_PAGE,{currentPage:newPage,currentUrl:window.location.href,currentPageNumber:newPage,pageChangeWaitMs:result.waitedMs||0,scrollTop:0,scrollProgress:0,navigationPending:false,navigationCompletedAt:new Date().toISOString()});
        }
      } catch(error){
        if(U.isExtensionContextInvalidated(error)){LiveCollector.stop();try{console.warn('[LX] Extension context invalidated; controller ended safely after checkpoint.');}catch(_){}return;}
        if(this._shouldStop()||this._isCancelledError(error))return;
        Logger.error('Controller failed',error?.message||error);
        try{await this._transition(C.STATES.ERROR,{lastError:error?.message||'Unknown controller error',errors:Number(this.meta.errors||0)+1,stopReason:'UNHANDLED_ERROR',debug:{currentState:this.state,currentUrl:window.location.href,currentPage:this._getPageNumber(),lastError:error?.message||'Unknown controller error'}});}catch(persistError){if(!U.isExtensionContextInvalidated(persistError))Logger.error('Failed to persist controller error state',persistError?.message||persistError);}
      } finally {
        try{await this._flushProgressPersist();}catch(_){}
        LiveCollector.stop(); this._stopAutoSave();
      }
    }

    async _validateSearchContext(){
      if(!this._isSearchView())return {ok:false,reason:'Open a supported LinkedIn People Search, Connections, Grow, or Sales Navigator result list before starting.'};
      const existing=await S.getMeta(); const current=U.searchKey(window.location.href);
      if(existing.searchKey&&existing.searchKey!==current&&existing.state&&! [C.STATES.IDLE,C.STATES.STOPPED,C.STATES.FINISHED,C.STATES.ERROR].includes(existing.state))return {ok:false,reason:'The current search does not match the saved active run. Reset the run before changing searches.'};
      return {ok:true};
    }
  }
  root.LXController=new Controller();
})(typeof window !== 'undefined' ? window : globalThis);
