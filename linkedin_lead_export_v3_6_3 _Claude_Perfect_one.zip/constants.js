/* constants.js — single source of truth for engine settings, states and limits. */
(function attachConstants(root) {
  const Constants = {
    VERSION: '3.6.3',
    RECORD_TYPES: Object.freeze({ PERSON: 'person', COMPANY: 'company' }),
    STORAGE_KEYS: Object.freeze({
      SETTINGS: 'lx_settings',
      META: 'lx_meta',
      MIGRATION: 'lx_storage_migration_v1'
    }),
    STATES: Object.freeze({
      IDLE: 'IDLE', STARTING: 'STARTING', SCROLLING: 'SCROLLING', COLLECTING: 'COLLECTING',
      SAVING: 'SAVING', NEXT_PAGE: 'NEXT_PAGE', WAITING_PAGE: 'WAITING_PAGE', PAUSED: 'PAUSED',
      FINISHED: 'FINISHED', STOPPED: 'STOPPED', ERROR: 'ERROR'
    }),
    DEFAULTS: Object.freeze({
      autoDownload: false,
      darkMode: true,
      autoScroll: true,
      autoNextPage: true,
      autoSave: true,
      autoResume: true,
      humanMode: true,
      safetyMode: true,
      stopOnSecurityPrompt: true,
      actionDelayMinMs: 1400,
      actionDelayMaxMs: 2600,
      maxActionsPerMinute: 12,
      randomDelayMinMs: 300,
      randomDelayMaxMs: 1000,
      scrollMinPx: 420,
      scrollMaxPx: 840,
      scrollPauseMinMs: 650,
      scrollPauseMaxMs: 1500,
      retryCount: 3,
      timeoutMs: 30000,
      expectedResultsPerPage: 25,
      pageAuditPasses: 3,
      liveScanDebounceMs: 160,
      liveReconcileMs: 1400,
      liveFlushDebounceMs: 100,
      autoSaveMs: 30000,
      storageTimeoutMs: 10000,
      maxPages: 1000,
      maxScrollPasses: 100,
      pageChangeRetries: 3,
      resumeStalenessMs: 10 * 60 * 1000,
      leaseHeartbeatMs: 15000,
      debugMode: false
    }),
    LIMITS: Object.freeze({
      retryCount: { min: 1, max: 6 }, timeoutMs: { min: 5000, max: 90000 },
      actionDelayMinMs: { min: 250, max: 30000 }, actionDelayMaxMs: { min: 500, max: 60000 },
      maxActionsPerMinute: { min: 2, max: 30 }, randomDelayMinMs: { min: 0, max: 10000 },
      randomDelayMaxMs: { min: 50, max: 20000 }, scrollMinPx: { min: 100, max: 1500 },
      scrollMaxPx: { min: 150, max: 2500 }, scrollPauseMinMs: { min: 250, max: 8000 },
      scrollPauseMaxMs: { min: 500, max: 15000 }, autoSaveMs: { min: 10000, max: 120000 },
      maxPages: { min: 1, max: 5000 }, maxScrollPasses: { min: 10, max: 500 },
      expectedResultsPerPage: { min: 1, max: 100 }, pageAuditPasses: { min: 1, max: 5 },
      pageChangeRetries: { min: 1, max: 6 }, storageTimeoutMs: { min: 3000, max: 30000 },
      resumeStalenessMs: { min: 60000, max: 24 * 60 * 60 * 1000 }, leaseHeartbeatMs: { min: 5000, max: 60000 }
    })
  };
  root.LXConstants = Constants;
})(typeof window !== 'undefined' ? window : globalThis);
