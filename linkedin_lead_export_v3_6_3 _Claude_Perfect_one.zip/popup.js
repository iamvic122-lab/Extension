/* popup.js — control panel for automatic people/company extraction. */
(function popup() {
  const C = window.LXConstants;
  const S = window.LXStorage;
  const U = window.LX;
  const E = window.LXExport;

  const els = {
    settingsBtn: document.getElementById('settingsBtn'),
    settingsPanel: document.getElementById('settingsPanel'),
    statusPill: document.getElementById('statusPill'),
    modePill: document.getElementById('modePill'),
    totalLabel: document.getElementById('totalLabel'),
    statusHint: document.getElementById('statusHint'),
    totalCount: document.getElementById('totalCount'),
    pageCount: document.getElementById('pageCount'),
    duplicateCount: document.getElementById('duplicateCount'),
    errorCount: document.getElementById('errorCount'),
    speedValue: document.getElementById('speedValue'),
    etaValue: document.getElementById('etaValue'),
    progressBar: document.getElementById('progressBar'),
    startBtn: document.getElementById('startBtn'),
    pauseBtn: document.getElementById('pauseBtn'),
    resumeBtn: document.getElementById('resumeBtn'),
    stopBtn: document.getElementById('stopBtn'),
    extractBtn: document.getElementById('extractBtn'),
    resetRunBtn: document.getElementById('resetRunBtn'),
    clearBtn: document.getElementById('clearBtn'),
    tableTitle: document.getElementById('tableTitle'),
    tableRowCount: document.getElementById('tableRowCount'),
    leadTableHead: document.getElementById('leadTableHead'),
    leadTableBody: document.getElementById('leadTableBody'),
    leadTableEmpty: document.getElementById('leadTableEmpty'),
    copyAllBtn: document.getElementById('copyAllBtn'),
    downloadCsvBtn: document.getElementById('downloadCsvBtn'),
    downloadJsonBtn: document.getElementById('downloadJsonBtn'),
    downloadXlsxBtn: document.getElementById('downloadXlsxBtn'),
    saveSettingsBtn: document.getElementById('saveSettingsBtn'),
    urlIndicator: document.getElementById('urlIndicator'),
    paginationStatus: document.getElementById('paginationStatus'),
    setAutoScroll: document.getElementById('setAutoScroll'),
    setAutoNext: document.getElementById('setAutoNext'),
    setAutoSave: document.getElementById('setAutoSave'),
    setAutoResume: document.getElementById('setAutoResume'),
    setHumanMode: document.getElementById('setHumanMode'),
    setAutoDownload: document.getElementById('setAutoDownload'),
    setSafetyMode: document.getElementById('setSafetyMode'),
    setStopOnSecurity: document.getElementById('setStopOnSecurity'),
    setDebug: document.getElementById('setDebug'),
    setScrollMin: document.getElementById('setScrollMin'),
    setScrollMax: document.getElementById('setScrollMax'),
    setRetry: document.getElementById('setRetry'),
    setTimeout: document.getElementById('setTimeout'),
    setMaxPages: document.getElementById('setMaxPages'),
    setExpected: document.getElementById('setExpected'),
    setAuditPasses: document.getElementById('setAuditPasses'),
    setActionDelayMin: document.getElementById('setActionDelayMin'),
    setActionDelayMax: document.getElementById('setActionDelayMax'),
    setActionsPerMinute: document.getElementById('setActionsPerMinute'),
    versionLabel: document.getElementById('versionLabel')
  };

  let activeTabId = null;
  let refreshTimer = null;
  let tableRefreshTimer = null;
  let recordsChannel = null;
  let currentMode = C.RECORD_TYPES.PERSON;
  let currentPageType = 'unsupported';
  let currentSearchKey = '';
  let lastPing = null;
  let refreshSeq = 0;

  function inCurrentScope(record) {
    if (normalizeRecordType(record) !== currentMode) return false;
    if (!currentPageType || currentPageType === 'unsupported') return false;
    if (record.sourcePageType === currentPageType && record.sourceSearchKey === currentSearchKey) return true;
    return Array.isArray(record.sourceScopes) && record.sourceScopes.some((scope) => scope?.pageType === currentPageType && scope?.searchKey === currentSearchKey);
  }

  async function getCurrentScopeRecords() { return (await S.getLeads()).filter(inCurrentScope); }

  function scheduleTableRefresh() {
    if (tableRefreshTimer) clearTimeout(tableRefreshTimer);
    tableRefreshTimer = setTimeout(async () => {
      tableRefreshTimer = null;
      try { await loadData(); }
      catch (error) { setHint(`Table refresh failed: ${error?.message || 'storage read error'}`); }
    }, 140);
  }

  async function getActiveTab() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    return tabs?.[0] || null;
  }

  async function sendToTab(message) {
    if (!activeTabId) return { ok:false, noResponse:true, reason:'No active tab is available.' };
    return new Promise((resolve) => {
      let settled = false;
      const finish = (value) => { if (settled) return; settled = true; clearTimeout(timer); resolve(value); };
      const timer = setTimeout(() => finish({ ok:false, noResponse:true, reason:`Timed out waiting for the LinkedIn page to respond to ${message?.type || 'the command'}.` }), 4500);
      try {
        chrome.tabs.sendMessage(activeTabId, message, (response) => {
          try {
            if (chrome.runtime?.lastError) return finish({ ok:false, noResponse:true, reason:chrome.runtime.lastError.message || 'The active LinkedIn tab did not respond.' });
            finish(response || { ok:false, noResponse:true, reason:'The active LinkedIn tab returned no response.' });
          } catch (error) { finish({ ok:false, noResponse:true, reason:error?.message || 'Unable to read the tab response.' }); }
        });
      } catch (error) { finish({ ok:false, noResponse:true, reason:error?.message || 'Unable to send a command to the active tab.' }); }
    });
  }

  function isSupportedLinkedInUrl(rawUrl) {
    try {
      const url = new URL(rawUrl);
      if (!/(?:^|\.)linkedin\.com$/i.test(url.hostname)) return false;
      return /^\/(?:sales\/|search\/|mynetwork\/|in\/)/i.test(url.pathname);
    } catch (_) { return false; }
  }

  async function ensureContent(tab) {
    if (!tab?.id || !tab.url || !isSupportedLinkedInUrl(tab.url)) return null;
    let ping = await sendToTab({ type: 'LX_PING' });
    if (ping?.ok) return ping;
    // Re-injecting while a script is merely busy (timeout) would stack a second
    // copy of every module in the page; only inject when nothing is listening.
    if (ping?.noResponse && !/receiving end does not exist|could not establish connection|no tab with id/i.test(String(ping.reason || ''))) return null;
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: [
          'constants.js', 'logger.js', 'selectors.js', 'utils.js', 'linkedin_adapters.js', 'safety.js',
          'wait.js', 'storage.js', 'extractor.js', 'scroll.js', 'pagination.js',
          'live_collector.js', 'export.js', 'controller.js', 'content.js'
        ]
      });
    } catch (_) { return null; }
    await new Promise((resolve) => setTimeout(resolve, 0));
    ping = await sendToTab({ type: 'LX_PING' });
    return ping?.ok ? ping : null;
  }

  function modeLabel(mode) { return mode === C.RECORD_TYPES.COMPANY ? 'COMPANY' : mode === C.RECORD_TYPES.PERSON ? 'PEOPLE' : '—'; }
  function normalizeRecordType(record) { return record?.recordType === C.RECORD_TYPES.COMPANY ? C.RECORD_TYPES.COMPANY : C.RECORD_TYPES.PERSON; }

  async function loadData() {
    const filtered = await getCurrentScopeRecords();
    const visible = filtered.slice(-1000);
    // This metric is the number of rows displayed for the current view, not
    // the cumulative database total across previous pages/searches.
    els.totalCount.textContent = String(visible.length);
    renderTable(visible, Math.max(0, filtered.length - visible.length), currentMode, currentPageType);
  }

  async function refreshTab() {
    const seq = ++refreshSeq;
    const tab = await getActiveTab();
    activeTabId = tab?.id || null;
    const ping = await ensureContent(tab);
    // tabs.onActivated / onUpdated can fire several refreshes at once; only the
    // newest one may render, otherwise an older tab's state overwrites it.
    if (seq !== refreshSeq) return;
    lastPing = ping?.ok ? ping : null;
    if (!tab?.url) {
      els.urlIndicator.textContent = '—';
      currentMode = C.RECORD_TYPES.PERSON;
      setHint('Open a Sales Navigator people or company search.');
      return;
    }
    try { els.urlIndicator.textContent = new URL(tab.url).pathname.slice(0, 52); }
    catch (_) { els.urlIndicator.textContent = tab.url.slice(0, 52); }
    if (!ping) {
      currentPageType = 'unsupported'; currentSearchKey = '';
      setHint('Open LinkedIn People Search, My Network Connections, a person profile, or a Sales Navigator result page.');
      await loadData();
      return;
    }
    currentMode = ping.mode || C.RECORD_TYPES.PERSON;
    currentPageType = ping.pageType || 'unsupported';
    currentSearchKey = ping.url ? U.searchKey(ping.url) : '';
    const meta = await S.getMeta();
    renderState(meta, ping);
    renderPagination(ping, meta);
    await loadData();
  }

  function setHint(text) { els.statusHint.textContent = text; }

  function renderState(meta, ping = null) {
    currentMode = ping?.mode || meta?.recordType || currentMode;
    const state = meta?.state || C.STATES.IDLE;
    els.statusPill.textContent = state;
    els.statusPill.className = `status-pill ${state.toLowerCase()}`;
    els.modePill.textContent = modeLabel(currentMode);
    // The main metric is the count in the currently selected view. The global
    // database count was overwriting this during status refresh (e.g. 212 saved
    // across pages while only 25 rows belong to the current page/view).
    els.totalLabel.textContent = currentMode === C.RECORD_TYPES.COMPANY ? 'Current View Companies' : 'Current View People';
    void meta?.totalRecordsByType;
    els.pageCount.textContent = String(meta?.currentPage ?? (ping?.page ?? 1));
    els.duplicateCount.textContent = String(meta?.duplicates ?? 0);
    els.errorCount.textContent = String(meta?.errors ?? 0);
    els.progressBar.style.width = `${Math.max(0, Math.min(100, Number(meta?.scrollProgress || 0)))}%`;
    els.speedValue.textContent = formatSpeed(meta);
    els.etaValue.textContent = formatEta(meta);
    if (els.versionLabel) els.versionLabel.textContent = `v${C.VERSION}`;

    const active = [C.STATES.STARTING, C.STATES.SCROLLING, C.STATES.COLLECTING, C.STATES.SAVING, C.STATES.NEXT_PAGE, C.STATES.WAITING_PAGE];
    // Storage-change and command-response renders pass no ping. Fall back to the
    // last good one instead of treating "unknown" as "no live controller", which
    // flipped Pause/Resume to the orphaned-run state on every progress update.
    if (ping?.ok) lastPing = ping;
    const live = ping?.ok ? ping : lastPing;
    ping = live;
    const ownerElsewhere = !!(live?.runLeaseActive && !live?.runLeaseOwnedByThisTab && !live?.controllerActive);
    const orphanedRun = !!live && active.includes(state) && !live?.controllerActive && !ownerElsewhere;
    els.pauseBtn.disabled = !active.includes(state) || ownerElsewhere || orphanedRun;
    els.resumeBtn.disabled = !(state === C.STATES.PAUSED || orphanedRun) || ownerElsewhere;
    // A persisted RUNNING state with no live controller is an orphaned run.
    // Keep Stop available so the user can clear it; Resume can recover it.
    els.stopBtn.disabled = (!active.includes(state) && state !== C.STATES.PAUSED) || ownerElsewhere;
    els.startBtn.disabled = (active.includes(state) && !orphanedRun) || !!(ping && !ping.isListView) || ownerElsewhere;

    const coverage = meta?.pageCoverage;
    const coverageText = coverage ? (coverage.expected == null ? `Page ${coverage.page}: ${coverage.uniqueCollected} unique · list settled audit · unresolved ${coverage.unresolvedCount || 0}` : `Page ${coverage.page}: ${coverage.uniqueCollected}/${coverage.expected} unique · unresolved ${coverage.unresolvedCount || 0}`) : '';
    const risk = ping?.safetyRisk?.risky ? `Safety guard: ${ping.safetyRisk.reason}` : null;
    setHint(ownerElsewhere ? 'Another tab currently owns the extractor run. Stop or wait for that run before starting another.' : (risk || coverageText || meta?.lastError || meta?.currentStateReason || (ping?.isListView ? `${ping.rowsVisible} visible ${currentMode} result rows (${ping.pageType}).` : ping?.isProfileView ? 'Profile view detected. Use Extract Current Page Live to enrich this person; current Experience values require visible profile details.' : 'Open a supported LinkedIn people list.')));
  }

  function renderPagination(ping, meta) {
    const action = ping?.pagination?.action || 'none';
    const labels = {
      'next-page': 'Next page detected',
      'load-more': 'Load more detected',
      none: 'No pagination control detected'
    };
    els.paginationStatus.textContent = `${labels[action] || 'Automatic detection'}${ping?.pagination?.text ? ` — ${ping.pagination.text}` : ''}${meta?.expectedResultsPerPage ? ` · ${meta.expectedResultsPerPage}/page target` : ''}`;
  }

  function formatSpeed(meta) {
    const count = Number(meta?.collectedThisRun || 0);
    const started = Date.parse(meta?.startedAt || '');
    if (!started || !count) return '0/min';
    const minutes = Math.max((Date.now() - started) / 60000, 1 / 60);
    return `${Math.round(count / minutes)}/min`;
  }

  function formatEta(meta) {
    const total = Number(meta?.expectedTotal || 0);
    const done = Number(meta?.collectedThisRun || 0);
    const started = Date.parse(meta?.startedAt || '');
    if (!total || !started || done >= total) return '—';
    const perMin = done / Math.max((Date.now() - started) / 60000, 1 / 60);
    if (!perMin) return '—';
    const minutes = Math.max((total - done) / perMin, 0);
    return minutes < 60 ? `${Math.ceil(minutes)}m` : `${Math.floor(minutes / 60)}h ${Math.ceil(minutes % 60)}m`;
  }

  function renderTable(records, offset = 0, mode = C.RECORD_TYPES.PERSON, pageType = currentPageType) {
    const columns = U.getColumnsForPage ? U.getColumnsForPage(mode, pageType) : U.getColumns(mode);
    const label = mode === C.RECORD_TYPES.COMPANY ? 'Companies' : pageType === 'connections' ? 'Connections' : 'People';
    els.tableTitle.firstChild.textContent = `${label} `;
    els.tableRowCount.textContent = `${records.length} visible row${records.length === 1 ? '' : 's'}`;
    els.leadTableHead.replaceChildren();
    const thIndex = document.createElement('th');
    thIndex.textContent = '#';
    els.leadTableHead.appendChild(thIndex);
    columns.forEach((column) => {
      const th = document.createElement('th');
      th.textContent = column.label;
      els.leadTableHead.appendChild(th);
    });

    els.leadTableBody.replaceChildren();
    if (!records.length) {
      const empty = els.leadTableEmpty.cloneNode(true);
      empty.hidden = false;
      empty.querySelector('td').colSpan = columns.length + 1;
      empty.querySelector('td').textContent = `No ${label.toLowerCase()} collected yet.`;
      els.leadTableBody.appendChild(empty);
      return;
    }

    const fragment = document.createDocumentFragment();
    records.forEach((record, index) => {
      const tr = document.createElement('tr');
      const indexCell = document.createElement('td');
      indexCell.textContent = String(offset + index + 1);
      tr.appendChild(indexCell);
      columns.forEach((column) => {
        const td = document.createElement('td');
        if (column.key === 'companyProfileImageUrl' && record[column.key]) {
          const image = document.createElement('img');
          image.className = 'company-logo-thumb';
          image.src = record[column.key];
          image.alt = record.companyName || 'Company logo';
          image.loading = 'lazy';
          image.decoding = 'async';
          const link = document.createElement('a');
          link.href = record[column.key];
          link.target = '_blank';
          link.rel = 'noopener noreferrer';
          link.appendChild(image);
          td.appendChild(link);
        } else if (column.key.endsWith('LinkedInUrl') && record[column.key]) {
          const link = document.createElement('a');
          link.href = record[column.key];
          link.target = '_blank';
          link.rel = 'noopener noreferrer';
          link.textContent = record[column.key];
          td.appendChild(link);
        } else {
          td.textContent = U.exportValue(record, column.key);
        }
        tr.appendChild(td);
      });
      fragment.appendChild(tr);
    });
    els.leadTableBody.appendChild(fragment);
  }

  function populateSettings(settings) {
    els.setAutoScroll.checked = !!settings.autoScroll;
    els.setAutoScroll.title = settings.autoScroll ? 'Required for complete lazy/virtualized-result coverage.' : 'Without auto-scroll, the engine will not advance from an incomplete page.';
    els.setAutoNext.checked = !!settings.autoNextPage;
    els.setAutoSave.checked = !!settings.autoSave;
    els.setAutoResume.checked = !!settings.autoResume;
    els.setHumanMode.checked = !!settings.humanMode;
    els.setAutoDownload.checked = !!settings.autoDownload;
    els.setSafetyMode.checked = !!settings.safetyMode;
    els.setStopOnSecurity.checked = !!settings.stopOnSecurityPrompt;
    els.setDebug.checked = !!settings.debugMode;
    els.setScrollMin.value = settings.scrollMinPx;
    els.setScrollMax.value = settings.scrollMaxPx;
    els.setRetry.value = settings.retryCount;
    els.setTimeout.value = settings.timeoutMs;
    els.setMaxPages.value = settings.maxPages;
    els.setExpected.value = settings.expectedResultsPerPage;
    els.setAuditPasses.value = settings.pageAuditPasses;
    els.setActionDelayMin.value = settings.actionDelayMinMs;
    els.setActionDelayMax.value = settings.actionDelayMaxMs;
    els.setActionsPerMinute.value = settings.maxActionsPerMinute;
  }

  async function runCommand(type) {
    setHint(`${type.replace(/^LX_/, '').replaceAll('_', ' ').toLowerCase()} requested…`);
    let response = await sendToTab({ type });
    if (response?.noResponse) {
      await refreshTab();
      response = await sendToTab({ type });
    }
    if (!response?.ok) {
      setHint(response?.reason || 'The page did not respond. Refresh it and try again.');
      return;
    }
    currentMode = response.state?.recordType || currentMode;
    renderState(response.state || await S.getMeta());
    await loadData();
  }

  async function init() {
    const settings = await S.getSettings();
    document.body.classList.toggle('light', settings.darkMode === false);
    document.body.classList.toggle('dark', settings.darkMode !== false);
    if (els.versionLabel) els.versionLabel.textContent = `v${C.VERSION}`;
    populateSettings(settings);

    els.settingsBtn.addEventListener('click', () => { els.settingsPanel.hidden = !els.settingsPanel.hidden; });
    els.startBtn.addEventListener('click', () => runCommand('LX_START'));
    els.pauseBtn.addEventListener('click', () => runCommand('LX_PAUSE'));
    els.resumeBtn.addEventListener('click', () => runCommand('LX_RESUME'));
    els.stopBtn.addEventListener('click', () => runCommand('LX_STOP'));
    els.resetRunBtn.addEventListener('click', async () => {
      if (confirm('Reset the saved run state? Your collected records will remain.')) await runCommand('LX_RESET_RUN');
    });
    els.extractBtn.addEventListener('click', async () => {
      const response = await sendToTab({ type: 'LX_EXTRACT_PAGE' });
      if (!response?.ok) setHint(response?.reason || 'Current-page extraction failed.');
      else {
        currentMode = response.mode || currentMode;
        setHint(`Live extraction: ${response.foundOnPage} unique ${currentMode} rows detected.`);
        await loadData();
      }
    });
    els.clearBtn.addEventListener('click', async () => {
      const meta = await S.getMeta();
      const active = [C.STATES.STARTING, C.STATES.SCROLLING, C.STATES.COLLECTING, C.STATES.SAVING, C.STATES.NEXT_PAGE, C.STATES.WAITING_PAGE].includes(meta.state);
      if (active) { setHint('Stop or pause the current run before clearing data.'); return; }
      if (!confirm('Clear all collected records? This cannot be undone.')) return;
      await S.clearLeads();
      await S.setMeta({ totalLeads: 0, totalRecordsByType: { person: 0, company: 0 }, currentPageLeadCount: 0 });
      await loadData();
      setHint('All collected records cleared.');
    });
    els.copyAllBtn.addEventListener('click', async () => {
      const records = await getCurrentScopeRecords();
      if (records.length) { await E.copyAll(records, currentMode, currentPageType); setHint(`Copied ${records.length} ${currentMode} records.`); }
    });
    els.downloadCsvBtn.addEventListener('click', async () => {
      const records = await getCurrentScopeRecords();
      if (records.length) E.downloadCsv(records, currentMode, currentPageType);
    });
    els.downloadJsonBtn.addEventListener('click', async () => {
      const records = await getCurrentScopeRecords();
      if (records.length) E.downloadJson(records, { ...(await S.getMeta()), recordType: currentMode });
    });
    els.downloadXlsxBtn?.addEventListener('click', async () => {
      const records = await getCurrentScopeRecords();
      if (records.length) E.downloadXlsx(records, currentMode, currentPageType);
    });
    els.saveSettingsBtn.addEventListener('click', async () => {
      const patch = {
        autoScroll: els.setAutoScroll.checked,
        autoNextPage: els.setAutoNext.checked,
        autoSave: els.setAutoSave.checked,
        autoResume: els.setAutoResume.checked,
        humanMode: els.setHumanMode.checked,
        autoDownload: els.setAutoDownload.checked,
        safetyMode: els.setSafetyMode.checked,
        stopOnSecurityPrompt: els.setStopOnSecurity.checked,
        debugMode: els.setDebug.checked,
        scrollMinPx: Number(els.setScrollMin.value),
        scrollMaxPx: Number(els.setScrollMax.value),
        retryCount: Number(els.setRetry.value),
        timeoutMs: Number(els.setTimeout.value),
        maxPages: Number(els.setMaxPages.value),
        expectedResultsPerPage: Number(els.setExpected.value),
        pageAuditPasses: Number(els.setAuditPasses.value),
        actionDelayMinMs: Number(els.setActionDelayMin.value),
        actionDelayMaxMs: Number(els.setActionDelayMax.value),
        maxActionsPerMinute: Number(els.setActionsPerMinute.value)
      };
      // Blank/NaN or out-of-range inputs used to be stored verbatim.
      const saved = await S.saveSettings(window.LXSafety.validateSettings({ ...(await S.getSettings()), ...patch }));
      populateSettings(saved);
      await refreshTab();
      setHint('Settings saved. Supported LinkedIn views are detected automatically.');
    });

    chrome.storage.onChanged.addListener(async (changes, area) => {
      if (area !== 'local') return;
      if (changes.lx_meta) renderState(changes.lx_meta.newValue || {});
      if (changes.lx_leads) scheduleTableRefresh();
      if (changes.lx_settings) populateSettings({ ...C.DEFAULTS, ...(changes.lx_settings.newValue || {}) });
    });
    // Lead records are persisted in IndexedDB, so chrome.storage.onChanged is
    // not a signal for each saved row. Listen to the same cross-context channel
    // as storage.js and refresh the visible table as records stream in.
    try {
      recordsChannel = new BroadcastChannel('lx-sales-navigator-records');
      recordsChannel.onmessage = (event) => {
        if (event.data?.type === 'lead-upsert' || event.data?.type === 'lead-clear') scheduleTableRefresh();
      };
    } catch (_) { recordsChannel = null; }
    chrome.tabs.onActivated.addListener(refreshTab);
    chrome.tabs.onUpdated.addListener((tabId, info) => {
      if (tabId === activeTabId && (info.status === 'complete' || info.url)) void refreshTab();
    });

    const scheduleRefresh = () => {
      refreshTimer = setTimeout(async () => {
        refreshTimer = null;
        try {
          const meta = await S.getMeta();
          const tab = await getActiveTab();
          const ping = tab?.id === activeTabId ? await sendToTab({ type: 'LX_PING' }) : null;
          renderState(meta, ping);
          if (ping?.ok) renderPagination(ping, meta);
        } catch (_) {}
        if (!document.hidden) scheduleRefresh();
      }, 1200);
    };
    scheduleRefresh();
    document.addEventListener('visibilitychange', () => { if (!document.hidden && !refreshTimer) scheduleRefresh(); });
    await refreshTab();
  }

  window.addEventListener('unload', () => { if (refreshTimer) clearTimeout(refreshTimer); if (tableRefreshTimer) clearTimeout(tableRefreshTimer); recordsChannel?.close(); }, { once: true });
  document.addEventListener('DOMContentLoaded', init, { once: true });
})();
