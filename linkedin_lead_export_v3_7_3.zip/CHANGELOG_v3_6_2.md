# v3.6.2 — Connections scroll performance

- Reduced per-scroll settling pauses on the Connections infinite list while retaining a short render window.
- Reduced the no-movement timeout and bottom-of-list lazy-load wait for Connections only.
- Stop the scroll loop after three stagnant passes instead of repeatedly waiting through five stagnant passes.
- Other views, including Sales Navigator, keep their existing pacing and timeout behavior.
- Validation is local only; live LinkedIn performance must be confirmed in the user's browser.
