# v3.5.9 — Current-view counter and dual URL candidate

- Fixed the status refresh race that replaced the current-view count with the global saved-record count. The main metric now stays aligned with the current table/view.
- When Sales Navigator exposes only a `/sales/lead/<opaque-id>` URL, exports now also produce the requested `/in/<opaque-id>` candidate URL while preserving the original Sales Navigator URL in its own column.
- Existing real `/in/` URLs are still preferred when present.

## Important URL limitation
The `/in/<opaque-id>` value is a candidate generated from the Sales Navigator lead ID to match the requested legacy output format; it is not independently verified as a canonical public profile URL. LinkedIn may redirect or reject it. The extension does not visit each lead's profile to verify URLs.
