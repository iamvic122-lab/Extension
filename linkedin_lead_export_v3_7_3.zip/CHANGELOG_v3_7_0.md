# v3.7.0 — New 12-column Sales Navigator People export

## Export layout (Sales Navigator People search only)
Person Name | Job Title | Person LinkedIn URL | Person Sales Navigator URL | Company Name | Company LinkedIn URL | Location |
Connection Degree | Years in Role | Years in Company | About | Data Quality

- Person Sales Navigator URL is the clean `https://www.linkedin.com/sales/lead/<ID>` (no `,NAME_SEARCH,token`).
- The profile-only columns (current_job_period, headline,
  current_job_location, status) are no longer exported for this page type. They are still kept on the stored
  record and in the JSON export. Other page types (LinkedIn search, Connections, profile, Companies) are unchanged.
- Person LinkedIn URL: `/sales/lead/<ID>,NAME_SEARCH,<token>` becomes `https://www.linkedin.com/in/<ID>`.
- Company LinkedIn URL: `/sales/company/<id>` becomes `https://www.linkedin.com/company/<id>`.
- Missing values export as `N/A`. - Data Quality is calculated by the extension (percentage of the 9 data fields present, plus complete/partial/weak).

## Extraction (extractor.js, selectors.js)
- Years in Role / Years in Company are parsed from the "2 months in role | 2 months in company" line, including
  "1 year 3 months", "10+ years" and "Less than a year".
- Job Title no longer picks up the tenure line (it shares `data-anonymize="job-title"`).
- Location, employee count and About are never read from the floating company hover card by mistake.
- About is read without the "… Show more" control. New setting expands clamped About text first.
- Employee Count was removed (column, extraction, quality score and company hover-card reading). The extension never hovers or opens company hover cards.
- The old `.artdeco-entity-lockup__metadata span:nth-child(1)` employee-count fallback was removed.

## Settings
- "Expand Show more in About" (default on).

## Tests
- Updated sales-people column/export tests; added tenure, employee-count and N/A/Data Quality tests (29 pass).
- Added a browser fixture built from the real markup in tests/fixture-tests.js (not executed in the build sandbox).

## v3.7.3
- Company name is now also read when Sales Navigator shows it as plain text after the title (no company link), from the subtitle text or the hidden "See more about <company>" button label (never clicked). Company LinkedIn URL stays N/A for those rows because no link exists.
