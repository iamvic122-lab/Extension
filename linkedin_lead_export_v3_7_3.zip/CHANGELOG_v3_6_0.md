# v3.6.0

- Restored the established dual-URL behavior: derive `https://www.linkedin.com/in/<lead-id>` from the Sales Navigator `/sales/lead/<lead-id>,...` href for the Normal LinkedIn URL column.
- Preserve the original `/sales/lead/...` href separately in `sales_navigator_url`.
- Prefer a real same-person `/in/` anchor when one is available; otherwise derive the normal-form candidate from the Sales Navigator lead ID.
- Main metric now counts rows shown in the current table view rather than the cumulative record count.
- Fixed extension version metadata to 3.6.0 so the loaded build can be identified in the popup.
