/* selectors.js — all LinkedIn-facing DOM selectors live in one place. */
(function attachSelectors(root) {
  root.LXSelectors = Object.freeze({
    personResultRow: [
      'li.artdeco-list__item[data-x-search-result="LEAD"]',
      'li[data-x-search-result="LEAD"]',
      'ol[data-x-search-results-list] > li',
      'ul.artdeco-list > li.artdeco-list__item',
      'li.artdeco-list__item.pl3.pv3'
    ],
    companyResultRow: [
      'ol[data-x-search-results-list] > li',
      'ul.artdeco-list > li.artdeco-list__item',
      'li.artdeco-list__item',
      'article[role="listitem"]',
      '[role="listitem"]'
    ],
    personLink: [
      'a[data-anonymize="person-name"]',
      'a[href*="/sales/lead/"]',
      'a.ember-view[href*="/sales/lead/"]'
    ],
    personName: [
      '[data-anonymize="person-name"]',
      'a[href*="/in/"] > div p:first-of-type',
      'a[href*="/in/"] p:first-of-type',
      'span[data-anonymize="person-name"]',
      '.artdeco-entity-lockup__title a',
      '.artdeco-entity-lockup__title span'
    ],
    jobTitle: [
      '[data-anonymize="title"]',
      '[data-anonymize="job-title"]',
      '.artdeco-entity-lockup__subtitle span[data-anonymize="title"]',
      '.artdeco-entity-lockup__subtitle'
    ],
    companyLink: [
      'a[data-anonymize="company-name"][href*="/sales/company/"]',
      'a[data-anonymize="company-name"]',
      'a[href*="/sales/company/"]'
    ],
    companyName: [
      'a[data-anonymize="company-name"]',
      '[data-anonymize="company-name"]'
    ],
    companySearchLink: [
      'a[data-anonymize="company-name"][href*="/sales/company/"]',
      'a[href*="/sales/company/"]'
    ],
    industry: [
      '[data-anonymize="industry"]'
    ],
    companySize: [
      '[data-anonymize="company-size"]'
    ],
    personSubtitle: ['.artdeco-entity-lockup__subtitle'],
    companyA11yTrigger: ['button.entity-hovercard__a11y-trigger[aria-label^="See more about"]', 'button[aria-label^="See more about"]'],
    tenureMetadata: ['.artdeco-entity-lockup__metadata', '[data-anonymize="job-title"]'],
    aboutExpandButton: ['button[data-test-expand-button]', 'button[id*="ellipsis-button"]'],
    revenue: [
      '[data-anonymize="revenue"]',
      '[data-test="account-revenue"]'
    ],
    companyAboutExpandButton: [
      '[data-test-expand-button]'
    ],
    companyLogo: [
      'img[alt]'
    ],
    // Standard LinkedIn list/profile adapters. These selectors are intentionally
    // semantic-first; hashed CSS classes are not used as the primary contract.
    standardPersonLinks: [
      'a[data-view-name*="search-result-lockup-title"][href*="/in/"]',
      'a[href*="/in/"][data-test-app-aware-link]',
      'a[href*="/in/"]'
    ],
    standardRowsByPageType: {
      search: [
        'li.reusable-search__result-container',
        '[data-view-name="search-entity-result-universal-template"]',
        '[data-chameleon-result-urn]',
        '.entity-result'
      ],
      connections: [
        'li.mn-connection-card',
        '.mn-connection-card',
        '[data-view-name*="connection"]'
      ],
      grow: [
        'li.discover-entity-type-card',
        '.discover-entity-type-card',
        '[data-view-name*="discover"]',
        '[data-view-name*="grow"]',
        'main li[role="listitem"]'
      ]
    },
    standardPersonName: [
      '[data-anonymize="person-name"]',
      'a[href*="/in/"] > div p:first-of-type',
      'a[href*="/in/"] p:first-of-type',
      '.entity-result__title-text a span[aria-hidden="true"]',
      '.entity-result__title-text a',
      '.mn-connection-card__name',
      '[data-view-name*="search-result-lockup-title"] span[aria-hidden="true"]',
      'a[href*="/in/"] span[aria-hidden="true"]'
    ],
    standardListHeadline: [
      '.entity-result__primary-subtitle',
      '.search-result__info .entity-result__primary-subtitle',
      '.mn-connection-card__occupation',
      'a[href*="/in/"] p:nth-of-type(2)',
      '.discover-entity-type-card__subtitle',
      '[data-anonymize="headline"]',
      '[data-anonymize="title"]'
    ],
    standardListLocation: [
      '.entity-result__secondary-subtitle',
      '.mn-connection-card__location',
      '[data-anonymize="location"]',
      '[aria-label^="Location"]'
    ],
    profileName: [
      'main h1',
      'h1.text-heading-xlarge',
      '[data-anonymize="person-name"]'
    ],
    profileHeadline: [
      'main .pv-text-details__left-panel .text-body-medium',
      'main .mt2.relative .text-body-medium.break-words'
    ],
    profileLocation: [
      'main .pv-text-details__left-panel .text-body-small.inline.t-black--light.break-words',
      'main .pv-text-details__left-panel [aria-label^="Location"]'
    ],
    profileExperienceItems: [
      '[data-view-name="profile-component-entity"]',
      'li.pvs-list__paged-list-item',
      '#experience li'
    ],
    profileExperienceTitle: [
      '[data-field="experience_title"]',
      '.t-bold span[aria-hidden="true"]',
      '.display-flex.flex-column.full-width > span[aria-hidden="true"]'
    ],
    profileExperienceCompanyLink: [
      'a[href*="/company/"]'
    ],
    profileExperienceCompanyName: [
      '[data-field="experience_company"]',
      '.t-14.t-normal span[aria-hidden="true"]'
    ],
    profileExperiencePeriod: [
      'time',
      '.pvs-entity__caption-wrapper',
      '.t-14.t-normal.t-black--light span[aria-hidden="true"]'
    ],
    profileExperienceLocation: [
      '[data-field="experience_location"]',
      '.pvs-entity__caption-wrapper[data-field*="location"]'
    ],
    location: [
      '[data-anonymize="location"]',
      '.artdeco-entity-lockup__caption span[data-anonymize="location"]'
    ],
    employeeCount: [
      '[data-anonymize="company-size"]'
    ],
    connectionDegree: [
      '.artdeco-entity-lockup__degree',
      'span.artdeco-entity-lockup__degree',
      '[data-test-connection-degree]'
    ],
    premiumBadge: [
      'li-icon[type="linkedin-premium-gold-icon"]',
      'svg[data-test-icon="premium-app-medium"]',
      '.premium-icon',
      'img[alt*="Premium"]'
    ],
    about: [
      '[data-anonymize="person-blurb"]',
      '.result-lockup__highlight-keyword',
      '.artdeco-entity-lockup__content p'
    ],
    loading: [
      '[data-test-loading-indicator]',
      '.search-results-container .artdeco-loader',
      '.search-results-container [role="progressbar"]',
      '.search-results-container [aria-busy="true"]'
    ],
    paginationControl: 'button, a',
    nextTextSpan: 'span.artdeco-button__text',
    nextButton: [
      'button[data-test-pagination-next]',
      'button.artdeco-pagination__button--next',
      'button[aria-label*="Next"]',
      'button[title*="Next"]'
    ],
    nextLink: [
      'a[data-test-pagination-next]',
      'a.artdeco-pagination__link--next',
      'a[aria-label*="Next"]',
      'a[title*="Next"]'
    ],
    loadMoreButton: [
      'button[data-test-load-more]',
      'button[aria-label*="Load more"]',
      'button[aria-label*="load more"]',
      'button[title*="Load more"]',
      'button[title*="load more"]'
    ],
    securityMarkers: [
      '[data-test-security-challenge]',
      '[data-test-checkpoint]',
      '[data-test-verification]',
      'input[name="captcha"]',
      'iframe[src*="captcha"]',
      'iframe[src*="challenge"]'
    ]
  });
})(typeof window !== 'undefined' ? window : globalThis);
