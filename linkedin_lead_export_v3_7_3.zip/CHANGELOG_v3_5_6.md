# v3.5.6 — Sales Navigator record validation repair

## Fixed
- Never convert opaque `/sales/lead/` identifiers into fabricated `/in/` profile URLs.
- Keep Sales Navigator lead URLs in the dedicated `sales_navigator_url` field.
- Reject placeholder cards whose only displayed name is `View profile` or another generic action label.
- Match normal profile links using visible text, accessible label, title, or a nested person-name label when present.
- Added regression coverage for OUT_OF_NETWORK placeholder exclusion and URL separation.

## Limitations
- A normal `/in/` URL remains `N/A` when the actual result DOM does not expose a matching normal profile link. Deriving one from an opaque Sales Navigator ID is not reliable.
- Automated tests do not replace testing on the user's live Sales Navigator page.
