# v3.6.1 — Connections infinite-scroll reliability

- Improved Connections scrolling by bringing the last rendered connection card into view and falling back to the document viewport when the selected container does not move.
- Re-detect the scroll container on each pass to tolerate LinkedIn replacing list wrappers during lazy loading.
- Allow a longer settling window and additional no-change passes on Connections before deciding the list has stopped growing.
- Preserved Sales Navigator extraction, dual URL behavior, and current-view counter logic.

Validation is limited to local regression tests and static checks; live LinkedIn behavior must be confirmed in the user's browser.
