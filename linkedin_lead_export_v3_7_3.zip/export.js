/* export.js — safe CSV / JSON / clipboard export for one record type. */
(function attachExport(root) {
  const U = root.LX;
  function downloadFile(content, fileName, contentType) {
    const blob = new Blob([content], {type:contentType});
    const url=URL.createObjectURL(blob), anchor=document.createElement('a');
    anchor.href=url;anchor.download=fileName;anchor.rel='noopener';document.body.appendChild(anchor);anchor.click();anchor.remove();
    setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  function timestamp(){return new Date().toISOString().replace(/[:.]/g,'-');}
  function normalizeMode(mode, records){if(mode==='company'||mode==='person')return mode;return records?.[0]?.recordType==='company'?'company':'person';}
  function columnsFor(mode, pageType) { return U.getColumnsForPage ? U.getColumnsForPage(mode, pageType || '') : U.getColumns(mode); }
  function downloadCsv(records,mode=null,pageType=''){
    const resolved=normalizeMode(mode,records), columns=columnsFor(resolved,pageType);
    const header=columns.map(c=>U.csvEscape(c.label)).join(','), rows=(Array.isArray(records)?records:[]).map(r=>columns.map(c=>U.csvEscape(U.exportValue(r,c.key))).join(','));
    downloadFile(`\uFEFF${[header,...rows].join('\n')}`,`${resolved}_export_${timestamp()}.csv`,'text/csv');
  }
  function exportRows(records, mode, pageType='') {
    const columns=columnsFor(mode,pageType);
    return (Array.isArray(records)?records:[]).map((record)=>Object.fromEntries(columns.map((column)=>[column.key,U.exportValue(record,column.key)])));
  }
  function downloadJson(records,meta={}){
    const resolved=normalizeMode(meta.recordType,records);
    const source=Array.isArray(records)?records:[];
    const data={meta:{...meta,recordType:resolved,exportedAt:new Date().toISOString(),count:source.length},records:source};
    downloadFile(JSON.stringify(data,null,2),`${resolved}_export_${timestamp()}.json`,'application/json');
  }
  function xmlEscape(value) {
    return String(value == null ? '' : value)
      .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '')
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&apos;');
  }
  function columnName(index) {
    let result = '', number = index + 1;
    while (number > 0) { const remainder = (number - 1) % 26; result = String.fromCharCode(65 + remainder) + result; number = Math.floor((number - 1) / 26); }
    return result;
  }
  function u16(value) { return [value & 255, (value >>> 8) & 255]; }
  function u32(value) { return [value & 255, (value >>> 8) & 255, (value >>> 16) & 255, (value >>> 24) & 255]; }
  const crcTable = (() => {
    const table = new Uint32Array(256);
    for (let n=0;n<256;n+=1) { let c=n; for(let k=0;k<8;k+=1) c=(c&1)?(0xEDB88320^(c>>>1)):(c>>>1); table[n]=c>>>0; }
    return table;
  })();
  function crc32(bytes) {
    let crc = 0xFFFFFFFF;
    for (let i=0;i<bytes.length;i+=1) crc = crcTable[(crc ^ bytes[i]) & 0xFF] ^ (crc >>> 8);
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }
  function concatBytes(parts) {
    const length=parts.reduce((total,part)=>total+part.length,0), output=new Uint8Array(length); let offset=0;
    for(const part of parts){output.set(part,offset);offset+=part.length;} return output;
  }
  function zipStored(entries) {
    const encoder=new TextEncoder(), localParts=[], centralParts=[]; let offset=0;
    for(const entry of entries){
      const name=encoder.encode(entry.name), data=encoder.encode(entry.data), crc=crc32(data);
      const local=concatBytes([new Uint8Array([0x50,0x4b,0x03,0x04]),new Uint8Array(u16(20)),new Uint8Array(u16(0x0800)),new Uint8Array(u16(0)),new Uint8Array(u16(0)),new Uint8Array(u16(0x21)),new Uint8Array(u32(crc)),new Uint8Array(u32(data.length)),new Uint8Array(u32(data.length)),new Uint8Array(u16(name.length)),new Uint8Array(u16(0)),name,data]);
      localParts.push(local);
      const central=concatBytes([new Uint8Array([0x50,0x4b,0x01,0x02]),new Uint8Array(u16(20)),new Uint8Array(u16(20)),new Uint8Array(u16(0x0800)),new Uint8Array(u16(0)),new Uint8Array(u16(0)),new Uint8Array(u16(0x21)),new Uint8Array(u32(crc)),new Uint8Array(u32(data.length)),new Uint8Array(u32(data.length)),new Uint8Array(u16(name.length)),new Uint8Array(u16(0)),new Uint8Array(u16(0)),new Uint8Array(u16(0)),new Uint8Array(u16(0)),new Uint8Array(u32(0)),new Uint8Array(u32(offset)),name]);
      centralParts.push(central); offset+=local.length;
    }
    const centralBytes=concatBytes(centralParts), localBytes=concatBytes(localParts);
    const end=concatBytes([new Uint8Array([0x50,0x4b,0x05,0x06]),new Uint8Array(u16(0)),new Uint8Array(u16(0)),new Uint8Array(u16(entries.length)),new Uint8Array(u16(entries.length)),new Uint8Array(u32(centralBytes.length)),new Uint8Array(u32(localBytes.length)),new Uint8Array(u16(0))]);
    return concatBytes([localBytes,centralBytes,end]);
  }
  function makeXlsx(records, mode, pageType='') {
    const columns=columnsFor(mode,pageType), rows=exportRows(records,mode,pageType);
    const allRows=[columns.map((column)=>column.label),...rows.map((row)=>columns.map((column)=>row[column.key]))];
    const sheetRows=allRows.map((values,rowIndex)=>`<row r="${rowIndex+1}">${values.map((value,colIndex)=>{
      const reference=`${columnName(colIndex)}${rowIndex+1}`;
      return `<c r="${reference}" t="inlineStr"><is><t xml:space="preserve">${xmlEscape(value)}</t></is></c>`;
    }).join('')}</row>`).join('');
    const lastCell=`${columnName(Math.max(0,columns.length-1))}${Math.max(1,allRows.length)}`;
    const worksheet=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><dimension ref="A1:${lastCell}"/><sheetViews><sheetView workbookViewId="0"/></sheetViews><sheetFormatPr defaultRowHeight="15"/><sheetData>${sheetRows}</sheetData><pageMargins left="0.25" right="0.25" top="0.5" bottom="0.5" header="0.2" footer="0.2"/></worksheet>`;
    const entries=[
      {name:'[Content_Types].xml',data:'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>'},
      {name:'_rels/.rels',data:'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'},
      {name:'xl/workbook.xml',data:'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Export" sheetId="1" r:id="rId1"/></sheets></workbook>'},
      {name:'xl/_rels/workbook.xml.rels',data:'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>'},
      {name:'xl/styles.xml',data:'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'},
      {name:'xl/worksheets/sheet1.xml',data:worksheet}
    ];
    return zipStored(entries);
  }
  function downloadXlsx(records, mode=null, pageType='') {
    const resolved=normalizeMode(mode,records), bytes=makeXlsx(records,resolved,pageType);
    downloadFile(bytes,`${resolved}_export_${timestamp()}.xlsx`,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  }

  async function copyAll(records,mode=null,pageType=''){
    const resolved=normalizeMode(mode,records), columns=columnsFor(resolved,pageType), header=columns.map(c=>U.tsvEscape(c.label)).join('\t');
    const rows=(Array.isArray(records)?records:[]).map(r=>columns.map(c=>U.tsvEscape(U.exportValue(r,c.key))).join('\t'));
    await navigator.clipboard.writeText([header,...rows].join('\n'));
  }
  root.LXExport={downloadCsv,downloadJson,downloadXlsx,copyAll,_test:{exportRows,makeXlsx}};
})(typeof window !== 'undefined' ? window : globalThis);
