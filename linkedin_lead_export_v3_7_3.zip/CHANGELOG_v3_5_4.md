# v3.5.4 targeted fixes

- Standard People Search now prefers explicit result-card selectors and does not allow a broad profile-link fallback to override the actual result list.
- Fixed corrupted word-boundary checks that allowed recommendation/action text to contaminate names/headlines.
- Person names and headline fallbacks now reject connection degree and promotional/action text.
- Automatic Next detection supports LinkedIn standard-search generated wrappers when the exact visible Next label is inside main and supported result rows exist.
- Records are scoped by page type and normalized search/filter URL; switching between People Search, Connections, and different filters no longer displays another view's records. Data remains stored; it is not silently deleted.
- Table columns are view-specific: People Search shows fields available in its list cards; Connections shows the connected date; Sales Navigator retains the detailed schema.
- Grow is no longer a supported extraction view per the requested scope.
