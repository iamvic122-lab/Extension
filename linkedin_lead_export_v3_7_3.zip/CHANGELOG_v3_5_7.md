# v3.5.7 — Sales Navigator scrolling and pagination repair

## Fixed
- Scroll selection now prefers the result-list ancestor with the greatest scrollable range, avoiding nested wrappers that can trap collection at a partial set of visible rows.
- Pagination detection now recognizes exact `Next` / `Next page` labels from visible text, `aria-label`, or `title`, including role=button controls on supported Sales Navigator result views.
- Added regression tests for nested scrolling containers and generated-class Sales Navigator pagination controls.

## Known limitations
- The normal LinkedIn `/in/` URL remains `N/A` when the live result card does not expose a corresponding normal profile link. No opaque Sales Navigator ID is converted into a guessed URL.
- This build has automated fixture/regression validation only; live LinkedIn behavior must still be verified in the user's browser.
