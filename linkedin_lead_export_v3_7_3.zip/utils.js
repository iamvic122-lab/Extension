/* utils.js — shared URL, text, selector, timing and export helpers. */
(function attachUtils(root) {
  const NA = 'N/A';
  const C = root.LXConstants;
  const DEFAULT_LINKEDIN_ORIGIN = 'https://www.linkedin.com';
  function baseOrigin() {
    try {
      const origin = root.location?.origin || '';
      return isLinkedInHost(new URL(origin).hostname) ? origin : DEFAULT_LINKEDIN_ORIGIN;
    } catch (_) { return DEFAULT_LINKEDIN_ORIGIN; }
  }

  function cleanText(value) {
    if (value == null) return '';
    return String(value).replace(/[\u00a0\u200b]+/g, ' ').replace(/\s+/g, ' ').trim();
  }

  function isLinkedInHost(hostname) {
    return /(?:^|\.)linkedin\.com$/i.test(String(hostname || ''));
  }

  function normalizeUrl(rawUrl) {
    if (!rawUrl) return '';
    try {
      let candidate = String(rawUrl).trim();
      if (!candidate) return '';
      if (candidate.startsWith('//')) candidate = `https:${candidate}`;
      else if (candidate.startsWith('/')) candidate = `https://www.linkedin.com${candidate}`;
      else if (/^[^/]+\.[a-z]{2,}(?:\/|$)/i.test(candidate) && !/^[a-z][a-z0-9+.-]*:\/\//i.test(candidate)) candidate = `https://${candidate}`;
      const url = new URL(candidate, baseOrigin());
      if (!isLinkedInHost(url.hostname)) return '';
      url.protocol = 'https:';
      url.hostname = 'www.linkedin.com';
      url.search = '';
      url.hash = '';
      url.pathname = url.pathname.replace(/\/+/g, '/').replace(/\/$/, '');
      return url.toString();
    } catch (_) {
      return '';
    }
  }

  function normalizeMediaUrl(rawUrl) {
    const value = String(rawUrl || '').trim();
    if (!value) return '';
    try {
      const url = new URL(value, baseOrigin());
      return /^(?:[^/]+\.)?licdn\.com$/i.test(url.hostname) ? url.toString() : '';
    } catch (_) { return ''; }
  }

  function safeDecode(value) {
    try { return decodeURIComponent(value); } catch (_) { return String(value || ''); }
  }

  function firstPathSegment(value) {
    const clean = String(value || '').split(/[?#]/, 1)[0].replace(/^\/+/, '').trim();
    return safeDecode(clean.split(',')[0].trim());
  }

  function trustedPathFromReference(rawUrl) {
    if (!rawUrl) return '';
    const raw = String(rawUrl).trim();
    if (!raw) return '';
    // Relative LinkedIn hrefs are common in the DOM. Absolute URLs must be
    // HTTP(S) and hosted by linkedin.com or one of its subdomains.
    if (raw.startsWith('/') && !raw.startsWith('//')) return raw;
    if (/^[a-z][a-z0-9+.-]*:/i.test(raw) || raw.startsWith('//') || /^[^/]+\.[a-z]{2,}(?:\/|$)/i.test(raw)) {
      try {
        const candidate = raw.startsWith('//') ? `https:${raw}` : (/^[a-z][a-z0-9+.-]*:/i.test(raw) ? raw : `https://${raw}`);
        const parsed = new URL(candidate);
        if (!/^https?:$/i.test(parsed.protocol) || !isLinkedInHost(parsed.hostname)) return '';
        return parsed.pathname;
      } catch (_) { return ''; }
    }
    return raw;
  }

  function extractLeadIdentity(rawUrl) {
    const raw = trustedPathFromReference(rawUrl);
    if (!raw) return '';
    const match = raw.match(/\/sales\/lead\/([^/?#]+)/i) || raw.match(/\/in\/([^/?#]+)/i);
    return match ? firstPathSegment(match[1]) : '';
  }

  function extractCompanyIdentity(rawUrl) {
    const raw = trustedPathFromReference(rawUrl);
    if (!raw) return '';
    const match = raw.match(/\/sales\/company\/(\d+)/i) || raw.match(/\/company\/(\d+)/i) || raw.match(/\/sales\/company\/([^/?#]+)/i);
    return match ? firstPathSegment(match[1]) : '';
  }

  function isNormalProfileUrl(rawUrl) {
    const path = trustedPathFromReference(rawUrl);
    return /^\/in\/[^/?#]+(?:[/?#]|$)/i.test(path);
  }

  function normalizeSalesNavigatorUrl(rawUrl) {
    const path = trustedPathFromReference(rawUrl);
    if (!/^\/sales\/lead\/[^/?#]+/i.test(path)) return '';
    return normalizeUrl(rawUrl);
  }

  function convertLeadUrl(rawUrl) {
    // Prefer an actual normal profile URL. When the Sales Navigator result only
    // exposes its opaque lead identifier, provide the /in/<identifier> form used
    // by this extractor's established export contract as a candidate URL.
    // Keep the original /sales/lead URL separately; LinkedIn may redirect or
    // reject the candidate if that identifier is not routable as a public slug.
    if (isNormalProfileUrl(rawUrl)) {
      const url = normalizeUrl(rawUrl);
      return url && /\/in\/[^/]+$/i.test(new URL(url).pathname) ? url : '';
    }
    const identity = extractLeadIdentity(rawUrl);
    if (!identity || !/\/sales\/lead\//i.test(trustedPathFromReference(rawUrl))) return '';
    return `https://www.linkedin.com/in/${encodeURIComponent(identity)}`;
  }

  function convertCompanyUrl(rawUrl) {
    const identity = extractCompanyIdentity(rawUrl);
    if (identity) return `https://www.linkedin.com/company/${identity}`;
    const url = normalizeUrl(rawUrl);
    return url ? url.replace('/sales/company/', '/company/') : '';
  }

  function extractLeadId(inUrl) { return extractLeadIdentity(inUrl); }
  function extractCompanyId(inUrl) { return extractCompanyIdentity(inUrl); }

  function displayValue(value) {
    if (value == null || String(value).trim() === '' || /^N\/A$/i.test(String(value).trim())) return NA;
    return String(value).trim();
  }

  function calculateDataQuality(record) {
    const company = record?.recordType === C.RECORD_TYPES.COMPANY;
    const required = company ? ['companyName', 'companyLinkedInUrl'] : ['personName', 'personLinkedInUrl'];
    const core = company ? ['industry', 'employeeCount', 'revenue', 'about'] : ['jobTitle', 'companyName', 'location', 'companyLinkedInUrl', 'connectionDegree', 'yearsInRole', 'yearsInCompany', 'about'];
    const identityPresent = company
      ? required.every((key) => cleanText(record?.[key]).length > 0)
      : !!(cleanText(record?.personLinkedInUrl) || cleanText(record?.salesNavigatorUrl)) && !!cleanText(record?.personName);
    const present = core.reduce((count, key) => { const text = cleanText(record?.[key]); return count + (text && !/^N\/A$/i.test(text) ? 1 : 0); }, 0);
    const percent = Math.round((present / Math.max(1, core.length)) * 100);
    return { percent, status: !identityPresent ? 'invalid' : percent >= 80 ? 'complete' : percent >= 50 ? 'partial' : 'weak' };
  }

  function normalizeLead(rawLead) {
    const next = { ...(rawLead || {}) };
    next.recordType = next.recordType === C.RECORD_TYPES.COMPANY ? C.RECORD_TYPES.COMPANY : C.RECORD_TYPES.PERSON;
    // Accept both the legacy internal schema and the exact exported profile schema.
    const incomingUrl = cleanText(next.personLinkedInUrl || (next.url && !/^N\/A$/i.test(cleanText(next.url)) ? next.url : ''));
    next.personName = cleanText(next.personName || (next.person_name && !/^N\/A$/i.test(cleanText(next.person_name)) ? next.person_name : ''));
    next.jobTitle = cleanText(next.jobTitle || (next.job_title && !/^N\/A$/i.test(cleanText(next.job_title)) ? next.job_title : ''));
    next.companyName = cleanText(next.companyName || (next.company_name && !/^N\/A$/i.test(cleanText(next.company_name)) ? next.company_name : ''));
    next.companyLinkedInUrl = cleanText(next.companyLinkedInUrl || (next.company_profile_url && !/^N\/A$/i.test(cleanText(next.company_profile_url)) ? next.company_profile_url : ''));
    next.currentJobPeriod = cleanText(next.currentJobPeriod || (next.current_job_period && !/^N\/A$/i.test(cleanText(next.current_job_period)) ? next.current_job_period : ''));
    next.profileHeadline = cleanText(next.profileHeadline || (next.headline && !/^N\/A$/i.test(cleanText(next.headline)) ? next.headline : ''));
    next.currentJobLocation = cleanText(next.currentJobLocation || (next.current_job_location && !/^N\/A$/i.test(cleanText(next.current_job_location)) ? next.current_job_location : ''));
    next.location = cleanText(next.location || '');
    next.extractionStatus = cleanText(next.extractionStatus || next.status || '');
    const textFields = ['connectionDegree','about','yearsInRole','yearsInCompany','personLinkedInUrl','employeeCount','industry','revenue','capturedFromUrl','companyProfileImageUrl'];
    textFields.forEach((key) => { next[key] = cleanText(next[key]); });

    // Sales Navigator lead IDs are not normal LinkedIn profile slugs. Keep the
    // two URL types separate; only normalize an actual /in/ URL as a profile URL.
    const rawSalesNavigatorUrl = cleanText(next.salesNavigatorUrl || next.sales_navigator_url || '');
    next.salesNavigatorUrl = normalizeSalesNavigatorUrl(rawSalesNavigatorUrl);
    const normalCandidate = incomingUrl || next.personLinkedInUrl || rawSalesNavigatorUrl;
    next.personLinkedInUrl = normalCandidate ? convertLeadUrl(normalCandidate) : '';
    next.companyLinkedInUrl = convertCompanyUrl(next.companyLinkedInUrl);
    next.companyProfileImageUrl = normalizeMediaUrl(next.companyProfileImageUrl);
    next.leadId = cleanText(next.leadId ? firstPathSegment(next.leadId) : extractLeadIdentity(next.personLinkedInUrl));
    next.companyId = cleanText(next.companyId ? firstPathSegment(next.companyId) : extractCompanyIdentity(next.companyLinkedInUrl));
    next.premium = !!next.premium;
    next.currentExperienceVerified = !!next.currentExperienceVerified;
    next.extractionStatus = /^(?:ok|partial|error)$/i.test(next.extractionStatus)
      ? next.extractionStatus.toLowerCase()
      : (next.currentExperienceVerified && next.jobTitle && next.companyName ? 'ok' : 'partial');

    // Stable, exact output field aliases. Unavailable values stay N/A; they are
    // never inferred from unrelated labels or previous-company links.
    if (next.recordType === C.RECORD_TYPES.PERSON) {
      next.url = next.personLinkedInUrl || NA;
      next.sales_navigator_url = next.salesNavigatorUrl || NA;
      // Clean Sales Navigator profile URL: /sales/lead/<ID> without the ,NAME_SEARCH,<token> suffix.
      const salesLeadId = next.salesNavigatorUrl ? extractLeadIdentity(next.salesNavigatorUrl) : '';
      next.sales_lead_url = salesLeadId ? `https://www.linkedin.com/sales/lead/${encodeURIComponent(salesLeadId)}` : NA;
      next.person_name = next.personName || NA;
      next.job_title = next.jobTitle || NA;
      next.company_name = next.companyName || NA;
      next.company_profile_url = next.companyLinkedInUrl || NA;
      next.current_job_period = next.currentJobPeriod || NA;
      next.headline = next.profileHeadline || NA;
      next.location = next.location || NA;
      next.current_job_location = next.currentJobLocation || NA;
      next.status = next.extractionStatus;
    }
    next.sourceRow = Number.isFinite(Number(next.sourceRow)) ? Number(next.sourceRow) : 0;
    next.capturedAt = next.capturedAt || new Date().toISOString();
    next.lastSeenAt = next.lastSeenAt || next.capturedAt;
    next.dataQuality = calculateDataQuality(next);
    return next;
  }

  function leadKey(lead) {
    if (!lead) return '';
    const type = lead.recordType === C.RECORD_TYPES.COMPANY ? C.RECORD_TYPES.COMPANY : C.RECORD_TYPES.PERSON;
    // A name-only key requires a real name: `person:` / `company:` would
    // otherwise collapse every identity-less record into one row.
    if (type === C.RECORD_TYPES.COMPANY) {
      const name = cleanText(lead.companyName).toLowerCase();
      const id = lead.companyId || extractCompanyIdentity(lead.companyLinkedInUrl) || (name && !/^n\/a$/.test(name) ? `company:${name}` : '');
      return String(id || '').toLowerCase();
    }
    const name = cleanText(lead.personName).toLowerCase();
    const id = lead.leadId || extractLeadIdentity(lead.personLinkedInUrl) || (name && !/^n\/a$/.test(name) ? `person:${name}` : '');
    return String(id || '').toLowerCase();
  }

  function recordKey(record) { return leadKey(record); }

  function stableRowKey(row, mode = C.RECORD_TYPES.PERSON) {
    try {
      const selector = mode === C.RECORD_TYPES.COMPANY ? '[data-anonymize="company-name"]' : '[data-anonymize="person-name"]';
      const anchor = row?.querySelector(selector) || row?.querySelector(mode === C.RECORD_TYPES.COMPANY ? 'a[href*="/sales/company/"], a[href*="/company/"]' : 'a[href*="/sales/lead/"], a[href*="/in/"]');
      const href = anchor?.getAttribute('href') || '';
      const key = mode === C.RECORD_TYPES.COMPANY ? extractCompanyIdentity(href) : extractLeadIdentity(href);
      if (key) return `${mode}:${key}`;
      const text = cleanText(row?.innerText || row?.textContent || '').slice(0, 240).toLowerCase();
      return text ? `${mode}:text:${hashString(text)}` : '';
    } catch (_) { return ''; }
  }

  function pageKey(url = root.location?.href || DEFAULT_LINKEDIN_ORIGIN + '/') {
    try { const parsed = new URL(url); parsed.hash = ''; return parsed.toString(); }
    catch (_) { return String(url || ''); }
  }

  function searchKey(url = root.location?.href || DEFAULT_LINKEDIN_ORIGIN + '/') {
    try {
      const parsed = new URL(url); parsed.hash = '';
      ['page','start','cursor'].forEach((key) => parsed.searchParams.delete(key));
      return parsed.toString();
    } catch (_) { return String(url || ''); }
  }

  function pageNumber(url = root.location?.href || DEFAULT_LINKEDIN_ORIGIN + '/', fallback = 1) {
    try {
      const page = Number(new URL(url).searchParams.get('page'));
      return Number.isFinite(page) && page > 0 ? page : Number(fallback) || 1;
    } catch (_) { return Number(fallback) || 1; }
  }

  function hashString(value) {
    let hash = 2166136261;
    const input = String(value || '');
    for (let i = 0; i < input.length; i += 1) { hash ^= input.charCodeAt(i); hash = Math.imul(hash, 16777619); }
    return (hash >>> 0).toString(16).padStart(8, '0');
  }

  function isExtensionContextInvalidated(error) {
    return /extension context invalidated/i.test(cleanText(error?.message || error || ''));
  }

  function randomBetween(min, max) {
    const low = Math.min(Number(min) || 0, Number(max) || 0);
    const high = Math.max(Number(min) || 0, Number(max) || 0);
    return Math.round(low + Math.random() * (high - low));
  }

  function csvEscape(value) {
    let s = value == null ? '' : String(value);
    // Treat leading whitespace/control characters before formula prefixes as unsafe too.
    if (/^[\s\u0000-\u001f]*[=+\-@]/.test(s)) s = `'${s}`;
    return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  }

  function tsvEscape(value) {
    let s = String(value == null ? '' : value).replace(/[\t\r\n]+/g, ' ').trim();
    // Treat leading whitespace/control characters before formula prefixes as unsafe too.
    if (/^[\s\u0000-\u001f]*[=+\-@]/.test(s)) s = `'${s}`;
    return s;
  }

  function clamp(value, min, max) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return min;
    return Math.min(Math.max(numeric, min), max);
  }

  function escapeCss(value) {
    if (typeof CSS !== 'undefined' && typeof CSS.escape === 'function') return CSS.escape(String(value));
    return String(value).replace(/[^a-zA-Z0-9_-]/g, '\\$&');
  }

  function buildStableSelector(element) {
    if (!element || element.nodeType !== 1) return '';
    const tag = element.tagName.toLowerCase();
    const testAttrs = ['data-test-pagination-next','data-test-load-more','data-test-id','data-test'];
    for (const attr of testAttrs) {
      const value = element.getAttribute(attr);
      if (value) return `${tag}[${attr}="${value.replace(/"/g, '\\"')}"]`;
    }
    const aria = cleanText(element.getAttribute('aria-label') || '');
    if (aria) return `${tag}[aria-label="${aria.replace(/"/g, '\\"')}"]`;
    const title = cleanText(element.getAttribute('title') || '');
    if (title) return `${tag}[title="${title.replace(/"/g, '\\"')}"]`;
    return '';
  }

  const rootUtils = root.LX || {};
  root.LX = Object.assign(rootUtils, {
    NA, cleanText, normalizeUrl, normalizeMediaUrl, safeDecode, convertLeadUrl, convertCompanyUrl,
    isNormalProfileUrl, normalizeSalesNavigatorUrl,
    extractLeadId, extractCompanyId, extractLeadIdentity, extractCompanyIdentity, displayValue,
    calculateDataQuality, normalizeLead, leadKey, recordKey, stableRowKey, pageKey, searchKey, pageNumber,
    hashString, randomBetween, csvEscape, tsvEscape, clamp, buildStableSelector, isExtensionContextInvalidated,
    COLUMNS_BY_MODE: Object.freeze({
      person: Object.freeze([
        { key:'url', label:'url' }, { key:'person_name', label:'person_name' }, { key:'job_title', label:'job_title' },
        { key:'company_name', label:'company_name' }, { key:'company_profile_url', label:'company_profile_url' },
        { key:'current_job_period', label:'current_job_period' }, { key:'headline', label:'headline' },
        { key:'location', label:'location' }, { key:'current_job_location', label:'current_job_location' }, { key:'status', label:'status' }
      ]),
      company: Object.freeze([
        { key:'companyName', label:'Company Name' }, { key:'companyLinkedInUrl', label:'Company LinkedIn URL' }, { key:'industry', label:'Industry' },
        { key:'employeeCount', label:'Employee Count' }, { key:'revenue', label:'Revenue' }, { key:'about', label:'About' },
        { key:'companyProfileImageUrl', label:'Company Profile Image' }, { key:'companyId', label:'Company ID' }, { key:'dataQuality', label:'Data Quality' }
      ])
    }),
    getColumns(mode = 'person') { return this.COLUMNS_BY_MODE[mode] || this.COLUMNS_BY_MODE.person; },
    getColumnsForPage(mode = 'person', pageType = '') {
      if (mode === 'company') return this.COLUMNS_BY_MODE.company;
      if (pageType === 'sales-people') return Object.freeze([
        { key:'person_name', label:'Person Name' }, { key:'job_title', label:'Job Title' },
        { key:'url', label:'Person LinkedIn URL' }, { key:'sales_lead_url', label:'Person Sales Navigator URL' },
        { key:'company_name', label:'Company Name' },
        { key:'company_profile_url', label:'Company LinkedIn URL' }, { key:'location', label:'Location' },
        { key:'connectionDegree', label:'Connection Degree' },
        { key:'yearsInRole', label:'Years in Role' }, { key:'yearsInCompany', label:'Years in Company' },
        { key:'about', label:'About' }, { key:'dataQuality', label:'Data Quality' }
      ]);
      if (pageType === 'search') return Object.freeze([
        { key:'url', label:'url' }, { key:'person_name', label:'person_name' },
        { key:'headline', label:'headline' }, { key:'location', label:'location' }, { key:'status', label:'status' }
      ]);
      if (pageType === 'connections') return Object.freeze([
        { key:'url', label:'url' }, { key:'person_name', label:'person_name' },
        { key:'headline', label:'headline' }, { key:'connected_date', label:'connected_date' }, { key:'status', label:'status' }
      ]);
      return this.COLUMNS_BY_MODE.person;
    },
    exportValue(record, key) { return key === 'dataQuality' ? (record?.dataQuality ? `${record.dataQuality.percent}% ${record.dataQuality.status}` : NA) : displayValue(record?.[key]); },
    clone(value) { return value == null ? value : JSON.parse(JSON.stringify(value)); }
  });
})(typeof window !== 'undefined' ? window : globalThis);
