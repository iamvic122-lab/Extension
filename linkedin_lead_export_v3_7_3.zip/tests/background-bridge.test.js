'use strict';
// Tests the MV3 service-worker message bridge's authorization and dispatch shape.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const listeners = {};
const calls = [];
const mockStorage = {
  getLeads: async () => [{ personName: 'Fixture Person' }],
  getLeadCount: async () => 1,
  getCountByType: async () => ({ person: 1, company: 0 }),
  upsertLead: async (record) => ({ added: true, updated: false, lead: record }),
  mergeLeads: async (records) => ({ added: records.length, updated: 0, duplicates: 0 }),
  clearLeads: async () => { calls.push('clear'); },
};
const chrome = {
  runtime: {
    id: 'fixture-extension-id',
    onMessage: { addListener: (fn) => { listeners.message = fn; } },
    onInstalled: { addListener: (fn) => { listeners.installed = fn; } },
  },
  storage: { local: { get(_key, callback) { callback({}); }, set(_value, callback) { callback?.(); } } },
};
const context = vm.createContext({
  chrome, console, URL, Set, Promise, Date, Math,
  importScripts() {},
});
context.LXStorage = mockStorage;
vm.runInContext(fs.readFileSync(require('node:path').join(__dirname, '..', 'background.js'), 'utf8'), context, { filename: 'background.js' });

function dispatch(message, sender) {
  return new Promise((resolve) => {
    const returnsAsync = listeners.message(message, sender, resolve);
    if (returnsAsync !== true) resolve({ sync: true });
  });
}
(async () => {
  let response = await dispatch(
    { type: 'LX_DB_GET_LEAD_COUNT' },
    { id: 'fixture-extension-id', tab: { url: 'https://www.linkedin.com/search/results/people/' } },
  );
  assert.equal(response.ok, true);
  assert.equal(response.result, 1);

  response = await dispatch(
    { type: 'LX_DB_UPSERT_LEAD', record: { personName: 'Safe' } },
    { id: 'fixture-extension-id', tab: { url: 'https://www.linkedin.com/in/safe/' } },
  );
  assert.equal(response.ok, true);
  assert.equal(response.result.lead.personName, 'Safe');

  response = await dispatch(
    { type: 'LX_DB_CLEAR_LEADS' },
    { id: 'some-other-extension-id', tab: { url: 'https://www.linkedin.com/' } },
  );
  assert.equal(response.ok, false);
  assert.equal(calls.length, 0, 'unauthorized caller must not invoke storage');

  response = await dispatch(
    { type: 'LX_DB_CLEAR_LEADS' },
    { id: 'fixture-extension-id', tab: { url: 'https://evillinkedin.com/' } },
  );
  assert.equal(response.ok, false);
  assert.equal(calls.length, 0, 'non-LinkedIn sender must not invoke storage');
  console.log('PASS background storage bridge allows own extension on LinkedIn');
  console.log('PASS background storage bridge rejects foreign extension');
  console.log('PASS background storage bridge rejects non-LinkedIn host');
  console.log('RESULT 3 passed');
})().catch((error) => { console.error(error); process.exitCode = 1; });
