'use strict';
// Deterministic Node tests for pure shared behavior. DOM-specific extraction is covered by
// fixture-tests.html, which still needs a normal browser to execute.
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const rootDir = path.resolve(__dirname, '..');
const fakeDocument = { querySelectorAll: () => [], querySelector: () => null, body: { innerText: '' } };
const windowObject = { location: { href: 'https://www.linkedin.com/search/results/people/', origin: 'https://www.linkedin.com', pathname: '/search/results/people/' } };
const context = vm.createContext({
  window: windowObject,
  document: fakeDocument,
  URL,
  TextEncoder,
  Uint8Array,
  Uint32Array,
  Blob,
  console,
  setTimeout,
  clearTimeout,
  navigator: { clipboard: { writeText: async () => {} } }
});
for (const name of ['constants.js', 'logger.js', 'selectors.js', 'utils.js', 'linkedin_adapters.js', 'extractor.js', 'export.js']) {
  vm.runInContext(fs.readFileSync(path.join(rootDir, name), 'utf8'), context, { filename: name });
}
const U = windowObject.LX;
const A = windowObject.LXLinkedInAdapters;
const X = windowObject.LXExport;
const E = windowObject.LXExtractor;
const expectedColumns = ['url','person_name','job_title','company_name','company_profile_url','current_job_period','headline','location','current_job_location','status'];
let passed = 0;
function test(name, fn) {
  try { fn(); passed += 1; console.log(`PASS ${name}`); }
  catch (error) { console.error(`FAIL ${name}: ${error.stack || error}`); process.exitCode = 1; }
}

test('exact requested person export order', () => {
  assert.deepEqual(Array.from(U.getColumns('person'), (column) => column.key), expectedColumns);
});
test('People Search table uses fields visible in standard search cards', () => {
  assert.deepEqual(Array.from(U.getColumnsForPage('person','search'), (column) => column.key), ['url','person_name','headline','location','status']);
});
test('Connections table includes connected date and omits unavailable Experience fields', () => {
  assert.deepEqual(Array.from(U.getColumnsForPage('person','connections'), (column) => column.key), ['url','person_name','headline','connected_date','status']);
});
test('standard people-search context', () => {
  assert.equal(A.detectContext('https://www.linkedin.com/search/results/people/?keywords=dev', fakeDocument).pageType, 'search');
});
test('Connections context', () => {
  assert.equal(A.detectContext('https://www.linkedin.com/mynetwork/invite-connect/connections/', fakeDocument).pageType, 'connections');
});
test('Grow suggestions are intentionally unsupported in this release', () => {
  assert.equal(A.detectContext('https://www.linkedin.com/mynetwork/grow/', fakeDocument).pageType, 'unsupported');
});
test('profile enrichment context', () => {
  assert.equal(A.detectContext('https://www.linkedin.com/in/jane-doe/', fakeDocument).pageType, 'profile');
});
test('standard list adapter extracts only the labelled list fields', () => {
  const makeNode = (text) => ({ textContent:text || '', innerText:text || '', nodeType:1, tagName:'SPAN', children:[], parentElement:null, getAttribute:()=>null });
  let row;
  const anchor = { nodeType:1, tagName:'A', textContent:'Jordan Lee · 2nd', parentElement:null, children:[], getAttribute:(name)=>name==='href'?'/in/jordan-lee/':null };
  row = {
    nodeType:1, tagName:'LI', parentElement:fakeDocument.body, children:[],
    querySelectorAll(selector) { return selector.includes('href*="/in/"') ? [anchor] : []; },
    querySelector(selector) {
      if (selector === '.entity-result__title-text a span[aria-hidden="true"]') return makeNode('Jordan Lee');
      if (selector === '.entity-result__primary-subtitle') return makeNode('Product Engineer at Example');
      if (selector === '.entity-result__secondary-subtitle') return makeNode('Austin, Texas');
      return null;
    }
  };
  anchor.parentElement = row;
  const record = U.normalizeLead(A.readListPerson(row, 'search', 0, 'https://www.linkedin.com/search/results/people/'));
  assert.equal(record.person_name, 'Jordan Lee');
  assert.equal(record.headline, 'Product Engineer at Example');
  assert.equal(record.location, 'Austin, Texas');
  assert.equal(record.job_title, 'N/A');
  assert.equal(record.company_name, 'N/A');
  assert.equal(record.status, 'partial');
});
test('Connections card extracts the name and headline from nested profile-link paragraphs', () => {
  const makeParagraph = (text) => ({ nodeType:1, tagName:'P', textContent:text, innerText:text, children:[], parentElement:null, getAttribute:()=>null });
  const nameP = makeParagraph('Joe Cornicelli');
  const headlineP = makeParagraph('Business Development at Mahalo | CX Technology | B2B SaaS');
  const anchor = {
    nodeType:1, tagName:'A', textContent:'Joe CornicelliBusiness Development at Mahalo | CX Technology | B2B SaaS',
    parentElement:null, children:[nameP,headlineP], getAttribute:(name)=>name==='href'?'https://www.linkedin.com/in/joecornicelli/':null,
    querySelectorAll(selector){ return selector==='p'?[nameP,headlineP]:[]; }
  };
  nameP.parentElement=anchor; headlineP.parentElement=anchor;
  const row = {
    nodeType:1, tagName:'DIV', parentElement:fakeDocument.body, children:[anchor],
    getAttribute:()=>null,
    querySelectorAll(selector){ return String(selector).includes('href*="/in/"')?[anchor]:[]; },
    querySelector(){ return null; }
  };
  anchor.parentElement=row;
  const record = U.normalizeLead(A.readListPerson(row, 'connections', 0, 'https://www.linkedin.com/mynetwork/invite-connect/connections/'));
  assert.equal(record.person_name, 'Joe Cornicelli');
  assert.equal(record.headline, 'Business Development at Mahalo | CX Technology | B2B SaaS');
  assert.equal(record.url, 'https://www.linkedin.com/in/joecornicelli');
  assert.equal(record.job_title, 'N/A');
  assert.equal(record.status, 'partial');
});

test('list row with a valid profile URL but missing name is retained as error', () => {
  const anchor = { nodeType:1, tagName:'A', textContent:'', parentElement:null, children:[], getAttribute:(name)=>name==='href'?'/in/unnamed-person/':null };
  const row = { nodeType:1, tagName:'LI', parentElement:fakeDocument.body, children:[], querySelectorAll(selector){return selector.includes('href*="/in/"')?[anchor]:[];}, querySelector(){return null;} };
  anchor.parentElement = row;
  const record = U.normalizeLead(A.readListPerson(row, 'search', 0, 'https://www.linkedin.com/search/results/people/'));
  assert.equal(record.url, 'https://www.linkedin.com/in/unnamed-person');
  assert.equal(record.person_name, 'N/A');
  assert.equal(record.status, 'error');
});
test('profile current Experience fields stay together and general location comes from the header', () => {
  const textNode = (text, attrs = {}) => ({
    nodeType:1, tagName:'SPAN', textContent:text, innerText:text, children:[], parentElement:null,
    getAttribute:(name)=>Object.hasOwn(attrs,name)?attrs[name]:null,
    querySelector(){return null;}, querySelectorAll(){return [];}, closest(){return null;}
  });
  const heading = textNode('Experience'); heading.tagName = 'H2';
  const currentTitle = textNode('Staff Engineer');
  const previousTitle = textNode('Product Engineer');
  const currentPeriod = textNode('Jan 2023 – Present · 3 yrs');
  const previousPeriod = textNode('2019 – 2022');
  const currentCompany = textNode('Acme Inc. · Full-time', { href:'/company/acme-inc/' }); currentCompany.tagName = 'A';
  const previousCompany = textNode('OldCo · Full-time', { href:'/company/oldco/' }); previousCompany.tagName = 'A';
  const currentWorkLocation = textNode('Remote — United States');
  const previousWorkLocation = textNode('Chicago, Illinois');
  const makeEntry = (title, company, period, workLocation) => ({
    nodeType:1, tagName:'DIV', children:[], parentElement:null,
    querySelector(selector) {
      if (selector === '.t-bold span[aria-hidden="true"]') return title;
      if (selector === 'li li [data-view-name="profile-component-entity"]') return null;
      if (selector === '[data-field="experience_location"]') return workLocation;
      return null;
    },
    querySelectorAll(selector) {
      const normalizedSelector = String(selector);
      if (normalizedSelector === 'a[href*="/company/"]') return [company];
      if (normalizedSelector.includes('.pvs-entity__caption-wrapper') || normalizedSelector === 'time') return [period];
      return [];
    }
  });
  const currentEntry = makeEntry(currentTitle,currentCompany,currentPeriod,currentWorkLocation);
  const previousEntry = makeEntry(previousTitle,previousCompany,previousPeriod,previousWorkLocation);
  const section = {
    nodeType:1, tagName:'SECTION', children:[heading], parentElement:null,
    querySelector(selector){return selector==='h2'?heading:null;},
    querySelectorAll(selector){return selector==='[data-view-name="profile-component-entity"]'?[currentEntry,previousEntry]:[];}
  };
  const profileName = textNode('Jane Doe'); profileName.tagName='H1';
  const headline = textNode('Staff Engineer at Acme');
  const generalLocation = textNode('Seattle, Washington');
  const main = {
    nodeType:1, tagName:'MAIN', children:[section],
    querySelector(selector) {
      if (selector==='main h1') return profileName;
      if (selector==='main .pv-text-details__left-panel .text-body-medium') return headline;
      if (selector==='main .pv-text-details__left-panel .text-body-small.inline.t-black--light.break-words') return generalLocation;
      return null;
    },
    querySelectorAll(selector) { return selector==='main section, section'?[section]:[]; }
  };
  const doc={querySelector(selector){return selector==='main'?main:null;},querySelectorAll:main.querySelectorAll.bind(main),body:fakeDocument.body};
  const record=U.normalizeLead(A.extractProfilePerson(doc,'https://www.linkedin.com/in/jane-doe/'));
  assert.equal(record.person_name,'Jane Doe');
  assert.equal(record.job_title,'Staff Engineer');
  assert.equal(record.company_name,'Acme Inc.');
  assert.equal(record.company_profile_url,'https://www.linkedin.com/company/acme-inc');
  assert.equal(record.current_job_period,'Jan 2023 – Present');
  assert.equal(record.current_job_location,'Remote — United States');
  assert.equal(record.location,'Seattle, Washington');
  assert.equal(record.headline,'Staff Engineer at Acme');
  assert.equal(record.status,'ok');
});
test('Sales Navigator OUT_OF_NETWORK placeholder is not exported as a person', () => {
  windowObject.location.href = 'https://www.linkedin.com/sales/search/people';
  const placeholderAnchor = {
    nodeType:1, tagName:'A', textContent:'View profile', parentElement:null, children:[],
    getAttribute(name) {
      if (name === 'href') return '/sales/lead/ACwAA123,OUT_OF_NETWORK,token';
      if (name === 'aria-label') return 'View profile';
      return null;
    },
    querySelectorAll() { return []; }, querySelector() { return null; }
  };
  const row = {
    nodeType:1, tagName:'LI', children:[placeholderAnchor], parentElement:fakeDocument.body,
    querySelector(selector) { return String(selector).includes('data-anonymize="person-name"') || String(selector).includes('/sales/lead/') ? placeholderAnchor : null; },
    querySelectorAll(selector) { return String(selector).includes('/in/') ? [] : []; },
    getAttribute() { return null; }
  };
  placeholderAnchor.parentElement = row;
  assert.equal(E.extractPerson(row, 0), null);
  windowObject.location.href = 'https://www.linkedin.com/search/results/people/';
});
test('Sales Navigator People remains supported', () => {
  const context = A.detectContext('https://www.linkedin.com/sales/search/people?page=2', fakeDocument);
  assert.equal(context.pageType, 'sales-people'); assert.equal(context.mode, 'person');
});
test('Sales Navigator Company remains supported', () => {
  const context = A.detectContext('https://www.linkedin.com/sales/search/companies', fakeDocument);
  assert.equal(context.pageType, 'sales-company'); assert.equal(context.mode, 'company');
});
const salesPeopleLabels = ['Person Name','Job Title','Person LinkedIn URL','Person Sales Navigator URL','Company Name','Company LinkedIn URL','Location','Connection Degree','Years in Role','Years in Company','About','Data Quality'];
test('Sales Navigator people columns use the requested 12-column layout', () => {
  assert.deepEqual(Array.from(U.getColumnsForPage('person','sales-people'), column => column.label), salesPeopleLabels);
  assert.deepEqual(Array.from(U.getColumnsForPage('person','sales-people'), column => column.key), ['person_name','job_title','url','sales_lead_url','company_name','company_profile_url','location','connectionDegree','yearsInRole','yearsInCompany','about','dataQuality']);
});
test('Sales Navigator export rows follow the new layout and include a clean Sales Navigator URL column', () => {
  const record = U.normalizeLead({
    recordType:'person', personName:'Michael Noke', jobTitle:'Sales Development Representative', companyName:'LegiStorm',
    salesNavigatorUrl:'/sales/lead/ACwAAC_NWEgBpKPj5PJHq355-Z5RVhNbzzQMOq8,NAME_SEARCH,xdnu?_ntb=fcz1tS9OTQuNgub%2BhRnFJA%3D%3D',
    companyLinkedInUrl:'/sales/company/2713134?_ntb=fcz1tS9OTQuNgub%2BhRnFJA%3D%3D',
    location:'United States', employeeCount:'50 employees', connectionDegree:'3rd', yearsInRole:'2 months', yearsInCompany:'2 months', about:'Synopsis (getsynopsis.ai)'
  });
  const rows = X._test.exportRows([record], 'person', 'sales-people');
  assert.deepEqual(Object.keys(rows[0]), Array.from(U.getColumnsForPage('person','sales-people'), column => column.key));
  assert.equal(rows[0].person_name, 'Michael Noke');
  assert.equal(rows[0].url, 'https://www.linkedin.com/in/ACwAAC_NWEgBpKPj5PJHq355-Z5RVhNbzzQMOq8');
  assert.equal(rows[0].sales_lead_url, 'https://www.linkedin.com/sales/lead/ACwAAC_NWEgBpKPj5PJHq355-Z5RVhNbzzQMOq8');
  assert.equal(rows[0].company_profile_url, 'https://www.linkedin.com/company/2713134');
  assert.equal(rows[0].connectionDegree, '3rd');
  assert.equal(rows[0].yearsInRole, '2 months');
  assert.equal(rows[0].yearsInCompany, '2 months');
  assert.match(rows[0].dataQuality, /^\d+% (complete|partial|weak)$/);
  assert.equal(record.sales_navigator_url, 'https://www.linkedin.com/sales/lead/ACwAAC_NWEgBpKPj5PJHq355-Z5RVhNbzzQMOq8,NAME_SEARCH,xdnu');
});
test('missing Sales Navigator fields export as N/A and Data Quality reflects the gaps', () => {
  const record = U.normalizeLead({ recordType:'person', personName:'Example Person', salesNavigatorUrl:'/sales/lead/ACwAA123,NAME_SEARCH,token' });
  const row = X._test.exportRows([record], 'person', 'sales-people')[0];
  for (const key of ['job_title','company_name','company_profile_url','location','connectionDegree','yearsInRole','yearsInCompany','about']) assert.equal(row[key], 'N/A', key);
  assert.match(row.dataQuality, /^0% weak$/);
});
test('tenure text is split into years in role and years in company', () => {
  assert.deepEqual({ ...E.parseTenure('2 months in role 2 months in company') }, { role:'2 months', company:'2 months' });
  assert.deepEqual({ ...E.parseTenure('1 year 3 months in role | 4 years in company') }, { role:'1 year 3 months', company:'4 years' });
  assert.deepEqual({ ...E.parseTenure('Less than a year in role Less than a year in company') }, { role:'Less than a year', company:'Less than a year' });
  assert.deepEqual({ ...E.parseTenure('10+ years in company') }, { role:'', company:'10+ years' });
  assert.deepEqual({ ...E.parseTenure('Director of Sales') }, { role:'', company:'' });
});
test('Sales Navigator lead ID produces the requested /in candidate and preserves original URL', () => {
  const record = U.normalizeLead({ recordType:'person', personName:'Example Person', personLinkedInUrl:'', salesNavigatorUrl:'/sales/lead/ACwAA123,NAME_SEARCH,volatile-token', leadId:'ACwAA123' });
  assert.equal(record.url, 'https://www.linkedin.com/in/ACwAA123');
  assert.equal(record.sales_navigator_url, 'https://www.linkedin.com/sales/lead/ACwAA123,NAME_SEARCH,volatile-token');
  assert.equal(record.leadId, 'ACwAA123');
});
test('normal profile URL remains available alongside Sales Navigator URL', () => {
  const record = U.normalizeLead({ recordType:'person', personName:'Example Person', personLinkedInUrl:'/in/example-person/', salesNavigatorUrl:'/sales/lead/ACwAA123,NAME_SEARCH,token', leadId:'ACwAA123' });
  assert.equal(record.url, 'https://www.linkedin.com/in/example-person');
  assert.equal(record.sales_navigator_url, 'https://www.linkedin.com/sales/lead/ACwAA123,NAME_SEARCH,token');
});
test('Sales Navigator identity strips volatile lead search token for normal URL candidate', () => {
  assert.equal(U.convertLeadUrl('/sales/lead/ACwAA123,NAME_SEARCH,volatile-token'), 'https://www.linkedin.com/in/ACwAA123');
  assert.equal(U.normalizeSalesNavigatorUrl('/sales/lead/ACwAA123,NAME_SEARCH,volatile-token'), 'https://www.linkedin.com/sales/lead/ACwAA123,NAME_SEARCH,volatile-token');
  assert.equal(U.extractLeadIdentity('/sales/lead/ACwAA123,NAME_SEARCH,token'), U.extractLeadIdentity('/sales/lead/ACwAA123,NAME_SEARCH,other'));
});
test('Sales Navigator lead IDs create a separate /in candidate without overwriting Sales Navigator URL', () => {
  for (const href of ['/sales/lead/ACwAA123,NAME_SEARCH,token', 'https://www.linkedin.com/sales/lead/ACwAA123,OUT_OF_NETWORK,token']) {
    assert.match(U.convertLeadUrl(href), /^https:\/\/www\.linkedin\.com\/in\/ACwAA123$/);
    assert.ok(U.normalizeSalesNavigatorUrl(href));
  }
  assert.equal(U.convertLeadUrl('/in/real-profile-slug/'), 'https://www.linkedin.com/in/real-profile-slug');
});
test('malformed URL escapes do not crash normalization', () => {
  assert.equal(U.safeDecode('%E0%A4%A'), '%E0%A4%A');
  assert.doesNotThrow(() => U.normalizeLead({ recordType:'person', url:'https://www.linkedin.com/in/%E0%A4%A', person_name:'Person' }));
});
test('non-LinkedIn hosts are rejected before URL canonicalization', () => {
  assert.equal(U.normalizeUrl('https://evillinkedin.com/in/someone'), '');
  assert.equal(U.convertLeadUrl('https://evillinkedin.com/in/someone'), '');
  assert.equal(U.convertLeadUrl('javascript:alert(1)/in/someone'), '');
  assert.equal(U.convertCompanyUrl('https://evil.example/company/123'), '');
  assert.equal(A.detectContext('https://evil.example/search/results/people/', fakeDocument).pageType, 'unsupported');
});
test('utility URL normalization works in the service-worker context without window', () => {
  const worker = vm.createContext({ URL, console, Date, Math, Map, Set, Uint8Array, Uint32Array, TextEncoder, setTimeout, clearTimeout });
  vm.runInContext(fs.readFileSync(path.join(rootDir, 'constants.js'), 'utf8'), worker, { filename:'worker/constants.js' });
  vm.runInContext(fs.readFileSync(path.join(rootDir, 'utils.js'), 'utf8'), worker, { filename:'worker/utils.js' });
  assert.equal(worker.LX.normalizeMediaUrl('https://media.licdn.com/dms/image/example.png'), 'https://media.licdn.com/dms/image/example.png');
  assert.equal(worker.LX.convertLeadUrl('/in/worker-profile/'), 'https://www.linkedin.com/in/worker-profile');
});
test('unavailable exact fields normalize to N/A', () => {
  const record = U.normalizeLead({ recordType:'person', url:'https://www.linkedin.com/in/someone', person_name:'Someone' });
  for (const key of expectedColumns) assert.ok(Object.hasOwn(record, key), `missing ${key}`);
  for (const key of ['job_title','company_name','company_profile_url','current_job_period','headline','location','current_job_location']) assert.equal(record[key], 'N/A', key);
  assert.equal(record.status, 'partial');
});
test('CSV formula injection is neutralized', () => {
  const formulaCell = U.csvEscape('=HYPERLINK("x")');
  assert.ok(formulaCell.startsWith("\"'=HYPERLINK("), formulaCell);
  assert.ok(formulaCell.includes('\"\"x\"\"'), formulaCell);
  assert.equal(U.csvEscape('+SUM(A1:A2)'), "'+SUM(A1:A2)");
  assert.equal(U.csvEscape('  =SUM(A1:A2)').startsWith("'  ="), true);
});
test('CSV/XLSX use identical ordered person columns', () => {
  const record = U.normalizeLead({ recordType:'person', url:'https://www.linkedin.com/in/test-person', person_name:'Test Person', headline:'Engineer', location:'Dublin' });
  const row = X._test.exportRows([record], 'person')[0];
  assert.deepEqual(Object.keys(row), expectedColumns);
  const bytes = X._test.makeXlsx([record], 'person');
  assert.ok(bytes instanceof Uint8Array);
  assert.equal(bytes[0], 0x50); assert.equal(bytes[1], 0x4b);
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lx-export-test-'));
  const tempFile = path.join(tempDir, 'sample.xlsx');
  fs.writeFileSync(tempFile, Buffer.from(bytes));
  const saved = fs.readFileSync(tempFile);
  assert.equal(saved[0], 0x50); assert.equal(saved[1], 0x4b);
  fs.rmSync(tempDir, { recursive: true, force: true });
});
console.log(`RESULT ${passed} passed`);
