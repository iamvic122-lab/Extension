'use strict';
// Verifies that LinkedIn content contexts route record operations to the
// extension-owned storage bridge instead of silently opening host-origin IDB.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const messages = [];
const keys = { lx_host_indexeddb_imported_to_extension_v1: true };
const chrome = {
  runtime: {
    id: 'fixture-extension-id', lastError: null,
    sendMessage(message, callback) {
      messages.push(message);
      const result = message.type === 'LX_DB_UPSERT_LEAD'
        ? { added:true, updated:false, lead:message.record }
        : true;
      callback({ ok:true, result });
    },
  },
  storage: { local: {
    get(key, callback) {
      if (typeof key === 'string') callback({ [key]: keys[key] });
      else callback({});
    },
    set(value, callback) { Object.assign(keys, value); callback?.(); },
    remove(key, callback) { delete keys[key]; callback?.(); },
  } },
};
const windowObject = {
  document: { body:{} },
  location: { hostname:'www.linkedin.com', protocol:'https:', href:'https://www.linkedin.com/search/results/people/' },
  console,
};
const context = vm.createContext({
  window:windowObject, chrome, console, URL, Date, Math, Promise, Map, Set,
  Uint8Array, Uint32Array, TextEncoder, Blob, setTimeout, clearTimeout,
  BroadcastChannel:undefined,
});
const rootDir = path.resolve(__dirname, '..');
for (const name of ['constants.js', 'logger.js', 'utils.js', 'storage.js']) {
  vm.runInContext(fs.readFileSync(path.join(rootDir, name), 'utf8'), context, { filename:name });
}
(async () => {
  assert.equal(windowObject.LXStorage.isContentStorageBridge, true);
  const record = { recordType:'person', personName:'Bridge Test', personLinkedInUrl:'https://www.linkedin.com/in/bridge-test', leadId:'bridge-test', extractionStatus:'partial' };
  const result = await windowObject.LXStorage.upsertLead(record);
  assert.equal(result.added, true);
  assert.equal(messages.length, 1);
  assert.equal(messages[0].type, 'LX_DB_UPSERT_LEAD');
  assert.equal(messages[0].record.personName, 'Bridge Test');
  console.log('PASS LinkedIn content storage routes records to extension-origin IndexedDB bridge');
  console.log('PASS content context does not use local host-origin database for new record writes');
  console.log('RESULT 2 passed');
})().catch((error) => { console.error(error); process.exitCode = 1; });
