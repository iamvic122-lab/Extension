'use strict';
// Regression tests for scroll.js scrollToBottom():
//  1. stagnation is counted once per pass (it used to be counted up to 3x, so the
//     "three stagnant passes" Connections limit actually fired after ONE pass);
//  2. the document-viewport fallback only runs when the chosen container really
//     did not move (it used to run after every smooth scroll, doubling the distance).
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const dir = process.env.LX_DIR || path.resolve(__dirname, '..');
let passed = 0;
const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

function build(url, container, rows) {
  const body = { nodeType: 1, tagName: 'BODY', parentElement: null };
  const html = { nodeType: 1, tagName: 'HTML', parentElement: null, scrollHeight: 600, clientHeight: 600, scrollTop: 0 };
  body.parentElement = html;
  container.parentElement = body;
  rows.forEach((row) => { row.parentElement = container; });
  const calls = { windowScrollBy: 0 };
  const window = { location: { href: url }, scrollBy() { calls.windowScrollBy += 1; } };
  const document = { body, documentElement: html, scrollingElement: html, querySelector: () => null };
  const context = vm.createContext({ window, document, URL, console, setTimeout, clearTimeout, Date, Math, Promise, queueMicrotask,
    getComputedStyle: (el) => ({ overflowY: el === container ? 'auto' : 'visible', display: 'block', visibility: 'visible' }) });
  window.LX = { randomBetween: (a, b) => Math.round((Number(a) + Number(b)) / 2), cleanText: (v) => String(v || '').trim() };
  window.LXLogger = { debug() {}, info() {}, warning() {} };
  vm.runInContext(fs.readFileSync(path.join(dir, 'wait.js'), 'utf8'), context, { filename: 'wait.js' });
  vm.runInContext(fs.readFileSync(path.join(dir, 'scroll.js'), 'utf8'), context, { filename: 'scroll.js' });
  return { scroll: window.LXScroll, calls };
}
const settings = { humanMode: true, scrollMinPx: 400, scrollMaxPx: 400, scrollPauseMinMs: 5, scrollPauseMaxMs: 5, timeoutMs: 120, maxScrollPasses: 100 };
const attrs = () => ({ nodeType: 1, getAttribute: () => null, querySelector: () => null, textContent: 'row' });

test('Connections stops after exactly three stagnant passes (not after one)', async () => {
  const container = { nodeType: 1, tagName: 'DIV', scrollHeight: 1200, clientHeight: 600, scrollTop: 600, scrollBy() {}, scrollTo() {} };
  const rows = [attrs(), attrs()];
  const { scroll } = build('https://www.linkedin.com/mynetwork/invite-connect/connections/', container, rows);
  const result = await scroll.scrollToBottom({ findRows: () => rows, settings, shouldPause: () => false, onProgress: null, onScan: null });
  assert.equal(result.passes, 3, `expected 3 passes, got ${result.passes}`);
});

test('other views allow five stagnant passes', async () => {
  const container = { nodeType: 1, tagName: 'DIV', scrollHeight: 1200, clientHeight: 600, scrollTop: 600, scrollBy() {}, scrollTo() {} };
  const rows = [attrs(), attrs()];
  const { scroll } = build('https://www.linkedin.com/sales/search/people', container, rows);
  const result = await scroll.scrollToBottom({ findRows: () => rows, settings, shouldPause: () => false });
  assert.equal(result.passes, 5, `expected 5 passes, got ${result.passes}`);
});

test('document fallback is not triggered while an async smooth scroll is moving the container', async () => {
  const container = { nodeType: 1, tagName: 'DIV', scrollHeight: 3000, clientHeight: 600, scrollTop: 0, scrollTo() {},
    scrollBy({ top }) { setTimeout(() => { this.scrollTop = Math.min(this.scrollHeight - this.clientHeight, this.scrollTop + top); }, 25); } };
  const rows = [attrs(), attrs()];
  const { scroll, calls } = build('https://www.linkedin.com/search/results/people/?keywords=a', container, rows);
  await scroll.scrollToBottom({ findRows: () => rows, settings, shouldPause: () => false });
  assert.equal(calls.windowScrollBy, 0, `window.scrollBy was called ${calls.windowScrollBy} time(s)`);
});

test('document fallback runs when the container genuinely does not move', async () => {
  const container = { nodeType: 1, tagName: 'DIV', scrollHeight: 3000, clientHeight: 600, scrollTop: 0, scrollBy() {}, scrollTo() {} };
  const rows = [attrs()];
  const { scroll, calls } = build('https://www.linkedin.com/search/results/people/?keywords=a', container, rows);
  await scroll.scrollToBottom({ findRows: () => rows, settings: { ...settings, maxScrollPasses: 10 }, shouldPause: () => false });
  assert.ok(calls.windowScrollBy > 0, 'fallback should be attempted for a stuck container');
});

(async () => {
  for (const { name, fn } of tests) {
    try { await fn(); passed += 1; console.log(`PASS ${name}`); }
    catch (error) { console.error(`FAIL ${name}: ${error.message}`); process.exitCode = 1; }
  }
  console.log(`RESULT ${passed} passed`);
})();
