'use strict';
// validateSettings() must clamp every numeric setting the engine consumes.
// Previously maxActionsPerMinute / scroll distance / scroll pause were passed through raw:
// NaN disabled the rate limit (NaN comparisons are false) and 0 px stalled scrolling.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const dir = process.env.LX_DIR || path.resolve(__dirname, '..');
let passed = 0;
const ctx = vm.createContext({ console, URL, Date, Math, setTimeout, clearTimeout });
for (const f of ['constants.js', 'logger.js', 'utils.js', 'safety.js']) vm.runInContext(fs.readFileSync(path.join(dir, f), 'utf8'), ctx, { filename: f });
const { LXSafety: Safety, LXConstants: C } = ctx;
function test(name, fn) { try { fn(); passed += 1; console.log(`PASS ${name}`); } catch (e) { console.error(`FAIL ${name}: ${e.message}`); process.exitCode = 1; } }

test('NaN / blank maxActionsPerMinute cannot disable the rate limit', () => {
  const v = Safety.validateSettings({ ...C.DEFAULTS, maxActionsPerMinute: NaN });
  assert.ok(Number.isFinite(v.maxActionsPerMinute) && v.maxActionsPerMinute >= C.LIMITS.maxActionsPerMinute.min);
});
test('maxActionsPerMinute is bounded above', () => {
  assert.equal(Safety.validateSettings({ ...C.DEFAULTS, maxActionsPerMinute: 9999 }).maxActionsPerMinute, C.LIMITS.maxActionsPerMinute.max);
});
test('zero scroll distance is raised to the minimum', () => {
  const v = Safety.validateSettings({ ...C.DEFAULTS, scrollMinPx: 0, scrollMaxPx: 0 });
  assert.ok(v.scrollMinPx >= C.LIMITS.scrollMinPx.min && v.scrollMaxPx >= C.LIMITS.scrollMaxPx.min);
});
test('swapped scroll min/max are reordered', () => {
  const v = Safety.validateSettings({ ...C.DEFAULTS, scrollMinPx: 900, scrollMaxPx: 300 });
  assert.ok(v.scrollMinPx <= v.scrollMaxPx);
});
test('scroll pause is clamped and ordered', () => {
  const v = Safety.validateSettings({ ...C.DEFAULTS, scrollPauseMinMs: 99999, scrollPauseMaxMs: 1 });
  assert.ok(v.scrollPauseMinMs <= v.scrollPauseMaxMs && v.scrollPauseMaxMs <= C.LIMITS.scrollPauseMaxMs.max);
});
test('defaults pass through unchanged', () => {
  const v = Safety.validateSettings({ ...C.DEFAULTS });
  for (const k of ['scrollMinPx', 'scrollMaxPx', 'scrollPauseMinMs', 'scrollPauseMaxMs', 'maxActionsPerMinute']) assert.equal(v[k], C.DEFAULTS[k], k);
});
console.log(`RESULT ${passed} passed`);
