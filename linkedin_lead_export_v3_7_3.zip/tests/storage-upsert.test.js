'use strict';
// Regression tests for storage.js upsert/merge semantics, using an in-memory IndexedDB stand-in.
//  - re-seeing an unchanged person must be a duplicate, not an "update" (timestamps/sourceRow are volatile)
//  - a person re-collected from another search must stay visible in BOTH views (sourceScopes)
//  - identity-less records must not collapse onto one `person:` key
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const dir = process.env.LX_DIR || path.resolve(__dirname, '..');
let passed = 0;

function makeIndexedDB() {
  const rows = new Map();
  const req = (fn) => { const r = {}; setTimeout(() => { r.result = fn(); r.onsuccess && r.onsuccess(); }, 0); return r; };
  const db = {
    objectStoreNames: { contains: () => true }, createObjectStore() {},
    transaction() {
      const tx = { oncomplete: null, onerror: null, onabort: null };
      const done = () => setTimeout(() => tx.oncomplete && tx.oncomplete(), 5);
      const store = {
        get: (key) => req(() => rows.get(key)),
        getAll: () => req(() => [...rows.values()]),
        count: () => req(() => rows.size),
        put: (value) => { rows.set(value.key, JSON.parse(JSON.stringify(value))); done(); return req(() => undefined); },
        clear: () => { rows.clear(); done(); return req(() => undefined); }
      };
      tx.objectStore = () => store;
      return tx;
    }
  };
  return { open() { const r = {}; setTimeout(() => { r.result = db; r.onsuccess && r.onsuccess(); }, 0); return r; } };
}

function load() {
  const kv = {};
  const chrome = { runtime: { id: 'x' }, storage: { local: {
    get(keys, cb) { const list = Array.isArray(keys) ? keys : [keys]; const out = {}; list.forEach((k) => { if (k in kv) out[k] = kv[k]; }); cb(out); },
    set(value, cb) { Object.assign(kv, value); cb(); },
    remove(keys, cb) { (Array.isArray(keys) ? keys : [keys]).forEach((k) => delete kv[k]); cb(); }
  } } };
  const context = vm.createContext({ chrome, indexedDB: makeIndexedDB(), console, URL, setTimeout, clearTimeout, Date, Math, Promise });
  for (const file of ['constants.js', 'logger.js', 'utils.js', 'storage.js']) vm.runInContext(fs.readFileSync(path.join(dir, file), 'utf8'), context, { filename: file });
  return { S: context.LXStorage, U: context.LX };
}

const CONN = 'https://www.linkedin.com/mynetwork/invite-connect/connections';
const SEARCH = 'https://www.linkedin.com/search/results/people?keywords=ada';
const person = (extra = {}) => ({ recordType: 'person', personName: 'Ada Lovelace', url: 'https://www.linkedin.com/in/ada', sourcePageType: 'connections', sourceSearchKey: CONN, ...extra });

async function run(name, fn) {
  try { await fn(load()); passed += 1; console.log(`PASS ${name}`); }
  catch (error) { console.error(`FAIL ${name}: ${error.message}`); process.exitCode = 1; }
}

(async () => {
  await run('re-seeing an unchanged person is a duplicate, not an update', async ({ S, U }) => {
    const first = await S.upsertLead(U.normalizeLead(person({ capturedAt: '2026-01-01T00:00:00.000Z', lastSeenAt: '2026-01-01T00:00:00.000Z', sourceRow: 1 })));
    assert.equal(first.added, true);
    const second = await S.upsertLead(U.normalizeLead(person({ capturedAt: '2026-02-02T00:00:00.000Z', lastSeenAt: '2026-02-02T00:00:00.000Z', sourceRow: 9 })));
    assert.equal(second.added, false);
    assert.equal(second.updated, false, 'only volatile fields changed');
  });

  await run('a genuinely changed field still counts as an update', async ({ S, U }) => {
    await S.upsertLead(U.normalizeLead(person()));
    const changed = await S.upsertLead(U.normalizeLead(person({ profileHeadline: 'Mathematician' })));
    assert.equal(changed.updated, true);
    assert.equal(changed.lead.profileHeadline, 'Mathematician');
  });

  await run('a person collected from two searches stays visible in both views', async ({ S, U }) => {
    await S.upsertLead(U.normalizeLead(person()));
    const again = await S.upsertLead(U.normalizeLead(person({ sourcePageType: 'search', sourceSearchKey: SEARCH })));
    const scopes = again.lead.sourceScopes.map((x) => `${x.pageType}|${x.searchKey}`);
    assert.ok(scopes.includes(`connections|${CONN}`), 'original view kept');
    assert.ok(scopes.includes(`search|${SEARCH}`), 'new view added');
  });

  await run('connected_date from a later pass is not dropped', async ({ S, U }) => {
    await S.upsertLead(U.normalizeLead(person()));
    const next = await S.upsertLead(U.normalizeLead(person({ connected_date: 'Connected on March 3, 2026', connectedDate: 'Connected on March 3, 2026' })));
    assert.equal(next.lead.connected_date, 'Connected on March 3, 2026');
  });

  await run('identity-less records do not share one key', async ({ U }) => {
    assert.equal(U.leadKey({ recordType: 'person', personName: '' }), '');
    assert.equal(U.leadKey({ recordType: 'person', personName: 'N/A' }), '');
    assert.equal(U.leadKey({ recordType: 'company', companyName: '' }), '');
    assert.equal(U.leadKey({ recordType: 'person', personName: 'Ada' }), 'person:ada');
  });

  await run('N/A placeholders do not inflate data quality', async ({ U }) => {
    const q = U.normalizeLead({ recordType: 'person', personName: 'Ada', url: 'https://www.linkedin.com/in/ada' }).dataQuality;
    assert.equal(q.percent, 0);
  });

  console.log(`RESULT ${passed} passed`);
})();
