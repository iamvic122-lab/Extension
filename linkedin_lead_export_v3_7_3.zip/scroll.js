/* scroll.js — lazy-load scrolling and identity-based coverage sweeps. */
(function attachScroll(root) {
  const U = root.LX;
  const Logger = root.LXLogger;
  const Wait = root.LXWait;

  function isScrollable(el) {
    if (!el || el.nodeType !== 1) return false;
    try {
      const style = getComputedStyle(el);
      return ['auto','scroll','overlay'].includes(style.overflowY) && el.scrollHeight > el.clientHeight + 40;
    } catch (_) { return false; }
  }

  function findContainer(rows) {
    const sample = rows?.[0];
    const ancestors = [];
    let node = sample?.parentElement || null;
    while (node && node !== document.body && node !== document.documentElement) {
      if (isScrollable(node)) ancestors.push(node);
      node = node.parentElement;
    }
    // Sales Navigator can nest the result list inside a short, non-scrolling
    // wrapper while the real scrolling surface is a higher application pane.
    // Prefer the ancestor with the greatest scrollable range instead of the
    // first overflow element, which can trap the collector at 10–12 records.
    if (ancestors.length) {
      ancestors.sort((a, b) => (Number(b.scrollHeight || 0) - Number(b.clientHeight || 0)) - (Number(a.scrollHeight || 0) - Number(a.clientHeight || 0)));
      return ancestors[0];
    }

    const docScroller = document.scrollingElement || document.documentElement;
    const candidates = [];
    try {
      const main = document.querySelector('main');
      if (main) {
        let parent = main;
        while (parent && parent !== document.body && parent !== document.documentElement) {
          if (isScrollable(parent)) candidates.push(parent);
          parent = parent.parentElement;
        }
        for (const el of main.querySelectorAll('div,section,ul,ol')) {
          if (isScrollable(el) && (!sample || el.contains(sample))) candidates.push(el);
        }
      }
    } catch (_) {}
    if (isScrollable(docScroller)) candidates.push(docScroller);
    if (candidates.length) {
      const unique = [...new Set(candidates)];
      unique.sort((a, b) => (Number(b.scrollHeight || 0) - Number(b.clientHeight || 0)) - (Number(a.scrollHeight || 0) - Number(a.clientHeight || 0)));
      return unique[0];
    }
    return docScroller;
  }

  function isConnectionsPage() {
    try { return /\/mynetwork\/(?:invite-connect\/)?connections(?:\/|$)/i.test(new URL(window.location.href).pathname); }
    catch (_) { return /\/mynetwork\/(?:invite-connect\/)?connections(?:\/|$)/i.test(String(window.location?.href || '')); }
  }

  function scrollStep(container, rows, distance, settings) {
    const lastRow = rows?.[rows.length - 1];
    // Connections is a continuous lazy list: use instant scrolling there so the
    // scrollIntoView and scrollBy calls compose (a second smooth scroll cancels
    // the first one in Chromium) and no time is spent animating.
    const behavior = settings.humanMode && !isConnectionsPage() ? 'smooth' : 'auto';

    // Scrolling the last rendered card into view is more reliable than assuming
    // the card's nearest ancestor owns the scroll position; LinkedIn may put the
    // actual scroll surface on the page.
    if (isConnectionsPage() && lastRow?.scrollIntoView) {
      try { lastRow.scrollIntoView({ block: 'end', inline: 'nearest', behavior }); } catch (_) {}
    }
    try { container.scrollBy({ top: distance, left: 0, behavior }); } catch (_) {}
  }

  // Only called after waitForMovement() reports that the chosen container did
  // not move. It must not run synchronously after a smooth scrollBy(): the
  // scroll position has not changed yet at that point, so the check always
  // looked like "no movement" and the page was scrolled twice per pass.
  function fallbackScroll(container, distance) {
    const docScroller = document.scrollingElement || document.documentElement;
    const docBefore = Number(docScroller?.scrollTop || 0);
    try { window.scrollBy({ top: distance, left: 0, behavior: 'auto' }); } catch (_) {}
    try {
      if (docScroller && docScroller !== container && Math.abs(Number(docScroller.scrollTop || 0) - docBefore) <= 8) {
        docScroller.scrollTop = Math.min(Number(docScroller.scrollHeight || 0), docBefore + distance);
      }
    } catch (_) {}
  }

  function progressOf(container) {
    const max = Math.max(1, Number(container?.scrollHeight || 0) - Number(container?.clientHeight || 0));
    return Math.min(100, Math.round((Number(container?.scrollTop || 0) / max) * 100));
  }
  function atBottom(container, threshold = 48) { return container.scrollTop + container.clientHeight >= container.scrollHeight - threshold; }
  function rowFingerprint(rows) {
    return (rows || []).map((row) => {
      const anchor = row?.querySelector?.('a[href*="/in/"], a[href*="/sales/lead/"], a[href*="/sales/company/"], a[href*="/company/"]');
      return String(row?.getAttribute?.('data-chameleon-result-urn') || anchor?.getAttribute?.('href') || row?.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 180);
    }).filter(Boolean).join('|');
  }

  async function waitForMovement(container, beforeTop, settings, shouldCancel) {
    try {
      await Wait.waitForCondition(() => Math.abs(container.scrollTop - beforeTop) > 8 || atBottom(container), {
        root: container,
        timeoutMs: Math.min(Number(settings.timeoutMs) || 30000, isConnectionsPage() ? 1600 : 3500),
        pollMs: 80,
        shouldCancel
      });
      return true;
    } catch (error) {
      if (error?.code === 'WAIT_CANCELLED') return false;
      return false;
    }
  }

  async function pace(settings, shouldCancel) {
    if (!settings.humanMode) return true;
    // Connections is a continuous lazy list, not a page-by-page workflow.
    // Keep a short settling pause between scrolls so the extractor does not
    // spend most of its runtime sleeping after each already-rendered batch.
    if (isConnectionsPage()) {
      const min = Math.min(Number(settings.scrollPauseMinMs) || 250, 250);
      const max = Math.max(min, Math.min(Number(settings.scrollPauseMaxMs) || 550, 550));
      return Wait.wait(U.randomBetween(min, max), shouldCancel);
    }
    return Wait.wait(U.randomBetween(settings.scrollPauseMinMs, settings.scrollPauseMaxMs), shouldCancel);
  }

  async function scrollToBottom({ findRows, settings, shouldPause, onProgress, onScan }) {
    let container = findContainer(findRows());
    let passes = 0;
    let stagnantPasses = 0;
    const connections = isConnectionsPage();
    // Consecutive passes with no new rows, height growth or movement before we
    // conclude the list has stopped growing.
    const stagnantLimit = connections ? 3 : 5;
    const maxPasses = Math.max(10, Number(settings.maxScrollPasses) || 100);
    const pausedResult = () => ({ paused: true, progress: progressOf(container), scrollTop: container.scrollTop, passes });

    while (passes < maxPasses) {
      if (shouldPause()) return pausedResult();
      passes += 1;
      // LinkedIn may replace the list wrapper during lazy loading, so re-select
      // the scroll surface each pass rather than keeping a stale node.
      const freshContainer = findContainer(findRows());
      if (freshContainer && freshContainer !== container) container = freshContainer;
      const beforeRowList = findRows();
      const beforeRows = beforeRowList.length;
      const beforeFingerprint = rowFingerprint(beforeRowList);
      const beforeHeight = container.scrollHeight;
      const beforeTop = container.scrollTop;
      const distance = Math.max(50, U.randomBetween(settings.scrollMinPx, settings.scrollMaxPx));
      scrollStep(container, beforeRowList, distance, settings);
      let moved = await waitForMovement(container, beforeTop, settings, shouldPause);
      if (!moved && shouldPause()) return pausedResult();
      if (!moved) {
        // The selected container did not move; LinkedIn may scroll the page
        // itself. Try the document viewport once, then re-check.
        fallbackScroll(container, distance);
        moved = await waitForMovement(container, beforeTop, settings, shouldPause);
        if (!moved && shouldPause()) return pausedResult();
      }
      await pace(settings, shouldPause);
      if (shouldPause()) return pausedResult();
      if (typeof onScan === 'function') await onScan();

      const currentRowList = findRows();
      const currentRows = currentRowList.length;
      const currentFingerprint = rowFingerprint(currentRowList);
      const currentHeight = container.scrollHeight;
      const currentTop = container.scrollTop;
      let progressed = currentRows > beforeRows || currentHeight > beforeHeight || currentTop > beforeTop + 8 || currentFingerprint !== beforeFingerprint;

      if (atBottom(container)) {
        // At the bottom, lazy loading may still be fetching the next batch.
        const beforeBottomHeight = container.scrollHeight;
        const beforeBottomRowList = findRows();
        const beforeBottomRows = beforeBottomRowList.length;
        const beforeBottomFingerprint = rowFingerprint(beforeBottomRowList);
        try {
          await Wait.waitForCondition(() => { const current = findRows(); return current.length > beforeBottomRows || rowFingerprint(current) !== beforeBottomFingerprint || container.scrollHeight > beforeBottomHeight; }, {
            root: container, pollMs: 100, timeoutMs: Math.min(Number(settings.timeoutMs) || 30000, connections ? 2200 : 2500), shouldCancel: shouldPause
          });
          progressed = true;
          if (onScan) await onScan();
        } catch (error) {
          if (error?.code === 'WAIT_CANCELLED' && shouldPause()) return pausedResult();
        }
      }

      // Exactly one increment (or reset) per pass.
      if (progressed) stagnantPasses = 0; else stagnantPasses += 1;

      const progress = progressOf(container);
      if (onProgress) await onProgress({ progress, scrollTop: container.scrollTop, scrollHeight: container.scrollHeight, rows: findRows().length, passes });
      Logger.debug('Scroll pass', passes, 'progress', progress, 'rows', currentRows, 'stagnant', stagnantPasses);

      if (stagnantPasses >= stagnantLimit) break;
    }

    return { paused: false, progress: progressOf(container), scrollTop: container.scrollTop, scrollHeight: container.scrollHeight, passes };
  }

  async function auditCoverage({ findRows, settings, shouldPause, onScan, getUniqueCount, getUnresolvedCount, expectedCount }) {
    const rows = findRows();
    const container = findContainer(rows);
    const originalTop = Number(container.scrollTop || 0);
    const viewport = Math.max(240, Number(container.clientHeight || window.innerHeight || 600));
    const step = Math.max(180, Math.floor(viewport * 0.72));
    const maxPasses = Math.max(1, Math.min(Number(settings.pageAuditPasses) || 3, 5));
    let attempts = 0;
    let passes = 0;
    const hasExpectedCount = expectedCount != null && Number.isFinite(Number(expectedCount)) && Number(expectedCount) > 0;
    let previousUnique = getUniqueCount();
    let previousUnresolved = Number(getUnresolvedCount?.() || 0);

    const scan = async () => {
      if (shouldPause()) return false;
      try { await onScan?.(); return true; }
      catch (error) { Logger.debug('Coverage scan failed', error?.message || error); return true; }
    };

    // Fast path for lists that do not expose a total and are not virtualized:
    // when every collected identity is still present in the DOM, we are at the
    // bottom, and nothing is unresolved, a top-to-bottom re-sweep (which is
    // capped at maxScrollPasses and can take minutes on a long Connections
    // list) cannot discover anything new.
    if (!hasExpectedCount) {
      if (!(await scan())) return { paused: true, passes: 0, attempts: 0, uniqueCount: getUniqueCount(), unresolvedCount: Number(getUnresolvedCount?.() || 0), originalTop };
      const uniqueNow = getUniqueCount();
      const unresolvedNow = Number(getUnresolvedCount?.() || 0);
      const domRows = (findRows() || []).length;
      if (uniqueNow > 0 && unresolvedNow === 0 && domRows >= uniqueNow && atBottom(container)) {
        return { paused: false, passes: 1, attempts: 0, uniqueCount: uniqueNow, unresolvedCount: 0, expectedCount: null, complete: true, audited: true, auditMode: 'dom-complete', originalTop, finalTop: container.scrollTop };
      }
    }

    const moveAndScan = async (target) => {
      const before = container.scrollTop;
      container.scrollTo({ top: target, behavior: 'auto' });
      if (Math.abs(container.scrollTop - before) > 0) {
        try { await Wait.waitForCondition(() => Math.abs(container.scrollTop - before) > 8 || container.scrollTop === target, { root: container, timeoutMs: 1800, shouldCancel: shouldPause }); }
        catch (error) { if (error?.code === 'WAIT_CANCELLED') return false; }
      }
      attempts += 1;
      return scan();
    };

    const sweep = async (direction) => {
      if (!(await scan())) return false;
      let guard = 0;
      while (guard < Number(settings.maxScrollPasses || 100)) {
        if (shouldPause()) return false;
        guard += 1;
        const maxTop = Math.max(0, container.scrollHeight - container.clientHeight);
        const target = direction === 'down' ? Math.min(maxTop, container.scrollTop + step) : Math.max(0, container.scrollTop - step);
        if (target === container.scrollTop) break;
        if (!(await moveAndScan(target))) return false;
        if ((direction === 'down' && atBottom(container)) || (direction === 'up' && container.scrollTop <= 0)) break;
      }
      return true;
    };

    // Initial deterministic pass from top to bottom.
    container.scrollTo({ top: 0, behavior: 'auto' });
    await scan();
    passes += 1;
    if (!(await sweep('down'))) return { paused: true, passes, attempts, uniqueCount: getUniqueCount(), unresolvedCount: getUnresolvedCount?.() || 0, originalTop };

    let uniqueCount = getUniqueCount();
    let unresolvedCount = Number(getUnresolvedCount?.() || 0);
    let complete = hasExpectedCount ? uniqueCount >= Number(expectedCount) && unresolvedCount === 0 : false;

    // Recovery passes alternate direction so virtualized rows that disappear from the DOM are revisited.
    while (!complete && passes < maxPasses) {
      const beforeUnique = uniqueCount;
      const beforeUnresolved = unresolvedCount;
      passes += 1;
      if (!(await sweep('up'))) break;
      if (!(await sweep('down'))) break;
      uniqueCount = getUniqueCount();
      unresolvedCount = Number(getUnresolvedCount?.() || 0);
      complete = hasExpectedCount
        ? uniqueCount >= Number(expectedCount) && unresolvedCount === 0
        : uniqueCount > 0 && unresolvedCount === 0 && uniqueCount === beforeUnique && unresolvedCount === beforeUnresolved;
      if (!complete && uniqueCount === beforeUnique && unresolvedCount === beforeUnresolved && uniqueCount === previousUnique && unresolvedCount === previousUnresolved) break;
      previousUnique = uniqueCount;
      previousUnresolved = unresolvedCount;
    }

    container.scrollTo({ top: Math.max(0, container.scrollHeight - container.clientHeight), behavior: 'auto' });
    await scan();
    const finalUnique = getUniqueCount();
    const finalUnresolved = Number(getUnresolvedCount?.() || 0);
    const countSatisfied = hasExpectedCount ? finalUnique >= Number(expectedCount) : complete;
    return { paused: false, passes, attempts, uniqueCount: finalUnique, unresolvedCount: finalUnresolved, expectedCount: hasExpectedCount ? Number(expectedCount) : null, complete: countSatisfied && finalUnresolved === 0, audited: true, auditMode:hasExpectedCount?'expected-count':'settled-lazy-list', originalTop, finalTop: container.scrollTop };
  }

  root.LXScroll = { findContainer, progressOf, atBottom, scrollToBottom, auditCoverage };
})(typeof window !== 'undefined' ? window : globalThis);
