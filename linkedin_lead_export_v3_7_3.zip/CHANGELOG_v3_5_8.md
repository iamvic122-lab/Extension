# v3.5.8 — Sales Navigator URL lookup and counter clarity

- Normal profile URL matching first checks the lead card, then the currently rendered document for an exact-name `/in/` link.
- Renamed the global record counter to Saved People / Saved Companies; current-page row count remains separately shown above the table.
- Preserved pagination, collection, and storage logic.

Limitation: if LinkedIn does not render a matching normal-profile link in the current DOM, the normal URL remains N/A. No live LinkedIn test has been performed.
