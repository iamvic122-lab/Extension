# v3.6.3 — Scroll stability, duplicate accounting, popup reliability

Debug pass over v3.6.2. Every fix below has a regression test that fails on v3.6.2 and passes here
(`tests/scroll-loop.test.js`, `tests/storage-upsert.test.js`, `tests/settings-validation.test.js`).

## Scrolling (scroll.js, wait.js)
- **Stagnation was counted up to 3x per pass.** Three separate checks each incremented the counter, so the
  Connections "three stagnant passes" limit (and the five-pass limit elsewhere) actually fired after a single
  pass. A slow lazy-load batch could end collection early. It is now exactly one increment/reset per pass.
- **Document-scroll fallback ran after every smooth scroll.** `scrollBy({behavior:'smooth'})` has not moved the
  container yet when the code checked, so the "did not move" fallback always fired and the page was scrolled
  twice per pass. The fallback now runs only after the movement wait genuinely times out.
- Connections now scrolls instantly. Previously `scrollIntoView` and `scrollBy` were both smooth, and the second
  call cancels the first in Chromium.
- Coverage audit fast path: when a list exposes no total, is not virtualized (every collected identity is still in
  the DOM), is at the bottom and has nothing unresolved, the up/down re-sweep is skipped. On long Connections
  lists that sweep was capped at 100 passes per direction and dominated runtime.
- `waitForCondition` accepts `pollMs`; scroll waits poll every 80-100 ms instead of 300 ms.

## Settings (safety.js, popup.js)
- `maxActionsPerMinute`, `scrollMinPx/MaxPx` and `scrollPauseMin/MaxMs` were never clamped. A blank/NaN
  `maxActionsPerMinute` silently disabled the action rate limit; a 0 px scroll distance stalled scrolling.
  All are now clamped to `LIMITS` and min/max are ordered. The popup validates before saving.

## Storage / data (storage.js, utils.js, live_collector.js, controller.js)
- Re-seen records were always reported as "updated" (fresh `lastSeenAt`/`sourceRow` made them differ), so the
  Duplicates counter never moved. Change detection now ignores volatile fields.
- A person collected from a second search kept only their first search's scope, so they vanished from the
  second search's table and exports. Records now track `sourceScopes` (every view they were seen in).
- `connected_date` seen on a later pass was discarded by the merge.
- Records with no URL and no name all shared the key `person:`/`company:` and overwrote each other. Name-only keys now
  require a real name.
- A failed save marked the record's revision as seen, so it was never retried on that page. Failed saves now retry.
- N/A placeholders were counted as present data in the data-quality score.
- Speed: dropped 2 service-worker round-trips per saved record (counts are tracked locally) and the per-upsert
  `chrome.storage` read for the legacy-migration marker.

## Popup (popup.js, popup.html)
- Pause/Resume flickered into the "orphaned run" state on every progress update because renders without a ping
  assumed no live controller. The last good ping is reused.
- Buttons were dead until the first tab refresh finished (up to ~9 s on a busy page); listeners now attach first.
- A busy page that merely timed out was re-injected, stacking duplicate module copies. Injection now happens only
  when no content script is listening.
- Overlapping refreshes (tab activate + update) could render stale state; only the newest refresh renders.
- The 1.2 s status refresh loop now restarts after the popup becomes visible again.
- Footer version label corrected (was hard-coded v3.5.7).

## Validation
- Syntax checks on all JS; all prior suites still pass (26 + 3 + 2 + 2) plus 4 + 6 + 6 new tests.
- Live LinkedIn behavior has NOT been tested; confirm in your browser. The audit fast path assumes the
  Connections list keeps all loaded cards in the DOM (not virtualized).
