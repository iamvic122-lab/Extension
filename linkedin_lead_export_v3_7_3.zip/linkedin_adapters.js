/* linkedin_adapters.js — page-specific adapters for LinkedIn list and profile views.
 * Sales Navigator remains on its established extractor path. These adapters only
 * read visible DOM data; they do not open profiles or submit page actions.
 */
(function attachLinkedInAdapters(root) {
  const U = root.LX;
  const SEL = root.LXSelectors;
  const NA = 'N/A';

  function clean(value) { return U.cleanText(value || ''); }
  function normalizePersonName(value) {
    return clean(value)
      .replace(/\s*[·•]\s*(?:1st|2nd|3rd|\d+(?:st|nd|rd)?)(?:\s+connection)?\s*$/i, '')
      .replace(/\s+(?:Connect|Message|Pending|Follow)\s*$/i, '')
      .trim();
  }
  function firstText(node, selectors) {
    for (const selector of selectors || []) {
      try {
        const found = node?.querySelector(selector);
        const text = clean(found?.textContent);
        if (text) return text;
      } catch (_) {}
    }
    return '';
  }
  function all(node, selector) { try { return Array.from(node?.querySelectorAll(selector) || []); } catch (_) { return []; } }
  function safeUrl(href) { return U.convertLeadUrl(href || ''); }
  function isAncillaryProfileLink(anchor) {
    const ownText = clean(anchor?.textContent || anchor?.getAttribute?.('aria-label') || '');
    const parentText = clean(anchor?.parentElement?.textContent || '');
    // Mutual-connection links can look like valid profile links but are not
    // the person represented by the surrounding result card.
    if (/\b(?:is a )?mutual connection\b|\bother mutual connections?\b|\bsee open roles\b/i.test(parentText)
      && parentText.length <= 180 && (ownText.length === 0 || parentText.toLowerCase().includes(ownText.toLowerCase()))) return true;
    if (/^(?:see open roles|view profile|connect|message|follow)$/i.test(ownText)) return true;
    return false;
  }
  function personAnchors(node) {
    const candidates = all(node, SEL.standardPersonLinks.join(','))
      .filter((anchor) => safeUrl(anchor.getAttribute('href')) && !isExcluded(anchor) && !isAncillaryProfileLink(anchor));
    // LinkedIn often renders both the avatar and the name as separate links to
    // the same profile. Treat them as one identity and prefer the text-bearing
    // link so extraction does not accidentally select an image-only anchor.
    const byUrl = new Map();
    for (const anchor of candidates) {
      const url = safeUrl(anchor.getAttribute('href'));
      const score = (clean(anchor.textContent).length ? 10 : 0) + (all(anchor, 'p').length ? 5 : 0) + (all(anchor, '[aria-hidden="true"]').length ? 1 : 0);
      const previous = byUrl.get(url);
      if (!previous || score > previous.score) byUrl.set(url, { anchor, score });
    }
    return [...byUrl.values()].map((item) => item.anchor);
  }
  function isExcluded(node) {
    const blocked = /^(?:more profiles for you|explore premium profiles|activity|skills|interests|people also viewed|promoted|advertisement|sponsored)$/i;
    let current = node;
    while (current && current !== (root.document || document).body && current.nodeType === 1) {
      const label = clean(current.getAttribute?.('aria-label') || current.getAttribute?.('data-view-name') || '');
      if (blocked.test(label)) return true;
      // Recommendation/promotion content is often wrapped in a section whose
      // heading is nested inside a header div, not a direct child of the card.
      // Inspect section/region ancestors only; scanning <main> would suppress
      // legitimate search rows whenever any unrelated section exists nearby.
      const isSectionBoundary = current.tagName === 'SECTION' || current.getAttribute?.('role') === 'region';
      if (isSectionBoundary) {
        const headings = all(current, 'h1,h2,h3,h4,h5,h6,[role="heading"]');
        if (headings.some((heading) => blocked.test(clean(heading.textContent)))) return true;
      }
      for (const child of Array.from(current.children || [])) {
        if (!/^(H1|H2|H3|H4|H5|H6)$/.test(child.tagName) && child.getAttribute?.('role') !== 'heading') continue;
        if (blocked.test(clean(child.textContent))) return true;
      }
      current = current.parentElement;
    }
    return false;
  }
  function isInsideMain(node) {
    const main = document.querySelector('main');
    return !main || main.contains(node);
  }
  function rowForAnchor(anchor, pageType) {
    const cardSelectors = SEL.standardRowsByPageType[pageType] || [];
    for (const selector of cardSelectors) {
      try { const row = anchor.closest(selector); if (row && isInsideMain(row) && !isExcluded(row)) return row; } catch (_) {}
    }
    const listRow = anchor.closest('li, [role="listitem"], article');
    if (listRow && isInsideMain(listRow) && !isExcluded(listRow) && personAnchors(listRow).length === 1) return listRow;
    let current = anchor.parentElement;
    let fallback = current;
    for (let depth = 0; current && depth < 6 && current !== document.body; depth += 1, current = current.parentElement) {
      if (!isInsideMain(current) || isExcluded(current)) break;
      const links = personAnchors(current);
      if (links.length === 1) fallback = current;
      else if (links.length > 1) break;
    }
    return fallback && isInsideMain(fallback) && !isExcluded(fallback) ? fallback : null;
  }
  function dedupeRows(rows) {
    const seen = new Set(), result = [];
    for (const row of rows) {
      const anchor = personAnchors(row)[0];
      const url = safeUrl(anchor?.getAttribute('href'));
      const key = U.extractLeadIdentity(url) || clean(anchor?.textContent).toLowerCase();
      if (!key || seen.has(key)) continue;
      seen.add(key); result.push(row);
    }
    return result;
  }
  function detectContext(href = root.location?.href || '', doc = root.document) {
    let url;
    try { url = new URL(href, 'https://www.linkedin.com'); } catch (_) { return { pageType: 'unsupported', mode: null, isListView: false, isProfileView: false }; }
    const path = url.pathname.toLowerCase();
    if (!/(?:^|\.)linkedin\.com$/i.test(url.hostname)) return { pageType:'unsupported', mode:null, isListView:false, isProfileView:false, usesSalesNavigator:false };
    if (/^\/sales\/search\/people(?:\/|$)/.test(path)) return { pageType: 'sales-people', mode: 'person', isListView: true, isProfileView: false, usesSalesNavigator: true };
    if (/^\/sales\/search\/(?:companies?|accounts?)(?:\/|$)/.test(path)) return { pageType: 'sales-company', mode: 'company', isListView: true, isProfileView: false, usesSalesNavigator: true };
    if (/^\/sales\/search\//.test(path)) {
      const source = doc || root.document;
      const people = all(source, 'a[data-anonymize="person-name"][href*="/sales/lead/"], a[href*="/sales/lead/"]');
      const companies = all(source, 'a[data-anonymize="company-name"][href*="/sales/company/"]');
      if (people.length) return { pageType: 'sales-people', mode: 'person', isListView: true, isProfileView: false, usesSalesNavigator: true };
      if (companies.length) return { pageType: 'sales-company', mode: 'company', isListView: true, isProfileView: false, usesSalesNavigator: true };
    }
    if (/^\/search\/results\/people(?:\/|$)/.test(path)) return { pageType: 'search', mode: 'person', isListView: true, isProfileView: false, usesSalesNavigator: false };
    if (/^\/mynetwork\/(?:invite-connect\/)?connections(?:\/|$)/.test(path)) return { pageType: 'connections', mode: 'person', isListView: true, isProfileView: false, usesSalesNavigator: false };
    if (/^\/in\/[^/]+(?:\/|$)/.test(path)) return { pageType: 'profile', mode: 'person', isListView: false, isProfileView: true, usesSalesNavigator: false };
    // Fallbacks for LinkedIn route variants only. Require specific content evidence.
    const source = doc || root.document;
    if (source && /linkedin\.com$/i.test(url.hostname)) {
      if (path.includes('/mynetwork/') && all(source, SEL.standardRowsByPageType.connections.join(',')).length) return { pageType: 'connections', mode: 'person', isListView: true, isProfileView: false, usesSalesNavigator: false };
      if (path.startsWith('/search/') && all(source, SEL.standardRowsByPageType.search.join(',')).length) return { pageType: 'search', mode: 'person', isListView: true, isProfileView: false, usesSalesNavigator: false };
    }
    return { pageType: 'unsupported', mode: null, isListView: false, isProfileView: false, usesSalesNavigator: false };
  }

  function findRows(pageType, doc = root.document) {
    if (pageType === 'profile') {
      const main = doc.querySelector('main') || doc.body;
      return main ? [main] : [];
    }
    const selectors = SEL.standardRowsByPageType[pageType] || [];
    const candidates = [];
    for (const selector of selectors) {
      const matched = all(doc, selector).filter((row) => isInsideMain(row) && !isExcluded(row) && personAnchors(row).length > 0);
      if (matched.length) candidates.push({ selector, rows: dedupeRows(matched) });
    }
    // Prefer explicit result-card selectors. The semantic-link fallback can
    // see mutual connections/recommendations nested in a search card and must
    // never outvote a page's actual result-list selector just because it finds
    // more profile links.
    if (candidates.length) {
      // Selector order is intentional: exact result-card contracts outrank
      // generic entity wrappers, even if a recommendation module contains more.
      return candidates[0].rows;
    }
    const fallbackRows = [];
    for (const anchor of personAnchors(doc.querySelector('main') || doc)) {
      const row = rowForAnchor(anchor, pageType);
      if (row) fallbackRows.push(row);
    }
    return dedupeRows(fallbackRows);
  }

  function readListPerson(row, pageType, index = 0, sourceUrl = root.location?.href || '') {
    const anchor = personAnchors(row)[0];
    const url = safeUrl(anchor?.getAttribute('href'));
    const anchorParagraphs = all(anchor, 'p').map((node) => clean(node.textContent)).filter(Boolean);
    // On standard search cards, the name is usually the anchor's own text. On
    // Connections, LinkedIn nests both the name and headline inside the profile
    // anchor, with the name in the first paragraph and headline in the next.
    const plausibleName = (value) => {
      const text = normalizePersonName(value || '');
      if (!text || text.length > 80) return '';
      if (/\b(?:is hiring|mutual connections?|see open roles|current\s*:|connect|message|follow|open to work)\b/i.test(text)) return '';
      if (/\b(?:1st|2nd|3rd)\b.*\b(?:founder|director|manager|engineer|sales|marketing)\b/i.test(text)) return '';
      return text;
    };
    const directName = anchor ? clean(anchor.getAttribute('aria-label') || '') : '';
    const nameLinkText = anchor ? clean(anchor.textContent) : '';
    const personName = [
      firstText(row, SEL.standardPersonName),
      anchorParagraphs[0],
      directName,
      nameLinkText
    ].map(plausibleName).find(Boolean) || '';
    if (!url) return null;

    const status = personName ? 'partial' : 'error';
    let headline = firstText(row, SEL.standardListHeadline);
    if (!headline && pageType === 'connections' && anchorParagraphs.length > 1) headline = anchorParagraphs[1];
    if (!headline && pageType === 'search') {
      // Fallback to a short, non-control text line in the same result card.
      // Exclude the profile name, location, connection metadata and actions.
      const blockedText = /^(?:connect|message|follow|pending|see open roles|open to|\d+(?:st|nd|rd)\+?|\d+ mutual connections?)$/i;
      const candidates = all(row, 'p,span')
        .map((node) => clean(node.textContent))
        .filter((text) => text && normalizePersonName(text) !== personName && text.length <= 180 && !blockedText.test(text)
          && !/^(?:current\s*:|connected on\b|\d+ mutual connection|see open roles)/i.test(text)
          && !/\b(?:is hiring|mutual connection|see open roles|connect|message|follow)\b/i.test(text)
          && !/\s*[·•]\s*(?:1st|2nd|3rd|\d+(?:st|nd|rd)?)(?:\s+connection)?/i.test(text));
      headline = candidates.find((text) => !/^\d+(?:st|nd|rd)\b/i.test(text)) || '';
    }
    const location = firstText(row, SEL.standardListLocation);
    const connectedDate = pageType === 'connections'
      ? (all(row, 'p,span,time').map((node) => clean(node.textContent)).find((text) => /^connected on\s+/i.test(text)) || '')
      : '';
    const record = {
      recordType: 'person', personName: personName || '', personLinkedInUrl: url, leadId: U.extractLeadId(url),
      jobTitle: '', companyName: '', companyLinkedInUrl: '', currentJobPeriod: '',
      profileHeadline: headline, location, currentJobLocation: '', extractionStatus: status,
      url, person_name: personName || NA, job_title: NA, company_name: NA, company_profile_url: NA,
      current_job_period: NA, headline: headline || NA, current_job_location: NA,
      connected_date: connectedDate || NA, connectedDate, status, pageType, sourcePageType: pageType,
      sourceRow: index + 1, capturedFromUrl: sourceUrl, capturedAt: new Date().toISOString()
    };
    return record;
  }

  function sectionByHeading(doc, titlePattern) {
    for (const section of all(doc, 'main section, section')) {
      const heading = firstText(section, ['h2', 'h3', '[role="heading"]']);
      if (titlePattern.test(heading)) return section;
    }
    return null;
  }
  function visibleText(node) { return clean(node?.innerText || node?.textContent || ''); }
  function extractCurrentExperience(doc) {
    const section = sectionByHeading(doc, /^experience(?:\s|$)/i);
    if (!section) return { jobTitle: '', companyName: '', companyLinkedInUrl: '', currentJobPeriod: '', currentJobLocation: '' };
    const entrySelectors = SEL.profileExperienceItems;
    let candidates = [];
    for (const selector of entrySelectors) {
      candidates = all(section, selector);
      if (candidates.length) break;
    }
    // Avoid selecting a wrapper that contains multiple experience entries.
    candidates = candidates.filter((entry) => firstText(entry, SEL.profileExperienceTitle) && !entry.querySelector('li li [data-view-name="profile-component-entity"]'));
    if (!candidates.length) {
      candidates = all(section, 'li').filter((entry) => firstText(entry, SEL.profileExperienceTitle));
    }
    const periodSelector = SEL.profileExperiencePeriod.join(',');
    const hasCurrentPeriod = (entry) => {
      const captions = all(entry, periodSelector).map(visibleText);
      if (captions.some((text) => /\b(?:present|current|now)\b/i.test(text) && /\d{4}/.test(text))) return true;
      return /(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{4}\s*[-–—]\s*(?:Present|Current|Now)|\b\d{4}\s*[-–—]\s*(?:Present|Current|Now)/i.test(visibleText(entry));
    };
    const current = candidates.find(hasCurrentPeriod) || null;
    if (!current) return { jobTitle: '', companyName: '', companyLinkedInUrl: '', currentJobPeriod: '', currentJobLocation: '' };

    const jobTitle = firstText(current, SEL.profileExperienceTitle);
    const companyLink = all(current, SEL.profileExperienceCompanyLink).find((a) => clean(a.textContent) && !a.closest('h1,h2,h3')) || null;
    let companyName = clean(companyLink?.textContent) || firstText(current, SEL.profileExperienceCompanyName);
    companyName = companyName.replace(/\s*[·•]\s*(?:full[- ]time|part[- ]time|contract|temporary|internship|freelance|self-employed|seasonal|volunteer)\b.*$/i, '').trim();
    let companyLinkedInUrl = companyLink ? U.convertCompanyUrl(companyLink.getAttribute('href') || '') : '';
    if (!companyLinkedInUrl && companyLink?.getAttribute('href')) companyLinkedInUrl = U.normalizeUrl(companyLink.getAttribute('href'));

    let currentJobPeriod = '';
    const dateCandidates = all(current, periodSelector);
    for (const item of dateCandidates) {
      const text = visibleText(item);
      if (/\b(?:present|current|now)\b/i.test(text) && /\b\d{4}\b/.test(text)) {
        currentJobPeriod = text.split(/\s*[·•]\s*/)[0].replace(/\s*[-–—]\s*/g, ' – ').trim();
        break;
      }
    }
    if (!currentJobPeriod) {
      const match = visibleText(current).match(/((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+)?\d{4}\s*[-–—]\s*(?:Present|Current|Now)/i);
      if (match) currentJobPeriod = match[0].replace(/\s*[-–—]\s*/g, ' – ').trim();
    }
    const currentJobLocation = firstText(current, SEL.profileExperienceLocation);
    return { jobTitle, companyName, companyLinkedInUrl, currentJobPeriod, currentJobLocation };
  }

  function extractProfilePerson(doc = root.document, currentUrl = root.location?.href || '') {
    const profileRoot = doc.querySelector('main') || doc;
    const url = safeUrl(currentUrl) || safeUrl(root.location?.href || '');
    const personName = firstText(profileRoot, SEL.profileName);
    if (!url) return null;
    const headline = firstText(profileRoot, SEL.profileHeadline);
    const location = firstText(profileRoot, SEL.profileLocation);
    const experience = extractCurrentExperience(profileRoot);
    const hasCurrentRole = !!(experience.jobTitle && experience.companyName);
    const status = !personName ? 'error' : (hasCurrentRole && experience.currentJobPeriod ? 'ok' : 'partial');
    const fields = {
      recordType: 'person', personName: personName || '', personLinkedInUrl: url, leadId: U.extractLeadId(url),
      jobTitle: experience.jobTitle, companyName: experience.companyName,
      companyLinkedInUrl: experience.companyLinkedInUrl, currentJobPeriod: experience.currentJobPeriod,
      profileHeadline: headline, location, currentJobLocation: experience.currentJobLocation,
      extractionStatus: status, currentExperienceVerified: hasCurrentRole,
      url, person_name: personName || NA, job_title: experience.jobTitle || NA,
      company_name: experience.companyName || NA, company_profile_url: experience.companyLinkedInUrl || NA,
      current_job_period: experience.currentJobPeriod || NA, headline: headline || NA,
      location: location || NA, current_job_location: experience.currentJobLocation || NA,
      status, pageType: 'profile', capturedFromUrl: currentUrl, capturedAt: new Date().toISOString()
    };
    return fields;
  }

  root.LXLinkedInAdapters = { detectContext, findRows, readListPerson, extractProfilePerson, extractCurrentExperience, isExcluded };
})(typeof window !== 'undefined' ? window : globalThis);
