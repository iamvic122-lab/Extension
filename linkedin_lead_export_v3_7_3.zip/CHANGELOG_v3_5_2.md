# v3.5.2 — targeted stabilization change log

- Added a page adapter for standard LinkedIn People Search, My Network Connections, and My Network Grow suggestions while retaining Sales Navigator People and Company adapters.
- Added explicit manual profile enrichment from `/in/<slug>`; no profile auto-opening is introduced.
- Standardized person CSV/XLSX output to the requested ten fields in the exact requested order, using `N/A` for unavailable fields.
- Scoped current-role fields to one current Experience entry; person headline and general location use header-scoped selectors instead of broad Experience fallbacks.
- A usable profile URL with a missing name now produces an `error` status record rather than disappearing.
- Added XLSX export generated locally without a runtime dependency; CSV and XLSX share the same column projection.
- Fixed immediate Resume racing with the prior paused loop’s shutdown and made explicit Resume work when automatic resume is turned off.
- Prevented weaker list-card extraction status from downgrading a previously enriched `ok` record.
- Tightened URL host validation before canonicalizing person/company identities; non-LinkedIn absolute URLs are rejected.
- Moved the authoritative records database to the extension-origin MV3 service worker. Content scripts use a sender-validated message bridge because content-script IndexedDB is scoped to the LinkedIn host origin, not the extension origin.
- Added a one-time import of records from the old host-origin database to preserve data from prior releases.
- Popup now refreshes the table on extension-origin record change broadcasts, so live counts and visible rows stay in sync.
- Shared run metadata is written only after a tab obtains the global Web Lock; non-owner tabs cannot pause, stop, or reset another active run.
- Changed cross-context IndexedDB cache notifications to carry/update one changed record instead of forcing a full dataset reload for every lead.
- A valid profile URL with a missing visible list-card name is retained as `person_name=N/A`, `status=error` rather than silently omitted.
- Removed broad result-list text checks from safety detection to reduce false positives on legitimate job/company text. Known security markers and challenge dialogs remain hard stops.
- Added a deterministic Node regression suite and DOM fixture suite.

- Removed assumptions about `window.location` from URL helper routines so the same safe normalization code can run in the MV3 service worker.


## v3.5.3 targeted fixes
- Standard LinkedIn Connections cards now deduplicate avatar/name links by canonical profile URL and prefer the text-bearing profile anchor.
- Connection names and headlines are extracted from the nested paragraph structure shown in the supplied DOM inspection.
- Standard Search name parsing rejects concatenated card/action text and prefers a plausible person-name candidate.
- Pause updates local state before waiting for persistence; queued records continue flushing asynchronously.
- Stop persistence is bounded so a stalled storage bridge cannot indefinitely delay the control acknowledgement.
- Popup messaging has a bounded timeout and reports command delivery failures; Stop remains available to clear an orphaned local run state.
