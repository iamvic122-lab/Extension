# v3.5.5 — Sales Navigator URL separation

## Fixed
- Added a dedicated `sales_navigator_url` field/column for Sales Navigator People results.
- Kept `url` reserved for a genuine normal LinkedIn `/in/` profile URL.
- Prevented `/sales/lead/ACw...` identifiers from being presented as normal profile slugs.
- If both links are present in the same result card, the normal profile URL is accepted only when its visible name/aria-label matches the primary person.
- Updated CSV, XLSX, and clipboard exports to use the active page-specific columns.
- Updated storage merge handling for the Sales Navigator URL field.

## Verification
- Node regression suite: 23 passed.
- Background bridge tests: 3 passed.
- Storage bridge tests: 2 passed.
- JavaScript syntax and manifest/reference checks: performed before packaging.
- ZIP integrity: checked after packaging.
- Live LinkedIn test: not performed; this build is not claimed as live-verified.
