/* pagination.js — automatic Next/load-more detection and verified navigation. */
(function attachPagination(root) {
  const SEL = root.LXSelectors;
  const Wait = root.LXWait;
  const Logger = root.LXLogger;
  const Extractor = root.LXExtractor;
  const U = root.LX;

  function isVisible(element) {
    if (!element || element.nodeType !== 1) return false;
    try {
      const style = getComputedStyle(element); const rect = element.getBoundingClientRect();
      return style.display !== 'none' && style.visibility !== 'hidden' && style.pointerEvents !== 'none' && rect.width > 0 && rect.height > 0;
    } catch (_) { return false; }
  }
  function isDisabled(element) {
    if (!element) return true;
    return !!(element.disabled || element.getAttribute('aria-disabled') === 'true' || element.hasAttribute('disabled') || element.classList.contains('disabled') || element.classList.contains('artdeco-button--disabled') || !isVisible(element));
  }
  function controlText(element) { return U.cleanText(`${element?.textContent || ''} ${element?.getAttribute?.('aria-label') || ''} ${element?.title || ''}`); }

  function paginationRegionFor(element) {
    if (!element) return null;
    return element.closest('nav, [role="navigation"], .artdeco-pagination, [class*="pagination"], footer') || element.parentElement;
  }
  function isPaginationLike(element) {
    const region = paginationRegionFor(element);
    if (!region) return false;
    const token = `${region.className || ''} ${region.getAttribute?.('aria-label') || ''}`;
    if (/pagination|paging|results|search/i.test(token) || !!region.querySelector?.('.artdeco-pagination__button--next')) return true;
    // LinkedIn standard search and Sales Navigator can use generated classes
    // and icon-only buttons. Accept an exact Next label only in the active main
    // results area when the adapter has positively identified result rows.
    const context = Extractor.getPageContext?.();
    const exactLabel = /^(?:next|next page)$/i.test(U.cleanText(`${element.textContent || ''} ${element.getAttribute?.('aria-label') || ''} ${element.getAttribute?.('title') || ''}`));
    const main = document.querySelector('main');
    const hasRows = !!context?.mode && Extractor.findResultRows(context.mode).length > 0;
    if (exactLabel && main?.contains(element) && hasRows && (context?.pageType === 'search' || context?.pageType === 'sales-people' || context?.pageType === 'sales-company')) return true;
    return false;
  }

  function findNextControl(includeDisabled = false) {
    try {
      const spans = [...document.querySelectorAll(SEL.nextTextSpan || 'span.artdeco-button__text')];
      for (const span of spans) {
        if (U.cleanText(span.textContent) !== 'Next') continue;
        const control = span.closest('button, a');
        if (!control || !isVisible(control) || !isPaginationLike(control)) continue;
        if (!includeDisabled && isDisabled(control)) continue;
        return { element: control, selector: 'span.artdeco-button__text=Next', disabled: isDisabled(control) };
      }
    } catch (error) { Logger.debug('Exact Next detector failed', error?.message || error); }

    const selectors = [...(SEL.nextButton || []), ...(SEL.nextLink || [])];
    for (const selector of selectors) {
      try {
        const matches = [...document.querySelectorAll(selector)];
        const target = matches.find((element) => isVisible(element) && isPaginationLike(element) && (includeDisabled || !isDisabled(element)));
        if (target) return { element: target, selector, disabled: isDisabled(target) };
      } catch (error) { Logger.debug('Next selector failed', selector, error?.message || error); }
    }
    return null;
  }

  function exactOrTextNext(includeDisabled = false) {
    const candidates = [...document.querySelectorAll('button, a, [role="button"]')].filter(isVisible);
    const context = Extractor.getPageContext?.();
    const rowsPresent = !!context?.mode && Extractor.findResultRows(context.mode).length > 0;
    const target = candidates.find((element) => {
      const text = U.cleanText(element.textContent || '');
      const aria = U.cleanText(element.getAttribute('aria-label') || '');
      const title = U.cleanText(element.getAttribute('title') || '');
      const exact = /^(?:next|next page)$/i.test(text) || /^(?:next|next page)$/i.test(aria) || /^(?:next|next page)$/i.test(title);
      if (!exact) return false;
      if (isPaginationLike(element)) return true;
      // Sales Navigator's pagination markup has changed across UI versions.
      // Do not require a class name containing "pagination" when an exact Next
      // control is inside main and supported result cards are present.
      return !!document.querySelector('main')?.contains(element) && rowsPresent
        && ['sales-people','sales-company','search'].includes(context?.pageType);
    });
    if (target && (includeDisabled || !isDisabled(target))) return { element: target, selector: 'text:next', disabled: isDisabled(target) };
    return null;
  }

  function findNextStatus() { return findNextControl(true) || exactOrTextNext(true); }
  function findNext() { return findNextControl(false) || exactOrTextNext(false); }

  function findLoadMoreStatus() {
    const selectors = SEL.loadMoreButton || [];
    for (const selector of selectors) {
      try {
        const matches = [...document.querySelectorAll(selector)];
        const target = matches.find((element) => isVisible(element));
        if (target) return { element: target, selector, disabled: isDisabled(target) };
      } catch (_) {}
    }
    const buttons = [...document.querySelectorAll('button')].filter(isVisible);
    const target = buttons.find((button) => /\bload\s+more\b|show\s+more\s+results|more\s+results/i.test(controlText(button)));
    return target ? { element: target, selector: 'text:load-more', disabled: isDisabled(target) } : null;
  }
  function findLoadMoreButton() { const result = findLoadMoreStatus(); return result && !result.disabled ? result : null; }

  function rowKeys(mode) { return Extractor.findResultRows(mode).map((row) => U.stableRowKey(row, mode)).filter(Boolean).slice(0, 50); }

  function getPageDescriptor() {
    const mode = Extractor.detectMode();
    const rows = mode ? Extractor.findResultRows(mode) : [];
    const keys = rowKeys(mode || root.LXConstants.RECORD_TYPES.PERSON);
    return {
      url: window.location.href,
      pageKey: U.pageKey(window.location.href),
      searchKey: U.searchKey(window.location.href),
      page: U.pageNumber(window.location.href, 1),
      mode,
      signature: Extractor.signature(rows, mode),
      firstKey: keys[0] || '',
      lastKey: keys[keys.length - 1] || '',
      rowKeys: keys,
      rowCount: rows.length,
      loading: Extractor.hasBlockingLoader()
    };
  }

  function pageChanged(previous) {
    if (!previous) return true;
    const current = getPageDescriptor();
    if (current.loading || current.rowCount === 0) return false;
    const urlChanged = current.pageKey !== previous.pageKey || current.url !== previous.url;
    const firstChanged = !!(previous.firstKey && current.firstKey && previous.firstKey !== current.firstKey);
    const prevTop = Array.isArray(previous.rowKeys) ? previous.rowKeys.slice(0, 5) : [];
    const currTop = Array.isArray(current.rowKeys) ? current.rowKeys.slice(0, 5) : [];
    const overlap = prevTop.length && currTop.length ? currTop.filter((key) => prevTop.includes(key)).length : 0;
    const leadingSetChanged = prevTop.length && currTop.length ? overlap < Math.ceil(Math.min(prevTop.length, currTop.length) / 2) : false;
    const signatureChanged = !!(previous.signature && current.signature && previous.signature !== current.signature);
    // A URL change by itself is not enough. The leading identities must also change,
    // preventing the old virtualized rows from being accepted as the new page.
    if (urlChanged) return firstChanged || leadingSetChanged;
    return firstChanged || leadingSetChanged || signatureChanged;
  }

  function detectExpectedResultsPerPage() {
    const context = Extractor.getPageContext?.() || { usesSalesNavigator: true, pageType: 'sales-people' };
    const candidates = [
      document.querySelector('[aria-label*="results" i]'),
      document.querySelector('[class*="pagination" i]'),
      document.querySelector('main')
    ].filter(Boolean);
    for (const node of candidates) {
      const text = U.cleanText(node.innerText || node.textContent || '');
      const range = text.match(/(?:showing|results)\s+(\d+)\s*[-–]\s*(\d+)\s+of\s+[\d,]+/i) || text.match(/(\d+)\s*[-–]\s*(\d+)\s+of\s+[\d,]+/i);
      if (range) { const size = Number(range[2]) - Number(range[1]) + 1; if (size > 0 && size <= 100) return size; }
    }
    // Sales Navigator's known contract is 25; ordinary LinkedIn lists vary and
    // connections/grow may be unbounded lazy lists, so do not invent a count.
    return context.usesSalesNavigator ? 25 : null;
  }

  async function clickNextWithRetry(previous, settings, safety, shouldCancel = () => false) {
    let lastFailure = 'next-not-found';
    const retries = Math.max(1, Number(settings.pageChangeRetries) || 3);
    const before = { ...(previous || getPageDescriptor()), rowKeys: [...(previous?.rowKeys || [])] };
    if (!before.firstKey) Object.assign(before, getPageDescriptor());

    for (let attempt = 1; attempt <= retries; attempt += 1) {
      if (shouldCancel()) return { ok: false, cancelled: true, reason: 'cancelled', attempt };
      if (pageChanged(before)) return { ok: true, attempt, descriptor: getPageDescriptor(), waitedMs: 0, selector: 'already-changed' };
      const target = findNext();
      if (!target) { lastFailure = 'next-not-found'; break; }
      try {
        const budget = safety ? await safety() : null;
        if (budget === false || shouldCancel()) return { ok: false, cancelled: true, reason: 'cancelled', attempt };
        target.element.scrollIntoView({ block: 'center', inline: 'nearest' });
        target.element.click();
        Logger.info('Next page clicked', target.selector);
        const result = await Wait.waitForCondition(() => pageChanged(before), {
          root: document.documentElement || document,
          timeoutMs: Number(settings.timeoutMs) || 30000,
          observeAttributes: false,
          shouldCancel
        });
        return { ok: true, descriptor: getPageDescriptor(), waitedMs: result.waitedMs, selector: target.selector, budget, attempt };
      } catch (error) {
        if (error?.code === 'WAIT_CANCELLED' || shouldCancel()) return { ok: false, cancelled: true, reason: 'cancelled', attempt };
        lastFailure = error?.message || 'page-change-timeout';
        Logger.warning('Next page attempt failed', attempt, lastFailure);
        if (attempt < retries) await Wait.wait(800, shouldCancel);
      }
    }
    return { ok: false, reason: lastFailure, attempt: retries };
  }

  async function clickLoadMoreWithRetry(previous, settings, safety, shouldCancel = () => false) {
    let lastFailure = 'load-more-not-found';
    const retries = Math.max(1, Number(settings.pageChangeRetries) || 3);
    const before = previous || getPageDescriptor();
    for (let attempt = 1; attempt <= retries; attempt += 1) {
      if (shouldCancel()) return { ok: false, cancelled: true, reason: 'cancelled', attempt };
      const target = findLoadMoreButton();
      if (!target) return { ok: true, finished: true, reason: 'load-more-unavailable', attempt };
      const beforeCount = Number(before.rowCount || Extractor.findResultRows().length);
      const beforeSignature = before.signature || Extractor.signature();
      try {
        const budget = safety ? await safety() : null;
        if (budget === false || shouldCancel()) return { ok: false, cancelled: true, reason: 'cancelled', attempt };
        target.element.scrollIntoView({ block: 'center', inline: 'nearest' });
        target.element.click();
        const result = await Wait.waitForCondition(() => {
          const current = getPageDescriptor();
          return !current.loading && (current.rowCount > beforeCount || (beforeSignature && current.signature && current.signature !== beforeSignature));
        }, { root: document.documentElement || document, timeoutMs: Number(settings.timeoutMs) || 30000, shouldCancel });
        return { ok: true, finished: false, descriptor: getPageDescriptor(), waitedMs: result.waitedMs, selector: target.selector, budget, attempt };
      } catch (error) {
        if (error?.code === 'WAIT_CANCELLED' || shouldCancel()) return { ok: false, cancelled: true, reason: 'cancelled', attempt };
        lastFailure = error?.message || 'load-more-timeout';
        Logger.warning('Load-more attempt failed', attempt, lastFailure);
      }
    }
    return { ok: false, reason: lastFailure, attempt: retries };
  }

  function detectAction() {
    const next = findNext();
    if (next) return { type: 'next-page', selector: next.selector, text: controlText(next.element), target: next.element, disabled: false };
    const more = findLoadMoreButton();
    if (more) return { type: 'load-more', selector: more.selector, text: controlText(more.element), target: more.element, disabled: false };
    return { type: 'none', selector: null, text: '', target: null, disabled: false };
  }

  function verifyTarget() {
    const nextStatus = findNextStatus();
    const moreStatus = findLoadMoreStatus();
    const action = detectAction();
    return {
      ok: action.type !== 'none' || !!nextStatus || !!moreStatus,
      action: action.type,
      selector: action.selector || nextStatus?.selector || moreStatus?.selector || null,
      text: action.text || controlText(nextStatus?.element || moreStatus?.element),
      disabled: action.type === 'none' ? !!(nextStatus?.disabled || moreStatus?.disabled) : false,
      next: nextStatus ? { present: true, disabled: nextStatus.disabled } : { present: false, disabled: false },
      loadMore: moreStatus ? { present: true, disabled: moreStatus.disabled } : { present: false, disabled: false }
    };
  }

  function isLastPage() {
    const next = findNextStatus();
    if (next) return next.disabled;
    const more = findLoadMoreStatus();
    return !!more && more.disabled;
  }

  root.LXPagination = {
    findNext: () => findNext()?.element || null,
    hasNext: () => !!findNext(),
    findNextStatus,
    hasLoadMore: () => !!findLoadMoreButton(),
    findLoadMoreButton: () => findLoadMoreButton()?.element || null,
    findLoadMoreStatus,
    getPageDescriptor,
    detectExpectedResultsPerPage,
    detectAction,
    isLastPage,
    clickNextWithRetry,
    clickLoadMoreWithRetry,
    verifyTarget
  };
})(typeof window !== 'undefined' ? window : globalThis);
