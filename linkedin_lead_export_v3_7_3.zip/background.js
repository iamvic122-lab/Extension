/* background.js — MV3 lifecycle + extension-origin persistent record store. */
importScripts('constants.js', 'logger.js', 'utils.js', 'storage.js');

const LX_DB_RPC_TYPES = new Set([
  'LX_DB_GET_LEADS',
  'LX_DB_GET_LEAD_COUNT',
  'LX_DB_GET_COUNT_BY_TYPE',
  'LX_DB_UPSERT_LEAD',
  'LX_DB_MERGE_LEADS',
  'LX_DB_CLEAR_LEADS',
  'LX_DB_IMPORT_BATCH'
]);

function isLinkedInContentSender(sender) {
  const rawUrl = sender?.tab?.url || sender?.url || '';
  try {
    const url = new URL(rawUrl);
    return /(?:^|\.)linkedin\.com$/i.test(url.hostname) && /^https?:$/i.test(url.protocol);
  } catch (_) { return false; }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !LX_DB_RPC_TYPES.has(message.type)) return false;
  if (sender?.id !== chrome.runtime.id || !isLinkedInContentSender(sender)) {
    sendResponse({ ok:false, error:'Record storage bridge accepts requests only from this extension on LinkedIn pages.' });
    return false;
  }

  (async () => {
    const S = globalThis.LXStorage;
    switch (message.type) {
      case 'LX_DB_GET_LEADS':
        return S.getLeads();
      case 'LX_DB_GET_LEAD_COUNT':
        return S.getLeadCount();
      case 'LX_DB_GET_COUNT_BY_TYPE':
        return S.getCountByType();
      case 'LX_DB_UPSERT_LEAD':
        return S.upsertLead(message.record);
      case 'LX_DB_MERGE_LEADS':
        return S.mergeLeads(Array.isArray(message.records) ? message.records : []);
      case 'LX_DB_CLEAR_LEADS':
        await S.clearLeads();
        return true;
      case 'LX_DB_IMPORT_BATCH': {
        const records = Array.isArray(message.records) ? message.records : [];
        if (records.length > 100) throw new Error('Legacy import batch exceeds 100 records.');
        let imported = 0;
        for (const record of records) {
          const result = await S.upsertLead(record);
          if (result?.lead) imported += 1;
        }
        return { imported };
      }
      default:
        throw new Error('Unsupported record-storage operation.');
    }
  })().then((result) => sendResponse({ ok:true, result }))
    .catch((error) => sendResponse({ ok:false, error:error?.message || 'Record storage operation failed.' }));
  return true;
});

chrome.runtime.onInstalled.addListener(async () => {
  try {
    const C = globalThis.LXConstants;
    const current = await chrome.storage.local.get(C.STORAGE_KEYS.SETTINGS);
    if (!current[C.STORAGE_KEYS.SETTINGS]) {
      await chrome.storage.local.set({ [C.STORAGE_KEYS.SETTINGS]: { ...C.DEFAULTS } });
    }
  } catch (error) {
    console.error('[LX] Install initialization failed', error);
  }
});
