/* safety.js — detects visible security/challenge signals and enforces conservative pacing. */
(function attachSafety(root) {
  const C = root.LXConstants;
  const SEL = root.LXSelectors;
  const U = root.LX;
  const Logger = root.LXLogger;

  const TEXT_PATTERNS = [
    /verify (your|the) identity/i,
    /verify it'?s you/i,
    /security verification/i,
    /security check/i,
    /unusual (activity|sign-in|login)/i,
    /security checkpoint/i,
    /account checkpoint/i,
    /verification checkpoint/i,
    /security challenge/i,
    /captcha/i,
    /temporarily restricted/i,
    /account restricted/i
  ];

  function visible(element) {
    if (!element) return false;
    const style = getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
  }

  function detect() {
    const path = `${window.location.pathname}${window.location.search}`.toLowerCase();
    const knownCheckpointPath = /checkpoint|challenge|verify|login|auth/i.test(path);

    for (const selector of SEL.securityMarkers || []) {
      try {
        const match = [...document.querySelectorAll(selector)].find(visible);
        if (match) return { risky: true, severity: 'hard-stop', reason: `Security marker: ${selector}`, selector };
      } catch (_) {}
    }

    const dialogs = [...document.querySelectorAll('[role="dialog"], [role="alertdialog"], dialog, .artdeco-modal, [data-test-modal]')].filter(visible);
    for (const dialog of dialogs) {
      const text = U.cleanText(dialog.innerText || dialog.textContent || '');
      if (/captcha|verify (your|the) identity|verify it'?s you|unusual (activity|sign-in|login)|security checkpoint|account checkpoint|temporarily restricted|account restricted/i.test(text)) {
        return { risky: true, severity: 'hard-stop', reason: 'Security/challenge dialog detected' };
      }
    }

    if (knownCheckpointPath && /captcha|verify|checkpoint|unusual activity|temporarily restricted|account restricted/i.test(U.cleanText(document.body?.innerText || '').slice(0, 120000))) {
      return { risky: true, severity: 'hard-stop', reason: 'LinkedIn checkpoint/security URL detected' };
    }

    // Do not scan result-card/list text for generic security phrases. Job titles
    // and company names can legitimately contain words like "Security Check".
    // Challenge dialogs, explicit markers, and checkpoint URLs above are the
    // supported hard-stop signals.

    return { risky: false, severity: 'clear' };
  }

  function validateSettings(settings) {
    const min = U.clamp(settings.actionDelayMinMs, C.LIMITS.actionDelayMinMs.min, C.LIMITS.actionDelayMinMs.max);
    const max = U.clamp(settings.actionDelayMaxMs, C.LIMITS.actionDelayMaxMs.min, C.LIMITS.actionDelayMaxMs.max);
    const randomMin = U.clamp(settings.randomDelayMinMs, C.LIMITS.randomDelayMinMs.min, C.LIMITS.randomDelayMinMs.max);
    const randomMax = U.clamp(settings.randomDelayMaxMs, C.LIMITS.randomDelayMaxMs.min, C.LIMITS.randomDelayMaxMs.max);
    const scrollMin = U.clamp(settings.scrollMinPx, C.LIMITS.scrollMinPx.min, C.LIMITS.scrollMinPx.max);
    const scrollMax = U.clamp(settings.scrollMaxPx, C.LIMITS.scrollMaxPx.min, C.LIMITS.scrollMaxPx.max);
    const pauseMin = U.clamp(settings.scrollPauseMinMs, C.LIMITS.scrollPauseMinMs.min, C.LIMITS.scrollPauseMinMs.max);
    const pauseMax = U.clamp(settings.scrollPauseMaxMs, C.LIMITS.scrollPauseMaxMs.min, C.LIMITS.scrollPauseMaxMs.max);
    return {
      ...settings,
      // Previously unclamped: a blank/NaN value disabled the action rate limit
      // (NaN comparisons are always false) and a 0 scroll distance stalled scrolling.
      maxActionsPerMinute: Math.round(U.clamp(settings.maxActionsPerMinute, C.LIMITS.maxActionsPerMinute.min, C.LIMITS.maxActionsPerMinute.max)),
      scrollMinPx: Math.min(scrollMin, scrollMax),
      scrollMaxPx: Math.max(scrollMin, scrollMax),
      scrollPauseMinMs: Math.min(pauseMin, pauseMax),
      scrollPauseMaxMs: Math.max(pauseMin, pauseMax),
      actionDelayMinMs: Math.min(min, max),
      actionDelayMaxMs: Math.max(min, max),
      randomDelayMinMs: Math.min(randomMin, randomMax),
      randomDelayMaxMs: Math.max(randomMin, randomMax),
      retryCount: U.clamp(settings.retryCount, C.LIMITS.retryCount.min, C.LIMITS.retryCount.max),
      timeoutMs: U.clamp(settings.timeoutMs, C.LIMITS.timeoutMs.min, C.LIMITS.timeoutMs.max),
      maxPages: U.clamp(settings.maxPages, C.LIMITS.maxPages.min, C.LIMITS.maxPages.max),
      maxScrollPasses: U.clamp(settings.maxScrollPasses, C.LIMITS.maxScrollPasses.min, C.LIMITS.maxScrollPasses.max),
      expectedResultsPerPage: U.clamp(settings.expectedResultsPerPage, C.LIMITS.expectedResultsPerPage.min, C.LIMITS.expectedResultsPerPage.max),
      pageAuditPasses: U.clamp(settings.pageAuditPasses, C.LIMITS.pageAuditPasses.min, C.LIMITS.pageAuditPasses.max),
      pageChangeRetries: U.clamp(settings.pageChangeRetries, C.LIMITS.pageChangeRetries.min, C.LIMITS.pageChangeRetries.max),
      resumeStalenessMs: U.clamp(settings.resumeStalenessMs, C.LIMITS.resumeStalenessMs.min, C.LIMITS.resumeStalenessMs.max),
      leaseHeartbeatMs: U.clamp(settings.leaseHeartbeatMs, C.LIMITS.leaseHeartbeatMs.min, C.LIMITS.leaseHeartbeatMs.max),
      autoSaveMs: U.clamp(settings.autoSaveMs, C.LIMITS.autoSaveMs.min, C.LIMITS.autoSaveMs.max)
    };
  }

  async function waitForActionBudget(meta, settings, Wait, shouldCancel = () => false) {
    const now = Date.now();
    const windowStart = Number(meta.actionWindowStartedAt || now);
    const count = Number(meta.actionsInWindow || 0);
    const oneMinute = 60000;
    const normalized = validateSettings(settings);
    let started = windowStart;
    let used = count;
    if (now - started >= oneMinute) {
      started = now;
      used = 0;
    }
    if (used >= normalized.maxActionsPerMinute) {
      const remaining = oneMinute - (now - started);
      Logger.warning('Safety pacing limit reached; waiting for action window', remaining);
      if (!(await Wait.wait(Math.max(1000, remaining), shouldCancel))) return false;
      started = Date.now();
      used = 0;
    }
    const delay = U.randomBetween(normalized.actionDelayMinMs, normalized.actionDelayMaxMs);
    if (delay > 0 && !(await Wait.wait(delay, shouldCancel))) return false;
    return { actionWindowStartedAt: started, actionsInWindow: used + 1, lastActionAt: new Date().toISOString() };
  }

  root.LXSafety = { detect, validateSettings, waitForActionBudget };
})(typeof window !== 'undefined' ? window : globalThis);
