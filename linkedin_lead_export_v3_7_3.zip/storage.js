/* storage.js — IndexedDB record store + serialized metadata/settings. */
(function attachStorage(root) {
  const C = root.LXConstants;
  const U = root.LX;
  const Logger = root.LXLogger || console;
  const KEYS = C.STORAGE_KEYS;
  const DB_NAME = 'lx_sales_navigator_store';
  const DB_VERSION = 1;
  const LEAD_STORE = 'leads';
  const CONTENT_IMPORT_KEY = 'lx_host_indexeddb_imported_to_extension_v1';
  const IS_LINKEDIN_CONTENT_CONTEXT = !!(root.document && /(?:^|\.)linkedin\.com$/i.test(root.location?.hostname || ''));
  const cache = { migrated: false, loaded: false, leads: [], byKey: new Map(), counts: { person: 0, company: 0 }, dbPromise: null, metaWriteChain: Promise.resolve() };
  let channel = null;
  let contentImportPromise = null;

  function storageTimeoutMs() { return U.clamp(C.DEFAULTS.storageTimeoutMs, C.LIMITS.storageTimeoutMs.min, C.LIMITS.storageTimeoutMs.max); }

  function contextError(error) {
    const message = String(error?.message || error || 'Storage operation failed');
    return U.isExtensionContextInvalidated?.(error) ? new Error('Extension context invalidated') : new Error(message);
  }

  function withTimeout(promise, ms, message) {
    let timer;
    return Promise.race([promise.finally(() => clearTimeout(timer)), new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(message)), ms); })]);
  }

  function chromeGet(keys) {
    return withTimeout(new Promise((resolve, reject) => {
      try {
        chrome.storage.local.get(keys, (result) => {
          const error = chrome.runtime?.lastError;
          if (error) reject(contextError(error)); else resolve(result || {});
        });
      } catch (error) { reject(contextError(error)); }
    }), storageTimeoutMs(), `Storage get timed out after ${storageTimeoutMs()}ms`);
  }

  function chromeSet(value) {
    return withTimeout(new Promise((resolve, reject) => {
      try {
        chrome.storage.local.set(value, () => {
          const error = chrome.runtime?.lastError;
          if (error) reject(contextError(error)); else resolve();
        });
      } catch (error) { reject(contextError(error)); }
    }), storageTimeoutMs(), `Storage set timed out after ${storageTimeoutMs()}ms`);
  }

  function chromeRemove(keys) {
    return withTimeout(new Promise((resolve, reject) => {
      try {
        chrome.storage.local.remove(keys, () => {
          const error = chrome.runtime?.lastError;
          if (error) reject(contextError(error)); else resolve();
        });
      } catch (error) { reject(contextError(error)); }
    }), storageTimeoutMs(), `Storage remove timed out after ${storageTimeoutMs()}ms`);
  }

  function contentStorageRpc(type, payload = {}) {
    return withTimeout(new Promise((resolve, reject) => {
      try {
        chrome.runtime.sendMessage({ type, ...payload }, (response) => {
          const error = chrome.runtime?.lastError;
          if (error) { reject(contextError(error)); return; }
          if (!response?.ok) { reject(new Error(response?.error || `Storage bridge failed: ${type}`)); return; }
          resolve(response.result);
        });
      } catch (error) { reject(contextError(error)); }
    }), storageTimeoutMs(), `Storage bridge timed out after ${storageTimeoutMs()}ms (${type})`);
  }

  async function ensureHostDatabaseImported() {
    if (!IS_LINKEDIN_CONTENT_CONTEXT) return;
    if (contentImportPromise) return contentImportPromise;
    contentImportPromise = (async () => {
      const marker = await chromeGet(CONTENT_IMPORT_KEY);
      if (marker[CONTENT_IMPORT_KEY]) return;

      // Older builds opened IndexedDB from the content script, which means those
      // records live under linkedin.com rather than chrome-extension://<id>.
      // Read that legacy database once and move records through the background
      // bridge into the extension-origin database used by both popup and worker.
      const legacyEnvelope = await chromeGet('lx_leads');
      const legacyRecords = Array.isArray(legacyEnvelope.lx_leads) ? legacyEnvelope.lx_leads : [];
      let hostRecords = [];
      const db = await openDb();
      try { await migrateLegacyIfNeeded(db); }
      catch (error) { Logger.warning('Legacy host database migration check failed; attempting a read-only import', error?.message || error); }
      const tx = db.transaction(LEAD_STORE, 'readonly');
      const storedRows = await idbRequest(tx.objectStore(LEAD_STORE).getAll());
      hostRecords = (Array.isArray(storedRows) ? storedRows : []).map((item) => item?.record || item).filter(Boolean);

      const unique = new Map();
      for (const raw of [...legacyRecords, ...hostRecords]) {
        try {
          const normalized = U.normalizeLead(raw);
          const key = U.leadKey(normalized);
          if (key) unique.set(key, normalized);
        } catch (error) { Logger.warning('Skipping malformed record during host database import', error?.message || error); }
      }
      const records = [...unique.values()];
      const batchSize = 100;
      for (let offset = 0; offset < records.length; offset += batchSize) {
        await contentStorageRpc('LX_DB_IMPORT_BATCH', { records: records.slice(offset, offset + batchSize) });
      }
      await chromeSet({ [CONTENT_IMPORT_KEY]: true });
      Logger.info('Legacy host-origin database import completed', { imported: records.length });
    })();
    try { await contentImportPromise; }
    finally { contentImportPromise = null; }
  }

  function syncContentCache(records) {
    cache.leads = (Array.isArray(records) ? records : []).map((record) => U.normalizeLead(record));
    cache.counts = cache.leads.reduce((counts, lead) => { counts[lead.recordType === C.RECORD_TYPES.COMPANY ? 'company' : 'person'] += 1; return counts; }, { person: 0, company: 0 });
    rebuildIndex();
    cache.loaded = true;
    return cache.leads;
  }

  function enqueue(task) {
    const next = cache.metaWriteChain.then(task, task);
    cache.metaWriteChain = next.catch(() => {});
    return next;
  }

  function openDb() {
    if (cache.dbPromise) return cache.dbPromise;
    cache.dbPromise = withTimeout(new Promise((resolve, reject) => {
      if (!('indexedDB' in globalThis)) { reject(new Error('IndexedDB is unavailable.')); return; }
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(LEAD_STORE)) db.createObjectStore(LEAD_STORE, { keyPath: 'key' });
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error('IndexedDB open failed'));
      request.onblocked = () => Logger.warning('IndexedDB open blocked by another context');
    }), storageTimeoutMs(), `IndexedDB open timed out after ${storageTimeoutMs()}ms`);
    return cache.dbPromise;
  }

  function idbRequest(request) {
    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error('IndexedDB request failed'));
    });
  }

  async function migrateLegacyIfNeeded(db) {
    // upsertLead() calls this once per record; after the first successful check
    // the answer cannot change, so skip the chrome.storage round-trip.
    if (cache.migrated) return;
    const marker = await chromeGet(KEYS.MIGRATION);
    if (marker[KEYS.MIGRATION]) { cache.migrated = true; return; }
    const tx = db.transaction(LEAD_STORE, 'readonly');
    const count = await idbRequest(tx.objectStore(LEAD_STORE).count());
    if (count === 0) {
      const legacy = await chromeGet('lx_leads');
      const raw = Array.isArray(legacy.lx_leads) ? legacy.lx_leads : [];
      if (raw.length) {
        const writeTx = db.transaction(LEAD_STORE, 'readwrite');
        const store = writeTx.objectStore(LEAD_STORE);
        for (const item of raw) {
          try {
            const normalized = U.normalizeLead(item);
            const key = U.leadKey(normalized);
            if (key) store.put({ key, record: normalized });
          } catch (error) { Logger.warning('Skipping malformed legacy record', error?.message || error); }
        }
        await new Promise((resolve, reject) => {
          writeTx.oncomplete = resolve;
          writeTx.onerror = () => reject(writeTx.error || new Error('Legacy migration failed'));
          writeTx.onabort = () => reject(writeTx.error || new Error('Legacy migration aborted'));
        });
      }
    }
    await chromeSet({ [KEYS.MIGRATION]: true });
    cache.migrated = true;
    try { await chromeRemove('lx_leads'); } catch (error) { Logger.warning('Legacy cleanup failed', error?.message || error); }
  }

  function rebuildIndex() {
    cache.byKey.clear();
    cache.leads.forEach((lead, index) => { const key = U.leadKey(lead); if (key) cache.byKey.set(key, index); });
  }

  function applyRemoteLead(rawRecord) {
    // A cross-tab notification carries the changed record. Update the local
    // cache incrementally instead of re-reading every row from IndexedDB for
    // each lead inserted in another tab.
    if (!cache.loaded || !rawRecord) return;
    try {
      const record = U.normalizeLead(rawRecord);
      const key = U.leadKey(record);
      if (!key) return;
      const index = cache.byKey.get(key);
      if (index == null) {
        cache.byKey.set(key, cache.leads.length);
        cache.leads.push(record);
        cache.counts[record.recordType === C.RECORD_TYPES.COMPANY ? 'company' : 'person'] += 1;
      } else {
        const previous = cache.leads[index];
        const oldType = previous?.recordType === C.RECORD_TYPES.COMPANY ? 'company' : 'person';
        const newType = record.recordType === C.RECORD_TYPES.COMPANY ? 'company' : 'person';
        if (oldType !== newType) { cache.counts[oldType] = Math.max(0, cache.counts[oldType] - 1); cache.counts[newType] += 1; }
        cache.leads[index] = record;
      }
    } catch (error) { Logger.debug('Cross-context record update ignored', error?.message || error); }
  }

  async function loadLeads(force = false) {
    if (IS_LINKEDIN_CONTENT_CONTEXT) {
      await ensureHostDatabaseImported();
      const records = await contentStorageRpc('LX_DB_GET_LEADS');
      return syncContentCache(records);
    }
    if (cache.loaded && !force) return cache.leads;
    const db = await openDb();
    await migrateLegacyIfNeeded(db);
    const tx = db.transaction(LEAD_STORE, 'readonly');
    const rows = await idbRequest(tx.objectStore(LEAD_STORE).getAll());
    cache.leads = [];
    for (const row of Array.isArray(rows) ? rows : []) {
      try { const normalized = U.normalizeLead(row?.record || row); if (U.leadKey(normalized)) cache.leads.push(normalized); }
      catch (error) { Logger.warning('Skipping malformed stored record', error?.message || error); }
    }
    cache.leads.sort((a, b) => String(a.capturedAt || '').localeCompare(String(b.capturedAt || '')));
    cache.counts = cache.leads.reduce((counts, lead) => { counts[lead.recordType === C.RECORD_TYPES.COMPANY ? 'company' : 'person'] += 1; return counts; }, { person: 0, company: 0 });
    rebuildIndex();
    cache.loaded = true;
    return cache.leads;
  }

  async function getSettings() {
    const result = await chromeGet(KEYS.SETTINGS);
    return { ...C.DEFAULTS, ...(result[KEYS.SETTINGS] || {}) };
  }

  async function saveSettings(patch) {
    return enqueue(async () => {
      const current = await getSettings();
      const next = { ...current, ...(patch || {}) };
      await chromeSet({ [KEYS.SETTINGS]: next });
      return next;
    });
  }

  function mergeField(oldValue, newValue) {
    const oldText = String(oldValue ?? '').trim();
    const newText = String(newValue ?? '').trim();
    if (!newText || /^N\/A$/i.test(newText)) return oldValue || '';
    if (!oldText || /^N\/A$/i.test(oldText)) return newValue;
    return oldText === newText ? oldValue : newValue;
  }

  function scopeOf(record) {
    return record?.sourceSearchKey ? { pageType: record.sourcePageType || '', searchKey: record.sourceSearchKey } : null;
  }
  function mergeScopes(existing, incoming) {
    const list = Array.isArray(existing?.sourceScopes) ? existing.sourceScopes.filter((x) => x && x.searchKey).map((x) => ({ pageType: x.pageType || '', searchKey: x.searchKey })) : [];
    for (const record of [existing, incoming]) {
      const scope = scopeOf(record);
      if (scope && !list.some((x) => x.searchKey === scope.searchKey && x.pageType === scope.pageType)) list.push(scope);
    }
    return list.slice(-50);
  }
  // Fields that change on every observation and must not make an otherwise
  // identical record look "updated" (which also hid duplicates from the counter).
  const VOLATILE_FIELDS = ['lastSeenAt', 'capturedAt', 'capturedFromUrl', 'sourceRow', 'sourceSearchUrl', 'sourceScopes'];
  function comparable(record) {
    const copy = { ...(record || {}) };
    VOLATILE_FIELDS.forEach((key) => { delete copy[key]; });
    // A missing key and an empty value mean the same thing for change detection.
    Object.keys(copy).forEach((key) => { if (copy[key] === '' || copy[key] == null) delete copy[key]; });
    return JSON.stringify(Object.fromEntries(Object.keys(copy).sort().map((key) => [key, copy[key]])));
  }

  function mergeLead(existing, incoming) {
    const merged = { ...existing };
    const fields = ['connected_date','connectedDate','personName','jobTitle','companyName','location','connectionDegree','recordType','about','yearsInRole','yearsInCompany','personLinkedInUrl','salesNavigatorUrl','companyLinkedInUrl','employeeCount','industry','revenue','companyProfileImageUrl','leadId','companyId','currentJobPeriod','profileHeadline','currentJobLocation','extractionStatus'];
    fields.filter((key) => key !== 'extractionStatus').forEach((key) => { merged[key] = mergeField(existing?.[key], incoming?.[key]); });
    // Do not let a later list-card pass downgrade a previously enriched profile.
    const statusRank = { error:0, partial:1, ok:2 };
    const oldStatus = String(existing?.extractionStatus || '').toLowerCase();
    const newStatus = String(incoming?.extractionStatus || '').toLowerCase();
    merged.extractionStatus = (statusRank[newStatus] ?? -1) > (statusRank[oldStatus] ?? -1) ? newStatus : (oldStatus || newStatus || 'partial');
    // The same person can be collected from several searches. Keep every view
    // they were seen in so the popup's per-view table/export does not lose them
    // when a later search re-collects an existing record.
    merged.sourcePageType = incoming?.sourcePageType || existing?.sourcePageType || '';
    merged.sourceSearchKey = incoming?.sourceSearchKey || existing?.sourceSearchKey || '';
    merged.sourceSearchUrl = incoming?.sourceSearchUrl || existing?.sourceSearchUrl || '';
    merged.sourceScopes = mergeScopes(existing, incoming);
    merged.premium = !!(existing?.premium || incoming?.premium);
    merged.currentExperienceVerified = !!(existing?.currentExperienceVerified || incoming?.currentExperienceVerified);
    merged.sourceRow = Number(incoming?.sourceRow || existing?.sourceRow || 0);
    merged.capturedFromUrl = incoming?.capturedFromUrl || existing?.capturedFromUrl || '';
    merged.capturedAt = existing?.capturedAt || incoming?.capturedAt || new Date().toISOString();
    merged.lastSeenAt = incoming?.lastSeenAt || incoming?.capturedAt || existing?.lastSeenAt || merged.capturedAt;
    return U.normalizeLead(merged);
  }

  async function getLeads() {
    if (IS_LINKEDIN_CONTENT_CONTEXT) { await ensureHostDatabaseImported(); return U.clone(await contentStorageRpc('LX_DB_GET_LEADS')); }
    return U.clone(await loadLeads());
  }
  async function getLeadCount() {
    if (IS_LINKEDIN_CONTENT_CONTEXT) { await ensureHostDatabaseImported(); return contentStorageRpc('LX_DB_GET_LEAD_COUNT'); }
    await loadLeads(); return cache.leads.length;
  }
  async function getCountByType() {
    if (IS_LINKEDIN_CONTENT_CONTEXT) { await ensureHostDatabaseImported(); return contentStorageRpc('LX_DB_GET_COUNT_BY_TYPE'); }
    await loadLeads(); return { ...cache.counts };
  }

  async function upsertLead(rawLead) {
    if (IS_LINKEDIN_CONTENT_CONTEXT) {
      await ensureHostDatabaseImported();
      const result = await contentStorageRpc('LX_DB_UPSERT_LEAD', { record:rawLead });
      if (result?.lead) applyRemoteLead(result.lead);
      return result;
    }
    const incoming = U.normalizeLead(rawLead);
    const key = U.leadKey(incoming);
    if (!key) return { added:false, updated:false, lead:null };
    const db = await openDb();
    await migrateLegacyIfNeeded(db);
    await loadLeads();
    const tx = db.transaction(LEAD_STORE, 'readwrite');
    const store = tx.objectStore(LEAD_STORE);
    let currentRow = null;
    try { currentRow = await idbRequest(store.get(key)); } catch (error) { throw contextError(error); }
    const existing = currentRow?.record ? U.normalizeLead(currentRow.record) : null;
    const next = existing ? mergeLead(existing, incoming) : { ...incoming, sourceScopes: mergeScopes(null, incoming) };
    const changed = !existing || comparable(existing) !== comparable(next);
    store.put({ key, record:next });
    await new Promise((resolve,reject)=>{tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error||new Error('Lead write failed'));tx.onabort=()=>reject(tx.error||new Error('Lead write aborted'));});

    const cacheIndex = cache.byKey.get(key);
    const isAdded = !existing;
    if (cacheIndex == null) {
      cache.leads.push(next);
      cache.byKey.set(key, cache.leads.length-1);
      cache.counts[next.recordType===C.RECORD_TYPES.COMPANY?'company':'person'] += 1;
    } else {
      cache.leads[cacheIndex]=next;
    }
    if (channel) { try { channel.postMessage({type:'lead-upsert',key,record:next}); } catch (_) {} }
    return { added:isAdded, updated:!!existing && changed, lead:next };
  }

  async function mergeLeads(rawLeads) {
    if (IS_LINKEDIN_CONTENT_CONTEXT) {
      await ensureHostDatabaseImported();
      return contentStorageRpc('LX_DB_MERGE_LEADS', { records:Array.isArray(rawLeads) ? rawLeads : [] });
    }
    const result = { all: null, added: [], updated: [], duplicates: 0 };
    for (const raw of Array.isArray(rawLeads) ? rawLeads : []) {
      const upserted = await upsertLead(raw);
      if (!upserted.lead) continue;
      if (upserted.added) result.added.push(upserted.lead);
      else if (upserted.updated) result.updated.push(upserted.lead);
      else result.duplicates += 1;
    }
    result.all = await getLeads();
    return result;
  }

  async function clearLeads() {
    if (IS_LINKEDIN_CONTENT_CONTEXT) {
      await ensureHostDatabaseImported();
      await contentStorageRpc('LX_DB_CLEAR_LEADS');
      cache.loaded = true; cache.leads = []; cache.byKey.clear(); cache.counts = { person: 0, company: 0 };
      return;
    }
    const db = await openDb();
    const tx = db.transaction(LEAD_STORE, 'readwrite');
    tx.objectStore(LEAD_STORE).clear();
    await new Promise((resolve, reject) => { tx.oncomplete = resolve; tx.onerror = () => reject(tx.error || new Error('Lead clear failed')); tx.onabort = () => reject(tx.error || new Error('Lead clear aborted')); });
    cache.loaded = true; cache.leads = []; cache.byKey.clear(); cache.counts = { person: 0, company: 0 };
    try { channel?.postMessage({ type: 'lead-clear' }); } catch (_) {}
  }

  async function getMeta() { const result = await chromeGet(KEYS.META); return result[KEYS.META] || {}; }
  async function setMeta(patch) { return enqueue(async () => { const current = await getMeta(); const next = { ...current, ...(patch || {}) }; await chromeSet({ [KEYS.META]: next }); return next; }); }
  async function clearMeta() { return enqueue(async () => { try { await chromeRemove(KEYS.META); } catch (error) { Logger.warning('Failed to clear metadata', error?.message || error); } }); }

  try {
    if ('BroadcastChannel' in globalThis) {
      channel = new BroadcastChannel('lx-sales-navigator-records');
      channel.onmessage = async (event) => {
        try {
          if (event.data?.type === 'lead-clear') { cache.loaded = true; cache.leads = []; cache.byKey.clear(); cache.counts = { person: 0, company: 0 }; }
          else if (event.data?.type === 'lead-upsert') applyRemoteLead(event.data.record);
        } catch (error) { Logger.debug('Cross-context storage sync failed', error?.message || error); }
      };
    }
  } catch (_) {}

  root.LXStorage = { KEYS, DEFAULT_SETTINGS: C.DEFAULTS, getSettings, saveSettings, getLeads, getLeadCount, getCountByType, loadLeads, mergeLeads, upsertLead, clearLeads, getMeta, setMeta, clearMeta, ensureReady: () => IS_LINKEDIN_CONTENT_CONTEXT ? ensureHostDatabaseImported() : loadLeads(), isContentStorageBridge: IS_LINKEDIN_CONTENT_CONTEXT };
})(typeof window !== 'undefined' ? window : globalThis);
