/* wait.js — cancellable mutation/condition synchronization with bounded fallback polling. */
(function attachWait(root) {
  const Logger = root.LXLogger || console;

  class WaitCancelledError extends Error {
    constructor(message = 'Wait cancelled') { super(message); this.name = 'WaitCancelledError'; this.code = 'WAIT_CANCELLED'; }
  }

  function wait(ms, shouldCancel = () => false) {
    const total = Math.max(0, Number(ms) || 0);
    if (!total) return Promise.resolve(!shouldCancel());
    return new Promise((resolve) => {
      const started = Date.now();
      let timer = null;
      const tick = () => {
        if (shouldCancel()) { if (timer) clearTimeout(timer); resolve(false); return; }
        const remaining = total - (Date.now() - started);
        if (remaining <= 0) { resolve(true); return; }
        timer = setTimeout(tick, Math.min(250, remaining));
      };
      tick();
    });
  }

  function waitForCondition(predicate, options = {}) {
    const timeoutMs = Number(options.timeoutMs) > 0 ? Number(options.timeoutMs) : 30000;
    const rootNode = options.root || document;
    const observeAttributes = options.observeAttributes === true;
    const pollMs = Math.max(30, Math.min(1000, Number(options.pollMs) || 300));
    const shouldCancel = typeof options.shouldCancel === 'function' ? options.shouldCancel : () => false;
    const startedAt = Date.now();

    return new Promise((resolve, reject) => {
      let settled = false;
      let observer = null;
      let fallbackTimer = null;
      let pollTimer = null;
      let evaluateQueued = false;

      const cleanup = () => {
        observer?.disconnect();
        if (fallbackTimer) clearTimeout(fallbackTimer);
        if (pollTimer) clearTimeout(pollTimer);
      };
      const finish = (error, value) => {
        if (settled) return;
        settled = true;
        cleanup();
        error ? reject(error) : resolve(value);
      };
      const schedulePoll = () => {
        if (settled || pollTimer) return;
        const elapsed = Date.now() - startedAt;
        const remaining = Math.max(50, timeoutMs - elapsed);
        pollTimer = setTimeout(() => { pollTimer = null; evaluate(); }, Math.min(pollMs, remaining));
      };
      const evaluate = () => {
        if (settled || evaluateQueued) return;
        evaluateQueued = true;
        queueMicrotask(() => {
          evaluateQueued = false;
          if (settled) return;
          if (shouldCancel()) { finish(new WaitCancelledError()); return; }
          try {
            const value = predicate();
            if (value) { finish(null, { value, waitedMs: Date.now() - startedAt }); return; }
          } catch (error) { Logger.debug('Wait predicate failed; retrying', error?.message || error); }
          schedulePoll();
        });
      };

      try {
        observer = new MutationObserver(() => evaluate());
        observer.observe(rootNode, { subtree: true, childList: true, characterData: true, attributes: observeAttributes });
      } catch (error) { Logger.warning('MutationObserver unavailable; using polling', error?.message || error); }
      fallbackTimer = setTimeout(() => finish(new Error(`Wait timed out after ${timeoutMs}ms`)), timeoutMs);
      evaluate();
    });
  }

  root.LXWait = { wait, waitForCondition, WaitCancelledError };
})(typeof window !== 'undefined' ? window : globalThis);
